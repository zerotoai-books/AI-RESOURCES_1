# Chapter 10 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 10.2.2 A checked outcome map

| Outcome | Practice | Assessment evidence |
| --- | --- | --- |
| L1 Extract facts and unknowns | Identify three facts and one unresolved item in A. | Three accurate facts and one genuine unknown. |
| L2 Calculate the planned budget | Show each cost line and the remaining amount. | INR 2140 total and INR 260 remaining, with reserve included. |
| L3 Create an agenda that fits | Draft a 60-minute agenda with checking. | Durations total 60 and include a checking activity. |

U5 and U6 support these outcomes by keeping arrangements honest and preserving a correction record. The course does not promise mastery of all event management. It asks learners to finish a small, inspectable planning task.

## 10.2.3 Check the alignment

Ask whether a learner who completes the worksheet will have practised every assessed skill. Then ask whether a correct assessment answer can be traced to a source or lesson. Repair any gap before adding more content.

## 10.3.2 Complete worked lesson script

```text
Today you will turn a small workshop idea into a plan you can check. By the end, you should be able to identify supplied facts, calculate a planned budget, and create an agenda that fits the session.
```

```text
Start with the brief. Plan Your First Workshop is planned for 21 November 2026, from 10.30 am to 11.30 am IST. The capacity is 12 adult beginners. Learning Room, Adyar, Chennai is proposed, but the booking is not confirmed. The brief gives no registration count.
```

```text
Pause and underline three facts. Then circle one unresolved arrangement. Notice how capacity differs from confirmed attendance. A room can have capacity for 12 even when nobody has registered. We cannot calculate remaining places without the confirmed count.
```

```text
Next, calculate the planned costs. The venue figure is INR 800 and facilitation is INR 900. Printed learner packs cost 12 multiplied by INR 20, which is INR 240. Add the INR 200 reserve because this brief includes it inside the limit. The total is 800 + 900 + 240 + 200 = INR 2140.
```

```text
Pause and calculate the remaining amount yourself. The cap is INR 2400, so 2400 minus 2140 leaves INR 260. That is remaining budget. It is not profit, because the brief gives no revenue. These are planning figures, not evidence that invoices have been paid.
```

```text
An extra needs a new check. Refreshments for 12 people at INR 30 each add INR 360. The total would become INR 2500, which exceeds the cap by INR 100. Our selected plan therefore excludes refreshments. We keep the reserve instead of deleting it to hide the excess.
```

```text
Finally, allocate the session time. A useful agenda needs time for learners to practise and check their work. For example, five minutes of welcome, 10 of lesson, 15 of practice, five of checking, 10 of agenda work, 10 of assessment, and five of corrections total 60. Check both the minute sum and the clock times so that activities do not overlap.
```

```text
Pause and find the checking stages in that example. They let learners compare calculations, repair errors, and save a result they understand.
```

```text
Before saving your plan, compare it with the current brief. Keep the venue and access questions open, use the current time throughout, and record any correction with its source. You now have a method you can repeat with a different small planning task.
```

The lesson segment has a 10-minute slot in the delivery plan. The script is shorter than 10 minutes of continuous speech because it includes demonstration and learner pauses. Rehearse the complete segment with those pauses and shorten explanations if the practical work needs more time. The actual rehearsal result should guide the final allocation.

## 10.3.3 Check your result

• All three learning outcomes appear in the lesson.

• The current time is 10.30 am–11.30 am IST.

• Capacity is not described as registrations.

• The reserve is included in INR 2140.

• Remaining budget and profit are kept separate.

• The venue stays proposed and access stays unresolved.

## 10.4.3 Worked worksheet answer guide

W1: any three accurate facts earn a correct result. Examples are date 21 November 2026 and time 10.30 am–11.30 am IST from A2, and capacity 12 from A3. One genuine unknown is venue booking from A7, access or equipment from A8, or registrations from A3. Do not use an invented fact as the fourth item.

W2: venue 800, facilitation 900, printed learner packs 12 × 20 = 240, reserve 200. Total INR 2140; remaining INR 260. This does not establish profit because revenue is absent. Basis: A5 and A6. W3: extra 12 × 30 = INR 360; new total INR 2500; this exceeds the cap by INR 100 and fails the current budget.

W4: one valid answer is welcome five, lesson 10, practice 15, checking five, agenda work 10, assessment 10, and corrections five. Total 60. Alternative allocations are acceptable when they fit 60 and contain practice and checking. Basis: A4 and U4.

W5: use 10.30 am–11.30 am IST from A2. The venue is proposed and unconfirmed under A7; access is unresolved under A8; capacity 12 is not registrations under A3; refreshments are optional and excluded from the selected plan. W6: record one actual repair, such as replacing the older 10 am start with the current 10.30 am start, citing A2 version 1.1 and the corrected worksheet or summary.

Keep the answer guide separate when handing out the worksheet. In the worked session, learners complete W1–W3 during the 15-minute brief and budget practice, W4 during the 10-minute agenda activity, and W5–W6 during review and corrections. The assessment below is a separate individual task.

## 10.5.5 Assessment and corrections

At 11.15, give the separate assessment. Learners answer individually using Source A and the course rules, without viewing the answer key. This checks application of a source, not memorisation of hidden facts. At 11.25, show the key, ask learners to complete W5–W6, and save one correction with its source. End at 11.30.

## 10.6.3 Checked assessment key

T1: give one mark for each of three accurate supplied facts and one for a genuine unresolved fact. Examples: project title from A1; date and current time from A2; capacity from A3; budget cap from A5. Unknowns include registrations A3, venue booking A7, access or equipment A8. Maximum four. A fact with wrong numbers or an unsupported confirmation earns no mark.

T2: total 800 + 900 + (12 × 20) + 200 = INR 2140; remaining 2400 − 2140 = INR 260. Give one mark for the correct total with reserve and one for the correct remaining amount. Maximum two. Basis: A5, A6, and U3.

T3: give one mark for a complete allocation totalling 60 minutes and one for an explicit checking activity. The agenda in the delivery plan is one valid example; other sensible allocations can earn full marks. Maximum two. Basis: A4 and U4.

T4: the current start is 10.30 am IST and the end is 11.30 am IST under A2. A3 gives capacity 12, not 12 registrations; the actual registration count is unknown. Give one mark for the time repair and one for the capacity-versus-registration repair. Maximum two.

## 10.7.2 A checked correction record

| Defect | Source or rule | Repair and follow-up |
| --- | --- | --- |
| Wrong project name | A1 | Use Plan Your First Workshop in every resource. |
| Older session time | A2 | Use 10.30–11.30 am IST in lesson, schedule, and notes. |
| Capacity 10 | A3 | Use capacity 12; do not infer registrations. |
| INR 1940 cost total | A6 | Restore reserve; total 2140, remaining 260. Check all worked keys. |
| End time 11.40 | A2, A4, U4 | Repair the schedule to end at 11.30 and total 60. |
| Venue and access confirmed | A7 and A8 | Restore proposed venue and open access question. |

## 10.7.5 A possible handover note

```text
Plan Your First Workshop is prepared for human review using brief version 1.1. The pack contains the lesson, learner worksheet, separate answer guide, facilitator notes, assessment, and marking key.
```

```text
The planned session is 21 November 2026, 10.30 am–11.30 am IST, with capacity 12. The core planned total is INR 2140 including reserve, leaving INR 260 under the cap. The delivery agenda totals 60 minutes and includes practice, assessment, and corrections.
```

```text
Learning Room, Adyar, Chennai is still proposed and unbooked. Access and equipment need confirmation. Registrations and participant revenue are not supplied. Vishva should resolve venue and access questions; the equipment coordinator should confirm practical resources and rehearse delivery. These are proposed next actions. Shardha’s review and approval remain pending.
```

```text
Keep the older version 1.0 drawing as an archived comparison source. Public invitations should wait for the conditions in A9 to be resolved.
```

Your deliverable is a complete mini-course ready for human review. It can have complete learning resources while retaining unresolved real-world arrangements. Record those arrangements honestly. Do not mark the proposed session ready for public release merely because the documents look finished.

## 10.9.1 Worked challenge outcomes

• Calculate the Book Swap Helpers planned budget and remaining amount from the brief.

• Identify an unresolved arrangement and create a 45-minute agenda with checking.

## 10.9.2 Worked challenge lesson

```text
We will practise turning a small volunteering session into a plan we can check. Use the brief as the fact source. The session has capacity for eight adult volunteers, but no registration count is supplied. Community Room, Kochi is proposed and unbooked. Keep that status visible.
```

```text
Calculate costs line by line. Printing is eight multiplied by INR 15, or INR 120. Add venue INR 500, facilitation INR 600, and reserve INR 150. The planned total is INR 1370. Subtract it from the INR 1500 cap to get INR 130 remaining.
```

```text
Sticker kits would add eight multiplied by INR 25, or INR 200. That would raise the total to INR 1570, which is INR 70 over the cap. Exclude them under the current brief. Do not remove the reserve to hide the excess.
```

```text
Allocate the 45-minute session so volunteers can practise, compare their working, and correct mistakes. Check the duration sum and the clock intervals. Before saving, confirm that the venue still reads proposed, the time is 3 pm–3.45 pm IST, and no unsupported fee or attendance claim has been added.
```

## 10.9.3 Worked challenge worksheet

## 10.9.4 Worked challenge facilitator plan

| Time IST | Min | Activity |
| --- | --- | --- |
| 3.00–3.05 pm | 5 | Welcome and outcomes. |
| 3.05–3.13 pm | 8 | Use the short lesson. |
| 3.13–3.28 pm | 15 | Complete CW1–CW4. |
| 3.28–3.35 pm | 7 | Compare working with the separate guide. |
| 3.35–3.40 pm | 5 | Complete the individual assessment. |
| 3.40–3.45 pm | 5 | Correct and save one error record. |

Before delivery, confirm the venue and necessary access arrangements, prepare paper resources, and keep answers separate. The six durations total 45, and the clock intervals run continuously from 3 pm to 3.45 pm. Rehearse the eight-minute lesson segment with a calculation demonstration.

## 10.9.5 Worked challenge assessment and key

Keep the questions on the learner sheet and the marking text in a separate key. The maximum is six marks. A learner who meets the standard should still correct any wrong project time, budget amount, or unsupported venue confirmation before saving the pack.

## 10.9.6 Worked challenge handover

```text
Book Swap Helpers has a complete worked lesson, worksheet, 45-minute facilitator plan, assessment, and separate key ready for human review. The current time is 3 pm–3.45 pm IST on 28 November 2026. Capacity is eight, but registrations are not supplied. The core planned total is INR 1370, leaving INR 130; sticker kits are excluded because they would exceed the cap. Community Room, Kochi remains proposed and unbooked. Confirm the venue and practical access arrangements, rehearse the plan, and record the reviewer’s decision before public release.
```

## 10.10 Check your understanding

## 10.10.1 Answer guide
