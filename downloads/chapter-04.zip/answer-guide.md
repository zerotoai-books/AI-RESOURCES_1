# Chapter 4 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 4.4.2 Worked completion conditions

| Task IDs | Evidence of completion |
| --- | --- |
| P01 | Venue contact confirms the workshop room and session time, or records why confirmation failed. |
| P02 | A dated projector test result records power and image display as pass or fail. |
| P03 | A versioned brief reflects the venue and projector results and identifies open issues. |
| P04 | Budget arithmetic is checked against supplied cost inputs; defects or missing inputs are recorded. |
| P05 and P06 | Invitation and FAQ drafts use the current brief and distinguish unknown policies. |
| P07 | A presentation outline covers the supplied workshop purpose and session duration. |
| P08 | Shardha records review findings against all three drafts. |
| P09 | Vishva resolves findings or documents issues still awaiting a decision. |
| P10 | The final candidate pack is saved with a version and can be reopened. |
| P11 | the equipment coordinator checks the saved files and records pass, fail, or a blocker. |
| P12 | Shardha records Approve, Hold, or Reject with a reason and the pack version reviewed. |

A check can finish with a failed result, but a prerequisite that explicitly requires confirmation still blocks dependent work. If P01 fails, do not perform P02 as though venue access were confirmed; record the block and ask to replan. If P02 runs and fails, P03 can record that test result. The pack cannot be approved as though the projector had passed.

P04 checks the budget inputs available to the planner. A complete cost brief will be supplied in Chapter 5. In this chapter, a reviewer can record that cost decisions remain open rather than silently inventing prices. Your schedule reserves time for the review; it does not certify a budget you have not yet been given.

## 4.5.2 A checked dependency explanation

P01 precedes P02, and both feed P03. P04 follows P03. After P04, Vishva can draft the invitation and FAQ; the equipment coordinator can outline the presentation after P03. P08 waits for all three outputs. P09, P10, P11, and P12 then form the sequence from revision to approval decision. No dependency cycle appears in this task list.

A dependency cycle would mean that one task waits for another which eventually waits for the first. Neither could begin. This list avoids that problem, but it still needs a resource check. Two tasks may be logically independent and still compete for the same person’s available minutes.

## 4.6.2 One valid preparation schedule

| Day | Time IST | Task | Owner | Min |
| --- | --- | --- | --- | --- |
| Mon 2 Nov | 9.00–9.20 am | P01 | Vishva | 20 |
| Mon 2 Nov | 9.30–10.00 am | P02 | the equipment coordinator | 30 |
| Tue 3 Nov | 9.00–9.20 am | P03 | Vishva | 20 |
| Tue 3 Nov | 10.15–10.35 am | P04 | Shardha | 20 |
| Wed 4 Nov | 9.00–9.25 am | P05 | Vishva | 25 |
| Wed 4 Nov | 9.25–9.45 am | P06 | Vishva | 20 |
| Wed 4 Nov | 9.30–10.00 am | P07 | the equipment coordinator | 30 |
| Thu 5 Nov | 10.15–10.45 am | P08 | Shardha | 30 |
| Fri 6 Nov | 9.00–9.30 am | P09 | Vishva | 30 |
| Fri 6 Nov | 9.30–9.40 am | P10 | Vishva | 10 |
| Fri 6 Nov | 9.40–9.55 am | P11 | the equipment coordinator | 15 |
| Fri 6 Nov | 10.15–10.30 am | P12 | Shardha | 15 |

P01 ends before the Monday projector slot begins. On Tuesday, P03 finishes before P04. Vishva’s two Wednesday drafts use 45 minutes of his 60-minute window. The equipment coordinator’s outline finishes that morning. Shardha can therefore review all three outputs on Thursday. Friday leaves time to revise, save, check the saved version, and record the decision by 10.30 am, ahead of the 4 pm deadline.

## 4.6.3 Checked owner totals

| Owner | Task min | Week capacity | Unused min |
| --- | --- | --- | --- |
| Vishva | 125 | 300 | 175 |
| the equipment coordinator | 75 | 225 | 150 |
| Shardha | 65 | 150 | 85 |
| Team | 265 | 675 | 410 |

Vishva’s total is 20 + 20 + 25 + 20 + 30 + 10 = 125 minutes. The equipment coordinator’s is 30 + 30 + 15 = 75. Shardha’s is 20 + 30 + 15 = 65. The team task total is 265 minutes. Weekly capacities are five days multiplied by 60, 45, and 30 minutes respectively.

Unused time is capacity, not proof that delays can always be absorbed. Shardha’s Thursday review occurs late in her daily window; a missed review can move all downstream work. The equipment coordinator’s projector access is tied to Monday. A total of 410 unused team minutes does not create an additional room slot or make one person available outside their stated hours.

## 4.7.2 Checked review findings

• Monday P02 starts before the agreed projector slot and before venue confirmation.

• Tuesday Vishva is assigned 65 minutes, five more than his daily capacity; P05 and P06 also precede the required P04 budget review.

• Wednesday P08 is premature because P07 is not finished.

• Friday the equipment coordinator has a 15-minute overlap and 60 assigned minutes in a 45-minute window.

• The extra projector test has no approved duration or access slot in the supplied task list.

• P01, P04, P09, P10, P11, and P12 lack proper scheduled entries.

• Sending immediately after review bypasses revisions, saving, readiness checks, and the approval decision.

A useful correction refers back to a rule: move P02 into the agreed Monday slot after P01; split Vishva’s drafting across permitted days after P04; schedule P08 only when every draft is available. “Make the schedule better” does not identify which requirement has failed.

## 4.9.2 A possible review note

```text
The preparation schedule fits the stated owner windows, task durations, and dependencies. The event-day timings fit the room access and the two-hour participant session. Saturday attendance, exact joining details, and budget inputs remain open. Projector failure or an unavailable reviewer could cause further changes.
```

```text
Proposed status: Hold for release. Confirm the open items, review the saved pack, and record Shardha’s decision against its version. Completion of P12 means a decision is recorded; it does not guarantee that the decision is Approve.
```

A review note should reflect your actual sources. If the exercise later supplies the missing facts, update their status with the dated decision. Do not keep calling a matter unknown after it has been confirmed, and do not call a promised confirmation complete before the evidence arrives.

## 4.10.1 Answer guide after your attempt

A valid revision keeps Monday P01 and P02. Move P03 to Wednesday 9.00–9.20 am and P04 to Wednesday 10.15–10.35 am. Move P05 to Thursday 9.00–9.25 am and P06 to Thursday 9.25–9.45 am. P07 cannot fit the equipment coordinator’s 20-minute Wednesday window, so move it to Thursday 9.30–10.00 am. P08 still fits Thursday 10.15–10.45 am because all three inputs are ready by then.

The original Friday P09–P12 sequence can remain. Vishva’s capacity becomes 240 minutes, the equipment coordinator’s becomes 200, and Shardha’s stays at 150, giving 590 team minutes. Task time stays 265. The revision is feasible, but those totals alone are not the proof: the dated slots and predecessor finishes establish it.

## 4.10.2 Worked change log

| Task | Change | Reason |
| --- | --- | --- |
| P03 and P04 | Tuesday to Wednesday | Vishva unavailable Tuesday; budget follows brief |
| P05 and P06 | Wednesday to Thursday | Drafts follow the rescheduled P04 |
| P07 | Wednesday to Thursday | 30-minute task does not fit Wednesday’s 20 minutes |
| P08 | Thursday slot retained | All three drafts still finish before 10.15 am |
| P09–P12 | Friday slots retained | Their predecessor review still finishes Thursday |

If your plan moves the outline to Tuesday, it violates the updated P03 dependency, because the master brief would not yet exist. If it shortens the outline to 20 minutes, it violates the duration rule. Both are attractive-looking solutions to the wrong brief.

## 4.11.1 Questions to answer in your own words

## 4.11.2 Answer guide
