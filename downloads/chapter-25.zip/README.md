# Chapter 25 Deliver a complete workshop pitch

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 25.1.1 Your task

Step 1  State the spending approval being requested.

Step 2  Keep the proposal to five cards.

Step 3  List the event facts, agenda and budget that require checking.

Step 4  Set a four-minute spoken limit.

Step 5  Keep approval and actual rehearsal results pending until recorded.



## 25.2.1 Your task

Step 1  Put the proposal and purpose first.

Step 2  Explain the audience and practice activities.

Step 3  Show an agenda that reaches noon without extending the event.

Step 4  Put the estimates before the requested decision.

Step 5  Review the complete copy against the source set.



## 25.3.1 Your task

Step 1  Match each note to one card number.

Step 2  Explain the activity sequence and planning basis.

Step 3  Distinguish estimated cost from actual expenditure.

Step 4  End with the specific decision and next action.

Step 5  Keep a separate editable copy of the notes.



## 25.4.1 Your task

Step 1  Practise aloud with the deck in presentation view.

Step 2  Time every card and transition.

Step 3  Record the total before editing.

Step 4  Shorten repetition while retaining decision evidence.

Step 5  Rehearse again and save the new observations.



## 25.5.1 Your task

Step 1  Keep version 3 archived.

Step 2  Change materials and printing quantities to ten.

Step 3  Recalculate totals and remaining budget.

Step 4  Update the deck, notes and checking sheet.

Step 5  Produce fresh exports, inspect them and rehearse the revised pitch.

