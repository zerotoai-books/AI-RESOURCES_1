# Chapter 39 Plan a sequence and maintain continuity

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 39.2.1 Useful prompt or direction
Word body block 5299

```text
Storyboard direction: Shot one introduces paper planning. Shot two focuses on a blank planning page. Shot three returns to the complete tabletop arrangement. Finish with an editable event information card.
```

## 39.3.1 Useful prompt or direction
Word body block 5309

```text
Continuity record: one plain notebook, one yellow pencil, light wooden table, flat illustration style, soft light from the left. Framing may change. Keep the same visual identity across all three shots.
```

## 39.4.1 Useful prompt or direction
Word body block 5319

```text
Shot two motion direction: The view moves slowly toward the blank notebook page. Objects retain their positions and illustration style. Use the reviewed reference selected for this shot.
```

## 39.5.1 Useful prompt or direction
Word body block 5329

```text
Join review: At the cut from shot ___ to shot ___, the notebook ___. The change is intentional or distracting because ___. Required action ___; status ___.
```

## 39.6.1 Useful prompt or direction
Word body block 5339

```text
Sequence handover: Visual slots 00 to 08, 08 to 16 and 16 to 24; final card 24 to 30. Use hard cuts for the first assembly. Source files and selected ranges are listed in the storyboard.
```
