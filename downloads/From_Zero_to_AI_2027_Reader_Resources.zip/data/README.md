# Choose the correct dataset

The coding CSV has five columns including Alias. Claude uses data/claude/Registrations.csv with three columns. Excel uses the workbook tables with RegistrationDate and Seats. Do not swap their schemas. Generic Table CSV files preserve the corresponding printed table; the table index identifies its section.
