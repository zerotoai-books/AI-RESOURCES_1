# Chapter 18 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 18.2.2 Worked purpose note

```text
The paper-and-pencils illustration reinforces the hands-on planning activity. It is decorative teaching material. It does not show the actual room, establish past attendance or add equipment promises to C0.
```

## 18.2.3 Answer guide

The image must fit the activity and preserve room for the text. If generation adds lettering, a logo or an irrelevant screen, regenerate or make the simple drawing in Appendix A7. Do not spend the whole exercise improving decorative detail while leaving the registration contact unreadable.

## 18.3.2 Answer guide

One valid layout gives the image the lower third of the poster and keeps all essential facts above it. Another uses a small illustration beside the title. There is no requirement to fill every blank area. If the image makes the contact smaller or obscures the schedule, reduce the image before reducing essential text.

## 18.4.2 Worked editing record

| Intended edit | Check before editing | Check after editing |
| --- | --- | --- |
| Move the image | Correct object selected | No text covered |
| Widen contact text | Email text box selected | Full address visible |
| Change title weight | Title text selected | Words unchanged |
| Align date and venue | Intended blocks selected | Reading order clear |
| Undo an accident | Identify the unwanted change | Correct earlier state restored |

## 18.4.3 Answer guide

The final poster must still have the exact current time and contact. A group is useful for moving related objects together, but do not group the entire design and then assume every individual object remains directly selectable. The purpose of the exercise is to learn what the selection actually controls.

## 18.5.2 Worked asset record

```text
Asset: Paper_and_Pencils.png, created by the learner using Appendix A7.
Origin: my own arrangement of basic shapes or my own hand drawing.
Purpose: illustrative decoration in the fictional workshop exercises.
Source record: creation date, editor or drawing method, and author recorded in my log.
Content check: no people, venue photograph, logo or event lettering.
Limitation: it is not evidence of a real event or endorsement.
```

## 18.5.3 Answer guide

For a generated image, also save the prompt, tool, generation date and the relevant use information you checked. Do not write “copyright free everywhere” merely because the tool generated it. For third-party content, keep the applicable source information rather than relying on a verbal assumption.

## 18.6 Exercise 5 Check the image in the exported design

## 18.6.2 Worked observation note

```text
The illustration remains decorative and event words are separate text. The schedule and registration contact remain visible. The asset record identifies the image actually used. Phone-size readability still needs to be recorded for my own exported design; making an illustration alone does not establish that my layout passes.
```

## 18.6.3 Answer guide

An image file's pixel dimensions alone do not establish its print quality at a particular physical size. Inspect the source and the actual export. If a picture is blurred, use a better source, reduce its display size or replace it. Do not invent an AI-upscaling guarantee.

## 18.7.1 Answer guide

Inspect the stock photo's origin and intended-use information before retaining it. Remove the unverified logo because C2 supplies no sponsorship or brand relationship. Replace the generated contact with the exact photos@example.com address in an editable text element; removing the faulty lettering may require replacing the image itself. Keep the camera requirement and fee in the checked copy. A decorative image cannot establish that equipment is supplied.
