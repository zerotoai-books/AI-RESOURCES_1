# Chapter 28 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 28.1.2 Worked findings

| ID | Finding | Proposed treatment |
| --- | --- | --- |
| R02 | Category has spaces and lower case | Standardise to Workplace |
| R05 | Status is lower case | Standardise to Confirmed |
| R06 | Date is text 2026/11/06 | Convert to 6 Nov 2026 as a date |
| R03 | Two exact copies | Retain one after field comparison |
| R11 | Status is missing | Retain as Needs review |

## 28.1.3 Answer guide

A repeated ID is a reason to investigate. In this supplied case both R03 rows are identical in every field, so the approved rule removes one exact copy. If the same ID carried conflicting statuses or dates, that rule would not resolve the conflict. Record it for a human decision instead.

## 28.2.2 Answer guide

Replacing “ workplace ” with Workplace preserves the intended category in this controlled example. Promoting R11 to Confirmed would invent a booking decision. Deleting R11 would remove an unresolved record and understate the work still needed. Both actions differ from the approved cleaning rule.

Excel's TRIM can help with ordinary spaces, and a mapping can standardise recognised labels. Do not assume one text function fixes every kind of whitespace or every unfamiliar category. Inspect the supplied fields and keep unrecognised values visible.

## 28.3.2 Worked change log

```text
R02 Category: " workplace " to "Workplace". Trimmed and standardised an approved category.
R05 Status: "confirmed" to "Confirmed". Standardised recognised spelling.
R06 RegistrationDate: text "2026/11/06" to a true date representing 6 November 2026.
R03 duplicate: removed one identical repeated row after comparing all five source fields.
R11 Status: blank to "Needs review". Preserved the unresolved record without making a booking decision.
```

## 28.3.3 Answer guide

The cleaned result contains eleven distinct IDs. It has eight Confirmed, one Waitlisted, one Cancelled and one Needs review. Appendix A1 prints the expected cleaned result so you can compare it after your own attempt. It is an answer reference, not evidence that Copilot performed cleaning in your account.

Keep the raw and cleaned sources clearly distinguished. Formatting both with the same table style does not mean they have the same status or purpose.

## 28.4.2 Worked summaries

| Status | Records |
| --- | --- |
| Confirmed | 8 |
| Waitlisted | 1 |
| Cancelled | 1 |
| Needs review | 1 |
| Total | 11 |

Community has four Confirmed seats and Workplace has four. The sum is eight, matching the overall Confirmed measure. In Excel, a category formula can use SUMIFS with both Category and Status as criteria. An unfamiliar category must be investigated rather than disappearing from a chart of the two recognised labels.

## 28.4.3 Answer guide

The raw file has a duplicated confirmed record, so its apparent confirmed-seat sum is nine before the exact duplicate is resolved. Lower-case “confirmed” may still match an ordinary Excel criterion because common conditional functions are case-insensitive; cleaning its spelling is useful for consistent display and data rules, not proof that the original formula excluded it.

## 28.5.2 Worked handover

```text
The cleaned sample retains eleven distinct registration IDs from twelve raw rows. One exact repeated R03 record was removed. R02 and R05 labels were standardised, and R06's supplied date was converted to a true date. R11 remains in the data with Status set to Needs review. Confirmed seats total eight. A human booking decision is still required for R11 before it can be treated as Confirmed, Waitlisted or Cancelled.
```

## 28.5.3 Answer guide

A handover that says “all data fixed” overstates the result. The formatting and duplication issues have defined treatments, but the missing booking decision remains unresolved. Keep both the record and the open action visible.

## 28.6.1 Answer guide

Five raw rows become four distinct IDs. I01 and I02 are Confirmed, I03 is Needs review and I04 is Cancelled. Confirmed seats equal two. The cleaning process must not turn I03 into a third confirmed attendee or delete the unresolved record.
