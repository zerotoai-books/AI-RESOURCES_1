# Chapter 32 Write and revise a simple program

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 32.1.1 Your task
Word body block 4685

```text
Use the full K1 materials quote rules supplied below. Plan a small Python command-line calculator using only the standard library. Define input validation, decimal arithmetic, discount rounding, output and error behavior. Include the 25 times 12 with 10 percent example and two invalid cases. Do not edit files yet.
```

## 32.2.1 Your task
Word body block 4700

```text
Implement the calculation described in K1 in calculator.py. Create quote(unit_price, quantity, discount_percent="0") and return separate subtotal, discount and total values. Use Decimal values constructed from validated text. Round only the discount with ROUND_HALF_UP to two decimal places. Keep calculation separate from printing and use no external package.
```

## 32.3.1 Your task
Word body block 4715

```text
Add K1 validation to quote and its parsing helpers. Reject fractional quantities, negative values, blank input, exponent notation, NaN, Infinity, separators, currency text and prices with more than two decimals. Keep zero price, zero discount and 100 percent discount valid. The public quote function accepts typed text, not arbitrary Python numeric objects. Do not change the calculation policy.
```

## 32.4.1 Your task
Word body block 4737

```text
Add an argparse interface to calculator.py. Support python calculator.py 25 12 --discount 10. Default the discount to zero. On invalid input show a clear error and exit unsuccessfully, rather than printing a fake total. Preserve import without terminal output and keep the quote function usable by tests.
```

## 32.5.1 Your task
Word body block 4752

```text
Review these actual calculator results against K1. Explain any mismatch using the input rule and arithmetic. Keep expected and observed values separate. If a correction is needed, identify the affected helper or calculation before changing code.
```
