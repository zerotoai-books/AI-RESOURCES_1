# Chapter 10 source inputs

These are fictional teaching sources from the current printed manuscript. Use the exact source ID and scope named in the exercise. Deliberate defects and old versions remain unchanged.

## 10.1 What the finished pack contains

| Resource | Purpose |
| --- | --- |
| Master brief | Preserve the current project facts and open questions. |
| Learning outcomes | Define what the learner must be able to do. |
| Short lesson | Explain the method and demonstrate it. |
| Learner worksheet | Provide practice without placing answers beside the questions. |
| Facilitator notes | Allocate time and explain how to run and check the activities. |
| Assessment and key | Test the outcomes with transparent marking. |
| Review and handover record | Record corrections, unresolved arrangements, and review status. |

Start with the outcomes and evidence, then write the materials that support them. If you begin by asking for a long lesson, you may end with attractive explanations that the worksheet never practises or the assessment never tests.

## 10.9 Independent challenge

Build a complete 45-minute training pack for Book Swap Helpers. Use this current practice brief: date 28 November 2026; time 3 pm–3.45 pm IST; eight adult volunteers; paper format; proposed Community Room, Kochi, with booking unconfirmed. Core costs are venue INR 500, facilitation INR 600, eight learner packs at INR 15, and reserve INR 150. This printing figure includes the learner resources and facilitator copies. The cap is INR 1500 including reserve. Optional sticker kits cost eight × INR 25. No fee, registration count, or revenue is supplied.

Include two observable outcomes, a short lesson, four worksheet tasks, facilitator notes, a three-question assessment, a separate key, and a handover note. The worksheet should practise the assessed skills. Keep the venue unresolved and check the optional kits before deciding whether to include them.


## Current project brief from Chapter 8

## 8.3 Source A Community workshop brief

CURRENT PRACTICE SOURCE  |  VERSION 1.1

A1 Project
Plan Your First Workshop is a proposed community learning session coordinated by Vishva. The equipment coordinator is the proposed facilitator and Shardha is the reviewer.

A2 Date and time
The date is 21 November 2026. Version 1.1 sets the session time to 10.30 am to 11.30 am IST. It replaces the 10 am to 11 am time in version 1.0.

A3 Audience and capacity
The session is for adult beginners. Capacity is 12 attendees. No registration count is supplied.

A4 Learning format
Use English, paper activities, and a 60-minute session. Attendees must not be required to bring a phone or laptop.

A5 Budget limit
The total planned budget must be at most INR 2400, including the reserve. No participant fee or revenue is agreed.

A6 Supplied costs
Venue: INR 800. Facilitation: INR 900. Printed learner packs: 12 at INR 20 each. The printing figure covers learner resources and facilitator copies. Planning reserve: INR 200. Optional refreshments: 12 at INR 30 each, additional to the core budget. These are fictional planning figures, not current market quotations.

A7 Venue status
Learning Room, Adyar, Chennai is proposed. The room booking is not confirmed.

A8 Open questions
Step-free access and available room equipment have not been confirmed. The brief does not promise refreshments, certificates, parking, or loan devices.

A9 Review condition
The materials must be checked by Shardha. Venue and access questions must be resolved before public invitations are released.

A10 Source status
This is practice brief version 1.1. A room sketch labelled version 1.0 is an illustration and has an outdated time. It does not establish room availability or actual attendance.


## Syllabus from Chapter 9

## 9.1 The supplied syllabus

Course: Planning a small workshop. This is a short practice syllabus for the fictional community project. Use U1–U6 as the knowledge source and Source A version 1.1 as the project fact source. The course’s rules define how the exercises will be assessed.

U1 Define a useful outcome
An outcome describes something a learner can do and how it will be checked. Example: calculate a supplied budget and show the working. A topic such as budgeting names the subject but does not describe the task.

U2 Keep facts and unknowns separate
A fact is supported by the supplied brief. An unknown is not supplied or is explicitly unresolved. Capacity describes the maximum allowed attendance; it does not establish bookings. Keep the source version with your notes.

U3 Calculate the planned budget
Multiply quantity by unit price for each variable cost, then add fixed costs and the reserve. Remaining budget equals the limit minus the total. The reserve counts inside the limit in this course. Revenue is not given, so profit cannot be calculated.

U4 Build an agenda that fits
An agenda allocates the complete available time to activities. Include practice and checking. Each interval must end where the next begins, without an overlap or an unexplained gap. These are the scheduling rules for the exercises in this course.

U5 Record unfinished arrangements
Every unresolved arrangement needs a named owner and a specific question or action. Proposed details must remain proposed. A drawing of a room does not confirm a booking, access arrangements, or equipment availability.

U6 Check work before saving
Compare names, dates, times, costs, and claims with the current brief. Recalculate totals independently. Record the original error, the correction, and the source used. Save the checked version and the evidence that supports it.


## Official tool references

## Gemini

## Official references for the Gemini chapters

Product guidance was checked on 12 October 2026. The references support the Gemini access, file, privacy, and optional learning-tool instructions. The scenarios, source notes, illustrations, budgets, schedules, prompts, worked answers, and marking guides are teaching material created for this book. Follow the current official help if your account or interface differs.

1 Google  Use Gemini Apps
https://support.google.com/gemini/answer/13275745?hl=en
Official web app: https://gemini.google.com

2 Google  Upload and analyse files in Gemini Apps
https://support.google.com/gemini/answer/14903178?hl=en

3 Google  Gemini Apps Privacy Hub
https://support.google.com/gemini/answer/13594961?hl=en

4 Google  Use learning tools in Gemini Apps
https://support.google.com/gemini/answer/16448384?hl=en
