# Chapter 21 Generate a presentation from a short brief

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 21.2.1 Your task
Word body block 3679

```text
Using the complete G0 brief pasted below, plan a five-card presentation for adult beginners considering the workshop. Cover the event, who it suits, the practice activities, the practical details and registration. Keep the exact date, 11 am to noon IST, venue, free attendance, capacity and contact. Use navy, white and amber with editable text. Do not add certificates, refreshments, sponsors, participant numbers or guaranteed outcomes. Show the proposed card outline before building. This is a fictional practice event.
```

## 21.3.1 Your task
Word body block 3692

```text
Revise the outline to exactly five cards. Use these purposes: introduce the workshop; identify the audience and what to bring; explain the three practice tasks; give the practical details; explain registration and access enquiries. Keep G0 as the source. Do not invent missing information.
```

## 21.5.1 Your task
Word body block 3726

```text
Check the quoted draft against G0. List wrong, missing and unsupported details. Then provide corrected event wording. Capacity is not a booking count. Use the current version 3 time and exact contact.
```
