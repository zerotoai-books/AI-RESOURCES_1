# Chapter 22 source inputs

These are fictional teaching sources from the current printed manuscript. Use the exact source ID and scope named in the exercise. Deliberate defects and old versions remain unchanged.

## Gamma

## Official references for the Gamma chapters

Product guidance was checked on 14 October 2026 IST. The 2027 label identifies the book edition. Use current official help and account notices because features and eligibility can change.

Worked answers are editorial examples, not captured Gamma or Copilot responses. Practice events, registrations and estimates are fictional. Reviews, rehearsals and app checks remain pending until actually performed.

## GREF1 Gamma Create with Agent

Current conversation and plan flow.

https://help.gamma.app/en/articles/15002203-how-do-i-create-with-agent-in-gamma

## GREF2 Gamma Create a presentation with the classic generator

Alternative creation routes.

https://help.gamma.app/en/articles/7838093-how-do-i-create-a-new-presentation-document-or-webpage-in-gamma

## GREF3 Gamma Import slides or content

Source files and content preservation.

https://help.gamma.app/en/articles/11047840-how-can-i-import-slides-or-content-into-gamma

## GREF4 Gamma Export a presentation

PDF PNG PPTX and export options.

https://help.gamma.app/en/articles/8022861-what-s-the-easiest-way-to-export-my-gamma

## GREF5 Gamma Resolve export differences

Presentation view and export inspection.

https://help.gamma.app/en/articles/15939201-why-doesn-t-my-exported-pdf-or-powerpoint-match-what-i-see-in-gamma

## GREF6 Gamma Use speaker notes

Notes presenter view and timing.

https://help.gamma.app/en/articles/11047307-can-i-use-speaker-notes-while-presenting-in-gamma

## GREF7 Gamma Understand credits

Current usage notices.

https://help.gamma.app/en/articles/7834324-how-do-credits-work-in-gamma

## GREF8 Gamma Collaboration and sharing settings

Access permissions and plan differences.

https://help.gamma.app/en/articles/11047226-how-do-collaboration-and-sharing-settings-work-in-gamma

## Practice sources printed for offline use

These source documents are printed here for the controlled exercises. Type the source text into your tool or create your own saved copy. They are fictional teaching material. Additional datasets and creation instructions appear in the Printed practice materials appendix.

## G0 Workshop Presentation Brief v3

G0 Workshop presentation brief version 3

Fictional teaching case for From Zero to AI by SUNDAR P. This continues the Canva time update used in Chapter 20. No actual event booking, payment or approval is described.

Event: Plan Your First Workshop.

Date: Saturday 21 November 2026.

Time: 11 am to noon IST. Use this time throughout the Gamma section.

Venue: Learning Room, Adyar, Chennai. Confirmed only within the fictional exercise.

Audience: adult beginners. Capacity: 12. This is a maximum, not bookings or seats remaining.

Attendance: free. English and paper activities. Printed practice materials included. No phone or laptop needed.

Learning tasks: write one learning outcome, calculate a supplied budget, and make a timed agenda. These are practice tasks, not promised professional certification.

Registration: learn@example.com, a placeholder. Do not email it or publish the practice deck as a real invitation.

Access: step-free access is confirmed in the fictional venue note. Specific access needs should be discussed with the organiser. Universal accessibility is not established.

No certificates, refreshments, parking, transport or loan devices are promised. No sponsor or partner logo is supplied.

First deliverable: five cards for an audience considering attendance. The later pitch is for a fictional organiser deciding whether to approve a plan.

Design: navy #162638, white #FFFFFF and amber #F2B544. Use editable text and a simple sans-serif font. Imagery is optional.

Reviewer: Shardha. Review is pending until recorded during the exercise.

## G1 Workshop Proposal Source

G1 Workshop proposal source version 1

Fictional planning supplement to G0. G0 supplies the event facts. This supplement supplies teaching estimates and an approval request; it does not prove payment, market prices or approval.

Proposed planning budget limit: INR 1500. Attendance remains free. No participant revenue is assumed.

Room estimate: one booking at INR 600, total INR 600.

Materials estimate: 12 sets at INR 25 each, total INR 300.

Printing estimate: 12 sets at INR 15 each, total INR 180. All figures include the full costs assumed in this exercise. No additional costs are supplied. Estimates are for full capacity, not the current number of registrations. Planned total: INR 1080. Budget remaining: INR 420. This remaining amount is unallocated budget, not profit, revenue or savings against actual expenditure.

Agenda in IST

11.00 to 11.05 Welcome and choose a workshop idea, 5 minutes.

11.05 to 11.15 Write one learning outcome, 10 minutes.

11.15 to 11.30 Calculate the supplied budget, 15 minutes.

11.30 to 11.45 Build a timed agenda, 15 minutes.

11.45 to 11.55 Review with a partner, 10 minutes.

11.55 to noon Recap and next action, 5 minutes.

Total: 60 minutes. The six activity blocks can be grouped on one card.

Decision sought: approve the proposed plan and a spending limit of INR 1500 after the reviewer checks the deck and estimates. Approval is pending. No supplier quotes or actual expenditure are supplied.

## G2 Reviewer Feedback

G2 Fictional reviewer feedback

Keep the deck to five cards. State who should attend before giving the full logistics. Give the agenda a readable sequence. Place the budget before the approval request. Make learn@example.com readable. Remove claims about guaranteed results and certificates. Keep speaker detail in notes rather than shrinking slide text.

The final spoken pitch must be no longer than four minutes, including transitions and excluding questions. A useful time allowance is 35, 45, 50, 65 and 45 seconds for the five pitch cards. These allowances total 240 seconds. Record actual rehearsal times; do not call the allowances a completed rehearsal. Reviewer approval remains pending until recorded.

## G3 Capacity Change v4

G3 Capacity change version 4

Fictional revision used only in Chapter 25 Exercise 5. Capacity becomes 10 instead of 12. The budget limit remains INR 1500. Materials and printing quantities follow capacity: 10 sets at INR 25 and 10 sets at INR 15. Room estimate remains INR 600. Revised planned cost is INR 1000 and budget remaining is INR 500. Date, 11 am to noon IST, venue, audience, free attendance, contact and access wording stay as in G0. No bookings are supplied. Update the deck, speaker notes, checking sheet and exports. Keep version 3 archived.

## G4 Photography Challenge

G4 Independent presentation challenge

Fictional event: First Steps in Photography.

Date: Saturday 28 November 2026. Time: 3 pm to 4.30 pm IST.

Venue: Studio Room, Kochi, confirmed for the exercise.

Audience: adult beginners. Capacity: eight. Fee: INR 650 per person. Bring your own camera or camera phone. Contact: photos@example.com, a placeholder. No food, certificate, parking or equipment loans are supplied. Specific access arrangements are unknown. No registration count, expenses, supplier quotes or approval are supplied. Maximum potential fee revenue at eight paying attendees is INR 5200. This is a conditional illustration, not revenue already collected. Profit cannot be calculated without costs. Create a separate five-card deck. For the final challenge, allow at most three minutes for the spoken pitch, excluding questions. Do not combine this event with G0.
