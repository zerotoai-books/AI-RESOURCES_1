# Chapter 31 Set up your coding workspace

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 31.1.1 Your task

Step 1  Install VS Code and a suitable Python interpreter using their official instructions.

Step 2  Add the Microsoft Python extension in VS Code if it is not already present.

Step 3  Open the Copilot control in VS Code's Status Bar, choose Use AI Features when shown, and follow the sign-in prompts for your GitHub account. [GH2]

Step 4  Use File then Open Folder to open a new local practice folder.

Step 5  Record your editor version, Python version and the account access route in the practice log.



## 31.2.1 Your task

Step 1  Use the Python interpreter selector in VS Code to choose your installed interpreter.

Step 2  Open a fresh integrated terminal and check the version.

Step 3  Confirm that hello_workshop.py is visible in the current folder.

Step 4  Run the file and read the complete terminal output.

Step 5  Record the command, output and any error before changing anything.



## 31.3.1 Your task

Step 1  Find the two input names, capacity and confirmed.

Step 2  Locate the checks before the subtraction.

Step 3  Identify the line that returns the available count.

Step 4  Follow the result into main, where the program prints it.

Step 5  Explain why importing this file is different from running it as the main program.



## 31.4.1 Your task

Step 1  Save the baseline version.

Step 2  Change only the demonstration's confirmed input to nine.

Step 3  Run the file and compare with your prediction of three.

Step 4  Try thirteen confirmed places against capacity twelve.

Step 5  Restore the baseline inputs and run it again.



## 31.5.1 Your task

Step 1  Compare the original and revised demonstration call.

Step 2  Confirm that the input checks were not removed.

Step 3  Save the actual baseline and changed outputs.

Step 4  Record your interpreter and the working folder.

Step 5  Write a short explanation in your own words.

