# Chapter 50 Produce a complete audio handover

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 50.2 Exercise 1 Define the deliverables and source versions

Step 1  Create entries for the short English promotion, three part English explanation and optional reviewed second language version.

Step 2  Assign the actual script and source version to each.

Step 3  Record target duration, actual duration and status in separate fields.



## 50.3 Exercise 2 Fit the short script to the real edit

Step 1  Generate a candidate only after checking the script and voice route.

Step 2  Measure the downloaded recording and compare it with thirty seconds.

Step 3  If needed, revise optional wording and regenerate, preserving essential facts.



## 50.4 Exercise 3 Align narration with picture and readable text

Step 1  Import the reviewed audio into a copy of the Chapter 40 project if available.

Step 2  Check the spoken message against each visual slot and final information card.

Step 3  Play with sound, then muted, and inspect the final exported video if one is made.



## 50.5 Exercise 4 Complete the final listening and file checks

Step 1  Open each candidate in a separate player.

Step 2  Check complete playback, intelligibility, factual accuracy, joins, contact and final silence.

Step 3  Record actual format, duration and any unresolved language or permission issue.



## 50.6 Exercise 5 Package the handover and next actions

Step 1  Collect scripts, settings, pronunciation records, source permissions and actual outputs.

Step 2  Use the handover template to list each item and status.

Step 3  Mark Shardha approval Pending and identify any required language or organiser review.

