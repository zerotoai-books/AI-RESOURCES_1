# Chapter 22 Improve the sequence and slide wording

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 22.1.1 Your task

Step 1  Write the question answered by each card.

Step 2  Identify information the reader needs before making a decision.

Step 3  Remove a repeated promotional card if it adds no information.

Step 4  Keep the five-card count after reordering.



## 22.2.1 Your task

Step 1  Mark promises that G0 does not support.

Step 2  Keep the audience and actual activities.

Step 3  Explain the session in ordinary words.

Step 4  Compare the revised copy with the original source.



## 22.3.1 Your task

Step 1  Keep the card focused on the three practice tasks.

Step 2  Move logistical details to the details and registration cards.

Step 3  Put a short explanation of each task into speaker notes.

Step 4  Keep the notes tied to their card number.

Step 5  Check that the audience can understand the card without seeing the notes.



## 22.4.1 Your task

Step 1  Give the heading a clear visual position.

Step 2  Group the three task statements together.

Step 3  Keep the background plain enough to read comfortably.

Step 4  Use amber for a small accent rather than for long body text.

Step 5  Preview at a realistic presentation size.



## 22.5.1 Your task

Step 1  Record the deck names and versions being compared.

Step 2  Note what changed in order, text or layout.

Step 3  Record what the reviewer actually found or missed.

Step 4  Separate an observation from an opinion about style.

Step 5  Write a short reason for choosing the revised version.

