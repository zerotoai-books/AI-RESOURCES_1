# Chapter 20 Build a workshop promotion kit

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 20.2.1 Your task

Step 1  List the five designs and text caption required by C0 and C1.

Step 2  Record the purpose, dimensions, source design and intended export of each.

Step 3  Mark the essential standalone facts each graphic must retain.

Step 4  Leave publication and review approval Pending until decisions are recorded.



## 20.3.1 Your task

Step 1  Use the supplied copy blocks as the initial content for the designs and caption.

Step 2  Place essential standalone event details on each graphic before decoration.

Step 3  Apply consistent type and asset choices while adapting each arrangement.

Step 4  Check every item against C0 and C1 and save the first coordinated candidate kit.



## 20.4.1 Your task

Step 1  Check each design against the current copy and brief.

Step 2  Check asset records and remove unusable or unapproved content.

Step 3  Inspect title, schedule, venue and contact at the intended reading size.

Step 4  Download only the intended release pages.

Step 5  Open every exported file outside Canva and repeat the factual check.



## 20.5.1 Your task

Step 1  Collect the brief, design names, export list, asset record and correction log.

Step 2  Write a handover note identifying the exact candidate release.

Step 3  Record actual factual, readability and export observations, leaving unperformed checks Pending.

Step 4  State Shardha’s review status and next decision without inventing approval or publication.



## 20.6.1 Your task

Step 1  Update the poster, square post, story, registration graphic and handout.

Step 2  Update the caption and any associated plain-text copy.

Step 3  Search the revised source copy for the old time.

Step 4  Re-export the affected files and inspect every one.

Step 5  Update the manifest and correction record to v3.

