# Chapter 32 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 32.1.2 Worked acceptance rules

Unit price is plain nonnegative decimal text from zero to INR 100000, with at most two decimal places. Quantity is a whole number from one to forty. Discount is a whole percent from zero to one hundred. Surrounding spaces can be trimmed. Currency symbols, thousands separators, exponent notation, non-finite values and negative prices are rejected.

Calculate subtotal from price times quantity. Calculate the percentage discount, round that discount once to two decimal places using ROUND_HALF_UP, then subtract it from the subtotal. The discount rule belongs to this exercise. A different business could specify a different policy.

## 32.1.3 Answer guide

The plan should preserve zero as a genuine price and a hundred-percent discount as valid. It should reject zero quantity. These choices differ because the inputs have different meanings. A single generic check that every value is greater than zero would violate the brief.

Current VS Code guidance provides a dedicated planning workflow, including Plan mode in the Copilot target where available. Review the proposed files and checks before implementation. [GH4] The project needs only calculator.py; an extra web framework or remote service adds work without serving K1.

## 32.2.2 Worked calculation excerpt

After parsing has produced price, count and percent, the worked function uses:

```text
subtotal = price * count
discount = (subtotal * percent / Decimal("100")).quantize(
    Decimal("0.01"), rounding=ROUND_HALF_UP
)
total = subtotal - discount
```

The returned Quote object keeps components under the names subtotal, discount and total. A small named result is easier to inspect than a single unexplained number. The complete implementation and imports are printed in Appendix A3.

## 32.2.3 Answer guide

The baseline should give 300.00, 30.00 and 270.00 when formatted to two places. A total of 290 indicates that ten was subtracted as rupees instead of applying ten percent. A subtotal of 300 alone does not complete the discount calculation.

## 32.3.2 Worked validation decisions

The reference price parser checks a plain decimal pattern before constructing Decimal. This matters because Decimal itself can represent NaN and Infinity. Successful conversion alone is therefore not the full validation rule. The whole-number parser checks digits and then the relevant minimum and maximum.

The reference API rejects a Boolean or a Python number supplied directly instead of text. That is an explicit, narrow interface for these beginner exercises. It does not imply that every production calculator must use the same interface.

| Input case | Expected decision | Reason |
| --- | --- | --- |
| Price 0 | Accept | A genuine zero cost is allowed |
| Quantity 0 | Reject | At least one kit is required |
| Quantity 12.5 | Reject | Kits are whole units here |
| Discount 100 | Accept | Full discount is permitted |
| Price NaN | Reject | It is not a valid quoted price |
| Price 25.001 | Reject | More than two decimal places |

## 32.3.3 Answer guide

Trimming surrounding spaces is acceptable under K1. Silently removing an internal comma, currency symbol or decimal digit is not. For example, changing 25.001 to 25.00 would invent a correction rather than reject the input the brief excludes.

## 32.4.2 Worked command and output

Run this from your calculator's folder:

```text
python calculator.py 25 12 --discount 10
```

```text
Subtotal INR 300.00
Discount INR 30.00
Total INR 270.00
```

## 32.4.3 Answer guide

The worked command returns exit code zero. The reference uses argparse's error route for an invalid quantity such as 12.5; it reports the problem and exits with code two. The exact surrounding usage text can vary with the command path. Check the meaning, output and exit status rather than expecting every terminal to wrap the error identically.

## 32.5.2 Worked answer checks

With no discount, the baseline total is INR 300.00. With price zero it is zero, and with a hundred-percent discount it is also zero for a different reason. Quantity 12.5 is rejected. Price 100000.01 is rejected as above the practice maximum.

For price INR 0.05, quantity one and fifty-percent discount, the unrounded discount is INR 0.025. K1 rounds the discount to INR 0.03, leaving total INR 0.02. Rounding the net amount independently could produce a different answer, which is why the order must be specified.

## 32.6.1 Answer guide

Subtotal is INR 200.00. Fifteen percent is INR 30.00, leaving INR 170.00. With no discount the total is INR 200.00. Discount 101 is rejected. A program that subtracts fifteen rupees would return 185 and fail this challenge.
