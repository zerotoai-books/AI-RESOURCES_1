# Chapter 1 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 1.3.2 A possible first answer

```text
A prompt is the message you give an AI tool to ask for help. It can be a question or an instruction. For example, “Write a short invitation using these workshop facts” tells the tool what you want it to produce.
```

Send the follow-up in the same conversation if the explanation needs changing. A follow-up is another message about the current task, such as asking for simpler wording or a shorter version. Save both versions so that you can see what the instruction changed.

A prompt can be a question, an instruction, or a combination of both. The exercises that follow will show you how to provide the information needed for a useful response.

## 1.4 Exercise 1 Ask for a useful explanation

Goal: request an explanation that fits the reader. Materials: the prompt below. Output: a short explanation and a revised example.

## 1.4.2 A possible answer

```text
Cloud storage keeps your files on a service you reach through the internet. Instead of keeping the only copy on one phone or laptop, you can sign in to the service to access it. For example, you might save a holiday photograph in an online storage account and open it later on another device. The service’s settings determine who can see it. Saving a file online does not automatically make it public.
```

Check the example against the everyday meaning of cloud storage. It describes files held by an internet service and accessed through an account. It also preserves the point that online storage is not automatically public. An explanation that says every photograph becomes public would be inaccurate.

## 1.4.5 A possible two-sentence revision

```text
Cloud storage keeps your files on an internet service that you can access through your account. For example, you can save a holiday photograph and open it on another device; who else can see it depends on the service’s access settings.
```

## 1.4.6 Check your result

• The explanation describes remote storage and access through an internet service.

• It uses a photograph example and avoids unexplained technical terms.

• It does not say that every online file is public or that every service has unlimited space.

Try it yourself: repeat the exercise with “two-step verification.” Keep the task to an explanation; do not share a real login code. Your own summary should make sense without copying the AI answer.

## 1.6.4 A possible revised plan

| Time | Activity | Action |
| --- | --- | --- |
| 15 minutes | Learn | Read one good email and identify its purpose, facts, and request. |
| 30 minutes | Practise | Write and revise a fictional invitation with AI assistance. |
| 15 minutes | Check and save | Verify the details and save the final draft with the prompt. |

## 1.6.5 Check your result

The durations must add to 60 minutes. There should be exactly three activities. Each activity needs a concrete action, and the final activity must include checking and saving. A fourth activity or a 75-minute total means the instruction has not been followed.

## 1.7.3 A possible answer

```text
Subject: Join the Everyday AI Workshop on 7 November
```

```text
Hello,
Join our Everyday AI Workshop on 7 November 2026, from 10 am to noon IST, at Learning Room, Adyar, Chennai. This session is for adults who are new to AI.
The fee is INR 499 per person, and materials are included. Capacity is 12 attendees.
To book, email learn@example.com.
We look forward to welcoming you.
```

## 1.7.4 Check your result

Compare each event detail with the brief. Confirm that “12 places” describes capacity and does not claim that 12 people have booked. Check that the example email is copied exactly. Count the body separately from the subject line.

Try it yourself: ask for a 45-word version suitable for a short message. Decide which details must remain. Shortening should not silently change the fee, date, or booking action.

## 1.8.3 A possible two-sentence summary

```text
The team kept the registration cap at 12 and assigned Vishva to draft the invitation by 22 October. The projector check has no agreed date, and venue confirmation, poster review, loan-laptop availability, and the next meeting still need decisions.
```

## 1.8.4 A possible action table

| Task | Owner | Due date |
| --- | --- | --- |
| Draft invitation | Vishva | 22 October 2026 |
| Check projector | the equipment coordinator | Not agreed |
| Confirm venue | Not assigned | Not agreed |
| Assign poster reviewer | Not assigned | Not agreed |
| Confirm loan laptop availability | Not assigned | Not agreed |
| Agree next meeting date | Not assigned | Not agreed |

## 1.8.5 Check your result

The capacity decision is confirmed, but the venue is not. Vishva has a named deadline. The equipment coordinator has a task without a deadline. The laptop request should not be treated as proof that loan laptops exist. Ask whether the notes imply an action, a decision, or an unresolved question.

Different action wording can be acceptable if it preserves these distinctions. A useful open-question list asks who will confirm the venue, who will review the poster, whether loan laptops are available, and when the next meeting will occur.

## 1.9 Exercise 5 Check a numerical answer

Goal: verify calculations independently and correct a supplied mistake. Materials: a small fictional stationery order and a calculator. Output: checked line totals and an accurate overall total.

## 1.9.3 The checked answer

Notebooks: 12 × 40 = INR 480. Pens: 20 × 10 = INR 200. Folders: 5 × 30 = INR 150. Overall total: 480 + 200 + 150 = INR 830.

## 1.9.4 Challenge the answer

Test whether the assistant checks the evidence rather than agreeing with a confident suggestion. Introduce the colleague’s INR 930 total as a claim to investigate, not as a correction to accept. Ask ChatGPT to recalculate from the original order. Then compare each quantity, price and subtotal yourself; accept a revised total only when its arithmetic is supported.

## 1.9.6 Check your result

The correct total is INR 830. INR 930 is INR 100 too high. The response should identify the discrepancy without inventing a delivery charge to explain it. If the assistant agrees with INR 930, show the three line totals and request a correction.

A correct answer here does not prove that every future calculation will be correct. For larger datasets, use spreadsheet formulas or another reproducible calculation method and reconcile totals.

## 1.10.4 A possible revised reminder

```text
Reminder: the Everyday AI Workshop is on 7 November 2026, from 11 am to 1 pm IST, at Learning Room, Adyar, Chennai. The fee is INR 499 per person and materials are included. To book, email learn@example.com.
```

## 1.10.5 A possible revised invitation

```text
Subject: Everyday AI Workshop on 7 November
```

```text
Hello,
Join the Everyday AI Workshop on 7 November 2026, from 11 am to 1 pm IST, at Learning Room, Adyar, Chennai. This session is for adults who are new to AI.
The fee is INR 499 per person, materials are included, and capacity is 12 attendees.
To book, email learn@example.com.
We look forward to welcoming you.
```

## 1.10.6 Three checked FAQ answers

```text
Who is it for?
Adults who are new to AI.
```

```text
Are materials included?
Yes. The brief confirms that materials are included in the fee.
```

```text
How do I book?
Email learn@example.com.
```

## 1.10.7 A possible change log

Version 2 changes the workshop time from 10 am–noon to 11 am–1 pm IST. The date, venue, fee, capacity, materials, audience, and booking contact remain unchanged. The three FAQ answers do not mention a time, so they need no wording change.

## 1.10.8 Check your result

• Every time reference uses 11 am to 1 pm IST; none retains the old 10 am start.

• The date, venue, fee, capacity, and booking contact are unchanged.

• FAQ answers describe only what the brief confirms.

• The change log names the time update and avoids claiming other changes.

• All word limits are met; each document has a clear purpose.

## 1.12 When an answer needs correction

Specific feedback is easier to act on than “make it better.” Name the defect, identify the source of truth, and say what should change. Corrections should be small enough that you can check whether they worked.

| Problem | A useful next instruction |
| --- | --- |
| An invented detail | Remove the certificate claim. The brief does not include certificates. Use only the supplied facts. |
| Too much text | Keep the body under 80 words. Preserve the date, time, venue, fee, and booking action. |
| Wrong tone | Use straightforward everyday English. Remove exaggerated praise and sales language. |
| Missing information | Include the time zone and booking contact exactly as written in the brief. |
| A wrong calculation | Recalculate every line from quantity and unit price, then add the line totals. |
| Contradictory versions | Compare the three drafts against the updated brief and list every inconsistent detail. |

## 1.14 Before saving an answer

• Does it answer the actual task?

• Do all names, numbers, dates, and contacts match the supplied material?

• Are unknown details still marked as unknown?

• Does the format meet the instruction?

• Have you reviewed the whole result after the final revision?

## 1.16 Check your understanding and work independently

## 1.16.1 Questions to answer before looking below

## 1.16.2 Answer guide

## 1.17.1 Answer guide after your attempt

```text
Subject: First Steps in Photography on 14 November
```

```text
Hello,
Join First Steps in Photography on 14 November 2026, from 3 pm to 5 pm IST, at Studio Room, Kochi. The fee is INR 650, and capacity is now eight participants. Please bring your own camera or camera phone.
To book, email photos@example.com.
```

```text
Reminder: First Steps in Photography is on 14 November 2026, 3 pm–5 pm IST, at Studio Room, Kochi. The fee is INR 650 and capacity is eight. Bring your camera or camera phone. To book, email photos@example.com.
```

Change record: capacity was reduced from 10 to eight. The session time, location, fee, device requirement, and contact stayed the same. No refreshments, certificates, parking, or equipment loans were added. This is a separate case from the later Photography project, whose brief supplies its own time and prices.
