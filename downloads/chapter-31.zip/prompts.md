# Chapter 31 Set up your coding workspace

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 31.1.1 Your task
Word body block 4600

```text
I am learning Python with the supplied K0 brief. Explain the different jobs of VS Code, the Python extension, the Python interpreter and GitHub Copilot. Do not edit files or install packages. Tell me which checks I should perform myself before running the first example.
```

## 31.2.1 Your task
Word body block 4616

```text
Explain how to run hello_workshop.py from this folder using my selected Python interpreter. Do not change the code. If a command fails, help me interpret the exact error I provide instead of assuming that the program ran successfully.
```

## 31.3.1 Your task
Word body block 4630

```text
Read hello_workshop.py and explain the path from main to available_seats and back to print. Use the inputs 12 and 8. Explain each validation check and the purpose of the __name__ guard. Answer without editing the file.
```

## 31.4.1 Your task
Word body block 4643

```text
Change only the demonstration call in main from available_seats(12, 8) to available_seats(12, 9). Keep the validation function unchanged. Show the exact changed line and predict the output. Do not claim that execution happened unless a terminal run actually occurred.
```

## 31.5.1 Your task
Word body block 4655

```text
Review my original and revised hello_workshop.py. Identify every actual code change and explain whether it matches the request. Separate results I supplied from results you only predict. Suggest one manual check, without making further edits.
```
