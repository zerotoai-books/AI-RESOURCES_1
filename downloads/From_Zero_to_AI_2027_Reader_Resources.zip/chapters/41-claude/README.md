# Chapter 41 Start a conversation and check the facts

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 41.2 Exercise 1 Establish the source and task

Step 1  Paste or attach B0 and name its version in your message.

Step 2  Ask for a compact fact list and a separate unknown list.

Step 3  Compare every returned item with the source.



## 41.3 Exercise 2 Ask for a short invitation with limits

Step 1  Ask for a friendly invitation of no more than ninety words.

Step 2  Require the date, time, place and booking contact.

Step 3  Read the result aloud and compare it with your fact list.



## 41.4 Exercise 3 Use a follow up to make one change

Step 1  Save the first invitation.

Step 2  Ask for a version no longer than fifty words.

Step 3  Compare the two versions and identify any omitted essential fact.



## 41.5 Exercise 4 Catch and correct an unsupported claim

Step 1  Compare the flawed text with B0 sentence by sentence.

Step 2  List incorrect and unsupported claims separately.

Step 3  Request a corrected version and verify it again.



## 41.6 Exercise 5 Save a traceable conversation record

Step 1  Save the source version, useful prompts and final candidate.

Step 2  Record factual checks and any unresolved question.

Step 3  Separate your review results from the assistant’s assurances.

