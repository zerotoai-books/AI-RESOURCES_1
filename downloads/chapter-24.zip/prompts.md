# Chapter 24 Review visuals and exported files

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 24.1.1 Your task
Word body block 3946

```text
Use a simple decorative illustration of paper and pencils for the workshop activities card. Keep it separate from the editable text. Do not depict a real venue, named participant, sponsor logo or certificate. Preserve the three checked practice tasks. If an appropriate image is unavailable, use a clear text-only card.
```

## 24.2.1 Your task
Word body block 3957

```text
Audit the budget card against G1. Preserve the three estimated cost components and their units. Use a zero baseline for a bar or column chart. Keep total cost, spending limit and remaining budget labelled separately. Report any element that does not match the source before revising it.
```

## 24.4.1 Your task
Word body block 3980

```text
Prepare this five-card proposal for a PDF review. Preserve the checked content and make any readability corrections you can identify. Give me a checklist for opening and inspecting the export. Do not claim the export passed until I record observations from the downloaded file.
```
