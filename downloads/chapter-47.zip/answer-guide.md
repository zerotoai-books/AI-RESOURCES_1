# Chapter 47 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 47.2.2 Worked answer guide

The list separates a chosen expansion, such as Indian Standard Time, from a place name that needs a knowledgeable listener. A spelling approximation can help generation but is not authoritative pronunciation evidence. Do not invent an International Phonetic Alphabet transcription or claim local approval without review.

Check your work. The spoken contact “learn at example dot com” is a listening form; the editable title must still show learn@example.com exactly.

## 47.3.2 Worked answer guide

Both tests preserve the date and time. Test B gives the listener a clearer boundary before the time range, though the actual delivery still needs listening. Keep the same voice and model so the comparison is meaningful. If you also change the voice, record that as a separate experiment.

Check your work. Do not assume a comma creates a fixed length pause. The model interprets punctuation, and actual timing must be measured in the output.

## 47.4.2 Worked answer guide

A successful test reads the expanded timezone clearly. A test dictionary rule is: written term IST, replacement Indian Standard Time. Enter that pair through a supported dictionary editor rather than assuming an upload format. If dictionaries are unavailable, write Indian Standard Time directly in the spoken script. That fallback preserves meaning without relying on a hidden replacement rule.

Check your work. A dictionary change can affect every matching term in a project. Check existing paragraphs after connecting or editing it, especially if the project contains more than one language.

## 47.5.2 Worked answer guide

The target is an intelligible invitation, not a particular numerical slider value. If a model offers speed, record its actual setting and compare the same sentence. If a tag is spoken aloud or creates an unintended sound, remove it and check the model guide. Never assume that a bracketed production note will remain silent.

Check your work. The contact and date must stay understandable. A more animated voice that blurs those facts is a worse result for this exercise.

## 47.6.2 Worked answer guide

A complete record can say that the timezone expansion passed while Adyar remains pending a knowledgeable listener. It should not collapse those statuses into “all pronunciation approved.” Preserve the earlier take so the effect of the revision is clear, and keep the script version aligned with the candidate audio.

Check your work. If only one paragraph was regenerated, listen at its joins with neighbouring audio. A pronunciation fix can introduce a change in level, tone or rhythm.

## 47.7.1 Answer guide after your attempt

Suitable spoken forms include “six hundred and fifty Indian rupees” and “four thirty p.m.” The contact can be tested as “photos at example dot com,” while the written address stays literal. Kochi needs a recognisable local reading. The answer includes actual listening observations if generated, or a clearly marked test plan if not.
