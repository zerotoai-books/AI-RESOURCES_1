# Chapter 4 source inputs

These are fictional teaching sources from the current printed manuscript. Use the exact source ID and scope named in the exercise. Deliberate defects and old versions remain unchanged.

## 4.3 The supplied planning brief

Planning period: Monday 2 November through Friday 6 November 2026. The preparation pack must reach a recorded approval decision by 4 pm IST on Friday. Vishva is available from 9 am to 10 am each weekday; the equipment coordinator from 9.30 am to 10.15 am; Shardha from 10.15 am to 10.45 am. These windows cover preparation work only. Saturday availability must be confirmed separately.

Vishva coordinates the brief and drafts. The equipment coordinator checks equipment and the final saved pack. Shardha verifies the budget, reviews content, and records the release decision. For this exercise, these responsibilities and the preparation windows are agreed. An owner may do only one task at a time. Different owners may work in parallel when dependencies allow it.

Every task must keep the duration in the supplied list and finish within one daily working window. A dependent task may start at the exact time its prerequisite finishes. Venue confirmation is a desk task. Projector testing requires venue confirmation and a separate agreed access slot on Monday from 9.30 am to 10 am. Do not add travel time, overtime, or substitute owners without an explicit change to the brief.

For the event itself, the room access window is 10 am to 1.30 pm on Saturday 7 November. Participant-facing teaching must stay within 11 am to 1 pm. Proposed event-day roles are Vishva for registration, the equipment coordinator for setup and equipment, and Shardha for teaching. Those Saturday roles are proposals, not confirmed attendance.

## 4.3.1 The preparation task list

| ID | Task | Owner | Min | After |
| --- | --- | --- | --- | --- |
| P01 | Confirm venue | Vishva | 20 | None |
| P02 | Test projector | the equipment coordinator | 30 | P01 |
| P03 | Update master brief | Vishva | 20 | P01 and P02 |
| P04 | Verify budget | Shardha | 20 | P03 |
| P05 | Draft invitation | Vishva | 25 | P03 and P04 |
| P06 | Draft FAQ | Vishva | 20 | P03 and P04 |
| P07 | Outline presentation | the equipment coordinator | 30 | P03 |
| P08 | Review all drafts | Shardha | 30 | P05, P06 and P07 |
| P09 | Revise review issues | Vishva | 30 | P08 |
| P10 | Save final pack | Vishva | 10 | P09 |
| P11 | Check release readiness | the equipment coordinator | 15 | P10 |
| P12 | Record approval decision | Shardha | 15 | P11 |

The durations are fictional exercise estimates. They are not a claim that a real workshop can always be prepared in this much time. Here they give you fixed inputs for a schedule that can be checked. When doing your own work, replace them with estimates supported by your experience and include any required travel or waiting time.

## 4.7 Exercise 4 Review a deliberately defective plan

SUGGESTED TIME 20 MINUTES  |  OUTPUT REVIEW NOTES WITH CORRECTIONS

The table below is intentionally incomplete and inconsistent. Use it as material to review, not as a suggested schedule. There are several ways to fail the brief even when the task names look reasonable.

| Proposed slot | Owner | Work |
| --- | --- | --- |
| Mon 9.00–9.30 am | the equipment coordinator | P02 projector test before P01 confirmation |
| Tue 9.00–10.05 am | Vishva | P03 20 min, P05 25 min, P06 20 min |
| Wed 10.15–10.45 am | Shardha | P08 review before P07 outline is complete |
| Fri 9.30–10.00 am | the equipment coordinator | P07 presentation outline |
| Fri 9.45–10.15 am | the equipment coordinator | Extra projector test in the same period |
| Fri after review | Team | Send the pack immediately |

## 4.7.3 Keep a review record

For each defect, record the task ID, the problem, the source rule, the agreed correction, and whether you rechecked it. A note such as “P08 moved after P07; all three inputs now available by Thursday morning” explains why the change solves the issue. A note saying only “fixed” cannot be inspected later.

## 4.10 Independent challenge Reschedule changed availability

Keep the original task list and deadline. Two preparation windows change: Vishva is unavailable on Tuesday 3 November, and the equipment coordinator is available only from 9.30 am to 9.50 am on Wednesday 4 November. Every other daily window remains as originally stated. Tasks must still remain within one daily window and preserve all durations.

Write your own prompt, revise the schedule, and produce a change log. Check all affected successors, not just the tasks whose slots changed. State whether a valid schedule still exists and whether the Friday decision deadline can still be met. Keep event-day attendance and open budget inputs visible.


## Official tool references

## ChatGPT

## Official references for the ChatGPT chapters

The references support the general product use and prompting guidance. The workshop scenarios, datasets, prompts, sample answers, plans, and assessments are teaching material. Product guidance was checked on 11 October 2026. Follow the current official instructions if your account or screen differs.

1 OpenAI  Use ChatGPT
https://learn.chatgpt.com/docs/use-chatgpt

2 OpenAI  Prompting
https://learn.chatgpt.com/docs/prompting

3 OpenAI  ChatGPT on the web
https://learn.chatgpt.com/docs/web
