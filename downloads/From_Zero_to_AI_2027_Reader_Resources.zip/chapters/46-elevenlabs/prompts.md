# Chapter 46 Generate a clear voiceover from an approved script

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 46.2.1 Useful prompt or direction
Word body block 5802

```text
Script preparation note: Preserve the event name, date, 11 am to noon Indian Standard Time, free attendance, adult beginner audience and English paper based activity. Keep the booking address as a separately checked spoken form.
```

## 46.3.1 Useful prompt or direction
Word body block 5812

```text
Audition sentence: Join Plan Your First Workshop on the twenty first of November, twenty twenty six. Voice review: clear words, comfortable pace, suitable tone and understandable date.
```

## 46.4.1 Useful prompt or direction
Word body block 5822

```text
Listening direction: Compare every spoken word with the audition sentence. Check the event name and date first. Note the exact misheard phrase and timestamp instead of giving only a general quality score.
```

## 46.5.1 Useful prompt or direction
Word body block 5832

```text
Full review: Compare the recording with Voiceover_Main_EN.txt. Confirm the event facts, English activity description and spoken contact. Record actual duration and any defect. Do not assume a target duration from the word count.
```

## 46.6.1 Useful prompt or direction
Word body block 5842

```text
Take record: language English; script version ___; voice ___; model ___; format ___; measured duration ___; playback and factual checks ___; reviewer ___; approval Pending.
```
