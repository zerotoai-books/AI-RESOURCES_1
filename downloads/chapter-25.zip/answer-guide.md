# Chapter 25 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 25.1.2 Worked acceptance criteria

The deck must contain five purposeful cards, preserve the date and 11 am to noon IST time, show capacity 12 and free attendance, account for the 60-minute agenda, and state planned costs of INR 1080 with INR 420 remaining against the proposed limit. The final card must request a decision and identify the review still needed. The export must be opened and the rehearsal timed before either check is recorded as complete.

## 25.1.3 Answer guide

“A persuasive deck” is too vague to check. These criteria identify what a reviewer can actually inspect. They also keep generated polish from replacing the decision request or the numerical evidence.

## 25.2.2 Worked pitch card copy

```text
Card 1
Plan Your First Workshop
Proposed session for adult beginners
Saturday 21 November 2026, 11 am to noon IST
Learning Room, Adyar, Chennai
```

```text
Card 2
What participants will practise
Write one learning outcome.
Calculate a supplied budget.
Build a timed agenda.
English and paper activities. Printed materials included. No phone or laptop needed.
```

```text
Card 3
One hour from idea to review
Welcome 5 minutes
Learning outcome 10 minutes
Budget 15 minutes
Agenda 15 minutes
Partner review 10 minutes
Recap 5 minutes
```

```text
Card 4
Estimated delivery cost
Room INR 600
Materials INR 300
Printing INR 180
Planned total INR 1080
Proposed limit INR 1500
Remaining budget INR 420
```

```text
Card 5
Decision requested
Approve the proposed plan and spending limit after review.
Free attendance. Capacity 12.
Registration contact learn@example.com.
Step-free access is confirmed in the fictional venue note; discuss specific needs with the organiser.
Approval pending. Fictional practice case.
```

## 25.2.3 Answer guide

The cards preserve the decision, numbers and source qualifications. Some layouts may need fewer visible words and more speaker detail in notes. If you shorten Card 5, keep the approval request, pending status and correct contact somewhere visible. Do not remove essential conditions merely to maintain a preferred layout.

## 25.3.2 Worked speaker notes

```text
Card 1
This proposal is for Plan Your First Workshop, a practical session for adult beginners. The supplied case places it at Learning Room in Adyar, Chennai, on Saturday 21 November from 11 am to noon IST. I am asking the organiser to review the plan and proposed spending limit. The case is fictional, and the approval remains pending.
```

```text
Card 2
The session uses English and paper activities. Participants practise writing one learning outcome, calculating a supplied budget and building a timed agenda. Printed practice materials are included, and no phone or laptop is needed. These are specific practice tasks; the brief does not promise certification or guaranteed professional skills.
```

```text
Card 3
The agenda uses the full hour. A five-minute welcome leads into ten minutes on the learning outcome. Budget and agenda practice receive fifteen minutes each. Ten minutes are set aside for partner review and five for the recap. The total is sixty minutes, and the final block ends at noon. Speaker explanation should not extend the workshop window.
```

```text
Card 4
The estimates are planned for the full capacity of twelve. One room estimate is six hundred rupees. Twelve materials sets at twenty-five rupees cost three hundred, and twelve printing sets at fifteen rupees cost one hundred and eighty. Together they make one thousand and eighty rupees. Against the proposed fifteen-hundred-rupee limit, four hundred and twenty remains unallocated. This is not profit or actual spending.
```

```text
Card 5
The requested decision is approval of the proposed plan and spending limit after review. Attendance is free and capacity is twelve; the case does not supply bookings. The placeholder registration contact is learn@example.com. The fictional venue note confirms step-free access, while specific needs still require discussion. The next step is to complete the review and record the organiser's decision before release.
```

## 25.3.3 Answer guide

The notes are a rehearsal starting point. Their length alone cannot establish your delivery time because speaking rate and transitions vary. Gamma's notes and presenter view can support rehearsal; check the controls available in your account. [GREF6] Keep notes out of the audience screen and inspect their presence in exported files before delivery.

## 25.4.2 Worked timing plan

| Card | Purpose | Allowance sec | Actual sec |
| --- | --- | --- | --- |
| 1 | Introduce the proposal | 35 | Record result |
| 2 | Explain the activities | 45 | Record result |
| 3 | Explain the agenda | 50 | Record result |
| 4 | Explain the estimates | 65 | Record result |
| 5 | Request the decision | 45 | Record result |
| Total | Spoken pitch with transitions | 240 | Add actual times |

## 25.4.3 Answer guide

The allowances total four minutes. They are a plan, not completed timing evidence. If your pitch takes four minutes and twenty seconds, it exceeds the limit by twenty seconds. Remove repeated descriptions before deleting necessary cost qualifications. A successful second rehearsal must be timed again; an edited script does not automatically prove a shorter delivery.

## 25.5.2 Answer guide

Materials become INR 250 and printing INR 150. With the INR 600 room estimate, the new planned total is INR 1000 and remaining budget INR 500. Capacity 10 still does not establish a booking count. If the deck changes but a note still says twelve sets, the project is inconsistent. An older PDF remains an older version until you produce and inspect a replacement.

## 25.6.1 Answer guide

The deck must retain the fee of INR 650 per person, capacity eight, camera requirement, photos@example.com and the 90-minute event window. INR 5200 is maximum potential fee revenue only if eight attendees pay. Profit is not established. The three-minute pitch limit is 180 seconds and does not shorten the event. Save actual rehearsal results and leave approval pending until recorded.
