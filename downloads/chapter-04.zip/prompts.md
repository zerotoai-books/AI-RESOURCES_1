# Chapter 4 Plan and review a multi-step assignment

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 4.4.1 Prompt to try
Word body block 1037

```text
For P01–P12, propose one observable completion condition per task using only the planning brief. Distinguish completing a check from passing it. Do not add unlisted deliverables, substitute owners, or promise approval. Mark a failed check as a result that may block the next decision rather than claiming the issue is fixed.
```

## 4.5.1 Prompt to try
Word body block 1062

```text
Review the P01–P12 task list. Confirm one responsible owner per task, list every predecessor, identify tasks that can run in parallel, and check for missing task IDs or dependency cycles. Preserve the supplied owners and dependencies. Do not remove review, revision, saving, readiness, or approval steps to shorten the plan.
```

## 4.6.1 Prompt to try
Word body block 1077

```text
Schedule P01–P12 from Monday 2 to Friday 6 November 2026. Use only the stated owner windows and task durations. Each task must fit one daily window; owners cannot overlap their own tasks. Honor every dependency and the Monday projector access slot. Show Day and date, Start–finish IST, Task ID, Owner, and Minutes. Finish the recorded approval decision by Friday 4 pm. Then show minutes by owner and remaining capacity. Keep unknown costs and Saturday attendance visible as open decisions.
```

## 4.7.1 Prompt to try
Word body block 1128

```text
Inspect the defective plan against the original planning brief and P01–P12. Identify owner-window violations, overlaps, wrong ordering, missing tasks, unsupported added work, and assumptions about approval. For each defect, cite the violated rule and propose a correction. Do not silently repair the table; first show the review findings.
```

## 4.8.1 Prompt to try
Word body block 1148

```text
Propose an event-day plan for Saturday 7 November 2026. Room access is 10 am–1.30 pm IST; the participant workshop is 11 am–1 pm. Use the equipment coordinator for setup, Vishva for registration, and Shardha for teaching as proposed roles awaiting confirmation. Include two teaching blocks, a short break, questions, setup, registration, and tidying. Show start and finish times. Do not treat Saturday attendance or issue resolution as confirmed.
```

## 4.9.1 Prompt to try
Word body block 1177

```text
Using the checked preparation schedule and proposed event-day plan, make a short review note. Separate current open issues from possible future risks. For each, identify the affected task, proposed action, and decision needed. End with a proposed status of Ready, Ready with agreed conditions, or Hold, explaining what evidence is still required. Do not claim that an AI review grants approval.
```
