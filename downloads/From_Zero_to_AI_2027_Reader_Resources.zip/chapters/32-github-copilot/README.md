# Chapter 32 Write and revise a simple program

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 32.1.1 Your task

Step 1  Name the three inputs and their units.

Step 2  Record their permitted ranges and formats.

Step 3  Write the calculation order, including the rounding point.

Step 4  Specify the baseline output and at least two rejected inputs.

Step 5  Ask for an implementation plan before changing the starter file.



## 32.2.1 Your task

Step 1  Read the starter file's fixed price and quantity.

Step 2  Add a function named quote with the three text inputs.

Step 3  Calculate subtotal, rounded discount and total separately.

Step 4  Return those three values so tests can inspect them.

Step 5  Keep printing in a separate main function.



## 32.3.1 Your task

Step 1  Validate the price's plain decimal spelling and maximum amount.

Step 2  Validate quantity as whole-number text in its permitted range.

Step 3  Validate discount as whole-number percent text in its own range.

Step 4  Preserve valid zero prices and valid hundred-percent discounts.

Step 5  Reject unsupported inputs with a useful ValueError.



## 32.4.1 Your task

Step 1  Put the command-line work in main.

Step 2  Read unit_price and quantity as positional arguments.

Step 3  Add --discount with a default of zero.

Step 4  Convert a validation failure into an input error and a nonzero exit code.

Step 5  Print the three monetary components with INR labels and two decimals.



## 32.5.1 Your task

Step 1  Run the baseline with ten-percent discount.

Step 2  Run the same price and quantity with no discount.

Step 3  Test zero price and a hundred-percent discount separately.

Step 4  Test one fractional quantity and one excessive price.

Step 5  Check the small rounding case in K1.

