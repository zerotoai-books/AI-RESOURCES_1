# Chapter 16 Create your first workshop poster

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 16.3.1 Your task
Word body block 3185

```text
Create an A4 portrait poster for a fictional practice event. Event: Plan Your First Workshop. Audience: adult beginners. Date: Saturday 21 November 2026. Time: 10.30 am to 11.30 am IST. Venue: Learning Room, Adyar, Chennai. Free to attend; capacity 12. English; printed practice materials included; no phone or laptop needed. Register by emailing learn@example.com. Use navy, white and amber with a simple sans-serif font. Give the title, date and registration instruction a clear reading order. Keep text editable where supported. Do not add promises, logos or extra facts. Include Fictional practice event in a small footer.
```

## 16.4.1 Your task
Word body block 3196

```text
Revise this poster draft using the supplied C0 facts only. Make the event title prominent, preserve the exact date and time and remove any unsupported benefit. Keep the registration instruction visible. Explain any change you cannot make automatically so I can edit it manually.
```

## 16.6.1 Your task
Word body block 3223

```text
Check this poster copy against C0 version 2. List wrong, missing and unsupported details separately. Return corrected wording without adding an offer or implying a booking count.
```
