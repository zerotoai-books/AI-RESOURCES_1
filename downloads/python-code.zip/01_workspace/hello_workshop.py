def available_seats(capacity, confirmed):
    if type(capacity) is not int or type(confirmed) is not int:
        raise ValueError("Use whole-number counts")
    if capacity <= 0 or confirmed < 0 or confirmed > capacity:
        raise ValueError("Counts outside the allowed range")
    return capacity - confirmed


def main():
    print("Available seats:", available_seats(12, 8))


if __name__ == "__main__":
    main()
