# Chapter 5 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 5.3.2 Approved decision record for the worked project

| Decision | Date | Effect |
| --- | --- | --- |
| Keep 11 am–1 pm workshop time | 6 Nov 2026 | Use the revised Chapter 1 time in all current outputs |
| Confirm venue and projector test | 6 Nov 2026 | Treat these checks as passed for this worked case |
| Confirm Saturday team roles | 6 Nov 2026 | Use Vishva, the equipment coordinator, and Shardha as stated above |
| Confirm arrival at 10.40 am | 6 Nov 2026 | Add to joining instructions and the reminder |
| R010 is Cancelled | 6 Nov 2026 | Close the Chapter 3 blank-status question; receipts unchanged |
| No loan laptops | 6 Nov 2026 | State bring own laptop; do not promise a loan device |

These decisions resolve selected gaps from earlier exercises. They do not resolve the street address, access route, or refund policy. Keep those matters visible. Confirmation of one fact is not permission to assume related facts.

## 5.4.2 A possible master brief

```text
Master Brief v4
Issued 6 November 2026
```

```text
Everyday AI Workshop introduces adults new to AI to clear prompts, follow-ups, and checking short drafts. The workshop is on Saturday 7 November 2026, 11 am–1 pm IST, at Learning Room, Adyar, Chennai. Participant arrival is 10.40 am. Room access is 10 am–1.30 pm.
```

```text
Fee: INR 499 per ticket. Capacity: 12 participants. Printed learning sheets are included. Participants bring their own laptop; loan devices are not available. Booking enquiries: learn@example.com.
```

```text
Vishva handles communications and registration, the equipment coordinator setup and equipment, and Shardha teaching and review. Venue, projector test, arrival time, and Saturday roles are confirmed for this case.
```

```text
Ticket snapshot: eight Paid and two Pending tickets are active; two tickets are Cancelled. Paid receipts are INR 3,992. D07 is excluded as an exact duplicate of D04. R010 is Cancelled under the 6 November decision.
```

```text
Budget: planned allowance INR 4,520, including INR 300 reserve.
```

```text
Open: exact street address and accessible entrance route must be confirmed before the attendance reminder is sent. Refund terms, payment instructions, refreshments, and certificates are not supplied.
```

## 5.5.2 A possible checked invitation

```text
Subject: Everyday AI Workshop on 7 November
```

```text
Hello,
Join the Everyday AI Workshop on Saturday 7 November 2026, from 11 am to 1 pm IST, at Learning Room, Adyar, Chennai. It is for adults new to AI, with practice in writing prompts, asking follow-ups, and checking short drafts.
The fee is INR 499 per ticket. The workshop is limited to 12 participants, and printed learning sheets are included. Please bring your own laptop; loan devices are not available.
For booking enquiries, email learn@example.com.
Best,
Vishva
```

## 5.5.4 A possible reminder draft

```text
Reminder: Everyday AI Workshop is on Saturday 7 November 2026, from 11 am to 1 pm IST, at Learning Room, Adyar, Chennai. Please arrive at 10.40 am and bring your own laptop. Printed learning sheets are included; loan devices are not available. For questions, email learn@example.com.
```

The reminder meets the writing brief, but it is not ready to send as complete joining instructions. The exact address and accessible route still need Vishva’s confirmation. Save it with a Hold status in the review record. Do not put an invented address into the message to remove that status.

## 5.5.5 Check the two documents together

• Both use Saturday 7 November 2026 and the 11 am–1 pm IST session.

• Arrival at 10.40 am is distinct from the teaching start at 11 am.

• The invitation describes the capacity limit without claiming all 12 places remain.

• Both preserve the own-laptop requirement and avoid loan-device promises.

• The contact is identical wherever it appears.

• The reminder’s release condition is recorded beside its saved version.

## 5.6.2 A possible checked FAQ

```text
Who is the workshop for?
Adults who are new to AI and want introductory practice with prompts, follow-ups, and checking short drafts.
```

```text
When is it?
Saturday 7 November 2026, from 11 am to 1 pm IST. Please arrive at 10.40 am.
```

```text
Where is it?
Learning Room, Adyar, Chennai. Exact street-address and accessible-entrance details are awaiting confirmation. Contact learn@example.com for the confirmed joining information.
```

```text
What does it cost?
INR 499 per ticket.
```

```text
How many participants can attend?
The workshop is limited to 12 participants. This is the capacity limit, not the number of places still available.
```

```text
What is included?
Printed learning sheets.
```

```text
What should I bring?
Your own laptop. Loan devices are not available.
```

```text
How do I make a booking enquiry?
Email learn@example.com. Payment instructions are not supplied in this practice brief.
```

```text
Are refunds available?
Refund terms are not supplied. Ask the organiser at learn@example.com before relying on a refund arrangement.
```

```text
Are certificates or refreshments included?
The brief does not confirm either. Ask the organiser rather than assuming they are included.
```

This example leaves the unknowns visible while giving a useful contact. It does not turn “not supplied” into a policy that refunds are forbidden. It also does not say that certificates are included merely because a workshop commonly issues them.

## 5.7.2 Checked budget calculations

Planned allowance = 1,800 + 1,500 + 420 + 300 + 200 + 300 = INR 4,520. At full Paid capacity, fee revenue would be 12 × 499 = INR 5,988. Projected balance = 5,988 − 4,520 = INR 1,468. This is a planning projection including the reserve, not a report of actual profit.

Nine Paid tickets would provide 9 × 499 = INR 4,491, which is INR 29 below the planned allowance. Ten would provide INR 4,990, which is INR 470 above it. Therefore, the minimum whole number of Paid tickets needed to cover this fixed planning allowance is 10. Capacity is 12, so that quantity is possible within the stated limit.

| Measure | Calculation | INR |
| --- | --- | --- |
| Total planned allowance | All six budget lines | 4,520 |
| Full Paid capacity projection | 12 × 499 | 5,988 |
| Projected balance at 12 Paid | 5,988 − 4,520 | 1,468 |
| Recorded paid receipts | 8 × 499 | 3,992 |
| Pending-ticket amount | 2 × 499; not collected | 998 |
| Receipts compared with planned allowance | 3,992 − 4,520 | −528 |

The negative INR 528 comparison says current recorded receipts are below the planned allowance. It does not say that the event has already lost INR 528, because actual expenses are not supplied. If both Pending tickets become Paid, receipts would reach INR 4,990, provided the fee and quantities stay unchanged.

## 5.8.2 A possible checked outline

| Part | Content and practice | Min |
| --- | --- | --- |
| 1 Welcome and task | Event title, 7 November, 11 am–1 pm IST; capacity 12; introductory purpose. Each reader chooses one simple drafting task. | 10 |
| 2 Write a useful prompt | Supply purpose, reader, facts, and requested format. Practise an invitation using the fictional brief. | 40 |
| 3 Short break | Pause between the two teaching blocks. | 10 |
| 4 Ask a follow-up | Change tone or length while preserving source facts. Compare the revised draft with the first. | 25 |
| 5 Check and save | Inspect dates, costs, policies, and unsupported claims. Save the corrected draft with its prompt. | 20 |
| 6 Questions and next practice | Answer questions and identify one task to practise independently. | 15 |

Parts 1 and 2 take 50 minutes, matching 11 am to 11.50 am. The break takes 10 minutes. Parts 4 and 5 take 45 minutes, matching noon to 12.45 pm. Questions take 15 minutes. The total is 120 minutes, with 95 minutes of teaching, 10 minutes of break, and 15 minutes of questions.

The outline names what each part should teach and what the learner should do. If you later ask for slides, provide this checked outline and review the resulting slide text. A slide deck can drift away from the outline just as an email can drift away from its source brief.

## 5.9.2 Inspect this deliberately faulty draft fragment

```text
Invitation: “Join us on 7 November from 10 am to noon. All 12 places are still available.”
FAQ: “The fee is INR 450, and laptops and certificates are provided.”
Budget note: “All 12 fees have been received.”
Outline: “The questions section runs from 1 pm to 1.15 pm.”
```

## 5.9.3 Checked findings

| Draft problem | Correct source position | Correction |
| --- | --- | --- |
| Old 10 am–noon session | 11 am–1 pm IST | Update the invitation time |
| 12 places claimed available | Capacity 12; known active tickets 10 | State the limit without that false availability claim |
| Fee INR 450 | INR 499 per ticket | Replace the incorrect fee |
| Laptop and certificate promises | Own laptop; no loan devices; certificates not supplied | Restore the laptop policy and remove certificate promise |
| All fees received | Eight Paid tickets; INR 3,992 receipts | Label full-capacity fees as a projection |
| Questions after 1 pm | Session ends at 1 pm | Use 12.45–1 pm for questions |

The correct source position is not established by the number of documents that repeat it. If three drafts carry the old time, all three are wrong. Resolve the mismatch using the approved source and change record, then recheck every affected document.

## 5.10.2 Checked revised calculations

Printed materials become 10 × 35 = INR 350. The other five budget lines stay unchanged. Total planned allowance becomes INR 4,450, which is INR 70 lower than v4. Full Paid-capacity fees become 10 × 499 = INR 4,990. The projected balance is INR 540.

Nine Paid tickets would provide INR 4,491, exceeding the revised planned allowance by INR 41. Eight provide INR 3,992, below it by INR 458. The revised minimum is therefore nine Paid tickets. Recorded receipts are still INR 3,992, and the two Pending-ticket amount is still INR 998. Lowering capacity does not collect those pending fees.

## 5.10.3 A possible revised invitation

```text
Subject: Everyday AI Workshop on 7 November
```

```text
Hello,
The Everyday AI Workshop is on Saturday 7 November 2026, from 11 am to 1 pm IST, at Learning Room, Adyar, Chennai. It offers adults new to AI practice with prompts, follow-ups, and checking short drafts.
The fee is INR 499 per ticket. Capacity is now 10 participants, and all 10 places are allocated. Printed learning sheets are included. Participants bring their own laptop; loan devices are not available.
For enquiries, email learn@example.com.
Best,
Vishva
```

The revised document is now an event information message for enquiries rather than an invitation suggesting available places. Its filename may still identify the invitation document within the pack, but its wording must reflect the allocation decision. Do not invent a waiting-list policy to create a new booking option.

## 5.11.3 A possible README

```text
Everyday AI Workshop communication pack v5
Current brief: Master Brief v5, 6 November 2026
```

```text
Current event facts: 7 November 2026, 11 am–1 pm IST, Learning Room, Adyar, Chennai; arrival 10.40 am. Fee INR 499 per ticket. Capacity 10, with all places allocated to eight Paid and two Pending tickets. Printed sheets included; bring own laptop; no loan devices.
```

```text
Checked planning figures: allowance INR 4,450; full Paid-capacity fees INR 4,990; projected balance INR 540; minimum nine Paid tickets to cover the allowance. Recorded paid receipts INR 3,992. Pending amount INR 998 is not collected.
```

```text
Evidence: Raw v1 is unchanged. D07 is excluded from the working analysis as an exact duplicate. R010 is Cancelled under Vishva’s 6 November decision.
```

```text
Status: internal review complete for the worked drafts. The attendance reminder is on Hold until Vishva confirms the exact street address and accessible entrance route. Shardha must review the updated joining details and record a release decision against the current pack.
```

```text
Open policies: refund and payment instructions are not supplied. The FAQ does not make a promise about them. No certificates or refreshments have been added.
```

## 5.12.1 Answer guide after your attempt

At capacity 10, planned allowance is 1,500 + 1,800 + 200 + 300 + 200 = INR 4,000. Full Paid-capacity fees are 10 × 650 = INR 6,500, giving a projected balance of INR 2,500. Six Paid tickets provide INR 3,900, below the allowance; seven provide INR 4,550, so the minimum is seven. Recorded receipts are 4 × 650 = INR 2,600. Two Pending tickets represent INR 1,300 not collected. Known allocation is six tickets.

At capacity eight, sign-in sheets cost 8 × 20 = INR 160. Planned allowance becomes INR 3,960. Full Paid-capacity fees are INR 5,200, and projected balance is INR 1,240. The minimum remains seven Paid tickets because six still provide only INR 3,900. Recorded receipts and Pending amounts do not change. Six tickets are allocated within capacity eight; do not describe all eight places as available.

The four presentation parts total 50 + 10 + 45 + 15 = 120 minutes and end at 4 pm. Every mention of capacity and the sheet quantity should use the approved revision. The reminder remains a draft awaiting complete joining details, and unknown policies must not become promises.

## 5.13.1 Questions to answer in your own words

## 5.13.2 Answer guide
