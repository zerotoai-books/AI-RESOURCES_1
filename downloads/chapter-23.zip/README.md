# Chapter 23 Turn a source document into a deck

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 23.1.1 Your task

Step 1  Copy the event date, time, venue and capacity.

Step 2  Copy the three cost lines with quantities and unit prices.

Step 3  Copy the six agenda durations.

Step 4  Record the requested spending limit and pending approval.

Step 5  Keep actual spending and registration counts marked as not supplied.



## 23.2.1 Your task

Step 1  Decide whether you want a source-based rewrite or layout preservation.

Step 2  State that decision in the instruction.

Step 3  Ask for five cards and inspect the proposed outline.

Step 4  Compare the imported or generated content with the source.

Step 5  Record the route and file or text used.



## 23.3.1 Your task

Step 1  Multiply each quantity by its unit price.

Step 2  Add the three line totals once.

Step 3  Subtract the planned cost from the budget limit.

Step 4  Label the amounts as planning estimates in INR.

Step 5  Keep remaining budget separate from profit and collected revenue.



## 23.4.1 Your task

Step 1  Add the durations: 5, 10, 15, 15, 10 and 5 minutes.

Step 2  Check that the blocks run consecutively from 11 am to noon.

Step 3  Decide which details belong on the card and which can go in notes.

Step 4  Keep the three main practice tasks visible.

Step 5  Inspect the agenda again after an AI edit.



## 23.5.1 Your task

Step 1  List the essential event, agenda and budget claims.

Step 2  Record the source ID and deck card.

Step 3  Inspect the claim in presentation view.

Step 4  Mark missing or unsupported content for correction.

Step 5  Repeat the affected check after revising.

