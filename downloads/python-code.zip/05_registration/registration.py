import csv
import re
import sqlite3
from contextlib import contextmanager
from datetime import date
from pathlib import Path

FIELDS = ["RegistrationID", "Alias", "RegistrationDate",
          "Category", "Status"]
CATEGORIES = ("Community", "Workplace")
STATUSES = ("Confirmed", "Waitlisted", "Cancelled", "Needs review")


def label(value, choices):
    if not isinstance(value, str):
        raise ValueError("Missing label")
    for choice in choices:
        if value.strip().casefold() == choice.casefold():
            return choice
    raise ValueError("Unknown label: " + value)


def record_id(value):
    if not isinstance(value, str):
        raise ValueError("Missing ID")
    value = value.strip()
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{1,11}", value):
        raise ValueError("Invalid ID")
    return value.upper()


def clean(row):
    if set(row) != set(FIELDS):
        raise ValueError("Wrong record fields")
    ident = record_id(row["RegistrationID"])
    alias = row["Alias"]
    if not isinstance(alias, str):
        raise ValueError("Missing alias")
    alias = alias.strip()
    if not 1 <= len(alias) <= 40 or any(
        ord(c) < 32 or ord(c) == 127 for c in alias
    ):
        raise ValueError("Invalid alias")
    day = row["RegistrationDate"]
    if not isinstance(day, str) or not re.fullmatch(
        r"[0-9]{4}-[0-9]{2}-[0-9]{2}", day
    ):
        raise ValueError("Use YYYY-MM-DD")
    date.fromisoformat(day)
    category = label(row["Category"], CATEGORIES)
    status = label(row["Status"], STATUSES)
    return (ident, alias, day, category, status)


class Store:
    @classmethod
    def create(cls, path, capacity=12):
        if type(capacity) is not int or not 1 <= capacity <= 40:
            raise ValueError("Capacity must be 1 to 40")
        path = Path(path)
        with path.open("x"):
            pass
        db = sqlite3.connect(path, isolation_level=None)
        try:
            db.execute("BEGIN IMMEDIATE")
            db.execute("CREATE TABLE settings "
                       "(capacity INTEGER, version INTEGER)")
            db.execute("INSERT INTO settings VALUES (?, 1)",
                       (capacity,))
            db.execute("CREATE TABLE registrations "
                       "(RegistrationID TEXT PRIMARY KEY, "
                       "Alias TEXT, RegistrationDate TEXT, "
                       "Category TEXT, Status TEXT)")
            db.commit()
        except Exception:
            db.rollback()
            db.close()
            path.unlink()
            raise
        else:
            db.close()

    def __init__(self, path):
        path = Path(path).resolve()
        # mode=rw refuses to create a missing database.
        self.db = sqlite3.connect(
            path.as_uri() + "?mode=rw", uri=True,
            isolation_level=None
        )
        try:
            row = self.db.execute(
                "SELECT capacity, version FROM settings"
            ).fetchone()
            if row is None or row[1] != 1:
                raise ValueError("Unsupported database")
            self.capacity = row[0]
            if type(self.capacity) is not int or not (
                1 <= self.capacity <= 40
            ):
                raise ValueError("Invalid saved capacity")
        except Exception:
            self.db.close()
            raise

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.db.close()

    @contextmanager
    def write(self):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            yield
            self.db.commit()
        except Exception:
            self.db.rollback()
            raise

    def confirmed(self):
        return self.db.execute(
            "SELECT COUNT(*) FROM registrations "
            "WHERE Status = ?", ("Confirmed",)
        ).fetchone()[0]

    def _insert(self, row):
        values = clean(row)
        if values[4] == "Confirmed" and (
            self.confirmed() >= self.capacity
        ):
            raise ValueError("Capacity is full")
        self.db.execute(
            "INSERT INTO registrations VALUES (?, ?, ?, ?, ?)",
            values
        )

    def add(self, ident, alias, day, category, status):
        values = (ident, alias, day, category, status)
        with self.write():
            self._insert(dict(zip(FIELDS, values)))

    def import_csv(self, filename):
        with open(filename, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f, strict=True)
            if reader.fieldnames != FIELDS:
                raise ValueError("Wrong CSV header or order")
            with self.write():
                for row in reader:
                    self._insert(row)

    def set_status(self, ident, status):
        ident = record_id(ident)
        status = label(status, STATUSES)
        with self.write():
            row = self.db.execute(
                "SELECT Status FROM registrations "
                "WHERE RegistrationID = ?", (ident,)
            ).fetchone()
            if row is None:
                raise ValueError("Unknown ID")
            if status == "Confirmed" and row[0] != status:
                if self.confirmed() >= self.capacity:
                    raise ValueError("Capacity is full")
            self.db.execute(
                "UPDATE registrations SET Status = ? "
                "WHERE RegistrationID = ?", (status, ident)
            )

    def rows(self):
        rows = self.db.execute(
            "SELECT * FROM registrations ORDER BY RegistrationID"
        ).fetchall()
        return [dict(zip(FIELDS, row)) for row in rows]

    def summary(self):
        rows = self.rows()
        counts = {s: sum(r["Status"] == s for r in rows)
                  for s in STATUSES}
        confirmed = counts["Confirmed"]
        return {"capacity": self.capacity, "confirmed": confirmed,
                "available": self.capacity - confirmed,
                "total_records": len(rows), "statuses": counts}
