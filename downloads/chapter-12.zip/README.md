# Chapter 12 Narrow a research question

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 12.3.1 Your task

Step 1  Name the team and the three-month period.

Step 2  Include the registration capacity and CSV requirement.

Step 3  Include the account requirement, organiser count and budget.

Step 4  State that only supplied fictional sources may be used.

Step 5  Ask for unknowns as well as a proposed recommendation.



## 12.4.1 Your task

Step 1  Save both prompts and replies.

Step 2  Compare how much of each answer addresses the eligibility question.

Step 3  Open the official resize page in the second answer.

Step 4  Note whether the answer distinguishes automatic resizing from rebuilding a design.

Step 5  Record the date of your check.



## 12.5.1 Your task

Step 1  List the five workflow requirements and the budget.

Step 2  Separate the three-month purchase period from the monthly price.

Step 3  Propose one useful preference, such as a clearer first-use workflow.

Step 4  Identify evidence needed to evaluate that preference.



## 12.6.1 Your task

Step 1  Remove the assumed winner.

Step 2  Ask for evidence for and against each eligible option.

Step 3  Require the same criteria for every option.

Step 4  Ask the tool to identify missing facts.

Step 5  Keep a record of the rewritten question.



## 12.7.1 Your task

Step 1  Name the decision that the research should support.

Step 2  Require current primary evidence for every mandatory criterion.

Step 3  Set aside unsupported claims instead of searching indefinitely.

Step 4  List the practical tests still needed.

Step 5  Write a findings note of no more than 120 words.

