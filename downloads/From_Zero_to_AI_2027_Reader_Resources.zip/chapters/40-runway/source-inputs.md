# Chapter 40 source inputs

These are fictional teaching sources from the current printed manuscript. Use the exact source ID and scope named in the exercise. Deliberate defects and old versions remain unchanged.

## Runway

## Official references for the Runway chapters

Product guidance was checked on 15 October 2026. The 2027 label identifies the book edition. Use the current official guide and account notices when controls, access or model support differ. The exercises, prompts, scripts and worked answers are original teaching examples.

No signed in product session, generated media, measured recording or video playback is supplied. Complete those steps in your own account where access permits. Do not treat a planning target or worked answer as an observed generation result.

## R1 Runway Creating with Gen 4.5

Supported modes, duration and model access.

https://help.runwayml.com/hc/en-us/articles/46974685288467-Creating-with-Gen-4-5

## R2 Runway Text to Video Prompting Guide

Visual and motion descriptions.

https://help.runwayml.com/hc/en-us/articles/42460036199443-Text-to-Video-Prompting-Guide

## R3 Runway Camera Terms Prompts and Examples

Camera language and static shot guidance.

https://help.runwayml.com/hc/en-us/articles/47313504791059-Camera-Terms-Prompts-Examples

## R4 Runway Image to Video Prompting Guide

Reference image, motion prompts and frame continuation.

https://help.runwayml.com/hc/en-us/articles/48324313115155-Image-to-Video-Prompting-Guide

## Practice sources printed for offline use

These printed briefs supply the exercise facts. Type the text needed for your task or save your own working file. All events, records and reviewer names are fictional. Preserve the stated scope when an update applies only to one exercise.

## B0 Main Workshop

B0 Main workshop baseline version 1 dated 15 October 2026

This is a fictional teaching event. Event name: Plan Your First Workshop. Date: Saturday 21 November 2026. Time: 11 am to noon IST, meaning Indian Standard Time. Venue: Learning Room, Adyar, Chennai. Audience: adult beginners. Attendance is free. Maximum capacity is twelve; this does not state live availability.

The activity is in English and uses paper. Printed materials are provided. No phone or laptop is needed. Booking contact: learn@example.com, a practice placeholder. Step free access is confirmed for this fictional venue, but specific needs should be discussed through the contact route. Do not promise universal suitability.

Certificates, refreshments, parking, transport, loan devices and sponsors are not confirmed. Do not invent them. Any image you create for these exercises is illustrative, not a photograph establishing the fictional venue. Shardha is a fictional reviewer; approval is Pending. No real booking, message or public release is authorised by this practice brief.

## B1 Photography

B1 Separate Photography challenge version 1 dated 15 October 2026

Event: First Steps in Photography. Saturday 28 November 2026, 3 pm to 4.30 pm IST. Venue: Studio Room, Kochi. Audience: adults. Capacity: eight. Fee: INR 650 per person. Participants bring their own camera or camera phone. Booking contact: photos@example.com, a practice placeholder.

Access arrangements are unknown. Do not promise food, certificates, parking, equipment loans or confirmed attendance. This ninety minute event is separate from B0. All details are fictional. Any generated imagery is illustrative. Approval is Pending.
