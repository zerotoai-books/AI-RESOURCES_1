# Chapter 15 Build a research dossier for a decision

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 15.3.1 Your task

Step 1  Keep the 24-record requirement intact.

Step 2  Include English, desktop use, CSV and no participant accounts.

Step 3  Check that one organiser is included.

Step 4  Calculate the total purchase cost for three months.

Step 5  Keep practical quality questions in a separate trial section.



## 15.4.1 Your task

Step 1  Copy the mandatory R0 requirements into comparison fields.

Step 2  Read F2 to F5 and enter each documented feature, cost and term.

Step 3  Put the source ID beside every supported entry and mark untested qualities separately.

Step 4  Assess all mandatory requirements before comparing preference or cost.



## 15.5.1 Your task

Step 1  Collect the checked brief, source log, matrix and calculations.

Step 2  Assemble a dossier with the recommendation, eligible alternative and unresolved questions.

Step 3  List proposed trial tasks and preserve the evidence for every factual claim.

Step 4  Add a decision record with approval Pending and verify that no proposed test is called complete.



## 15.6.1 Your task

Step 1  Open the public form in the workflow available for testing.

Step 2  Check whether it asks the participant to create an account.

Step 3  Submit the dummy records using the available fields.

Step 4  Export the records and compare the values with the entries.

Step 5  Record missing fields, altered text or extra steps.



## 15.7.1 Your task

Step 1  Make three separate copies of the baseline comparison.

Step 2  Change only B to INR 400 per month in the first and recalculate the full term.

Step 3  Change only B to INR 450 per month in the second and test the budget cap.

Step 4  Change only the record requirement to 110 in the third and reassess every option.

Step 5  Explain the next evidence or decision needed in each separate case.

