# Chapter 3 Work with documents and small datasets

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 3.6 Exercise 1 Confirm the sources before extracting facts

Step 1  Copy Source A into a new chat with its title, version, and A1–A10 labels.

Step 2  Copy Source B as the table or CSV, including the header and all 12 rows.

Step 3  Ask for the source inventory below before asking for a summary.

Step 4  Compare the reported versions, row count, and column names with what you supplied.

Step 5  Save any access problem or import correction in your practice log.



## 3.7 Exercise 2 Extract facts and preserve the gaps

Step 1  Read all labelled sections of Source A.

Step 2  Request a fact table with a source section for every value.

Step 3  Compare each row with the source and correct both the value and its locator.

Step 4  List missing policies separately without filling them from general knowledge.



## 3.8 Exercise 3 Inspect data quality before adding totals

Step 1  Find repeated OrderIDs yourself. Compare every field in the repeated rows.

Step 2  Identify blank cells that affect the requested calculations.

Step 3  Check that quantities and unit prices can be read as numbers.

Step 4  Write the duplicate and blank-status rules from A7 and A8 in your log.

Step 5  Ask for the review below and compare it with your manual inspection.



## 3.9 Exercise 4 Calculate and reconcile the sales figures

Step 1  Use the documented working view with D04 retained once and D07 excluded.

Step 2  Calculate Quantity multiplied by UnitPriceINR for each retained row.

Step 3  Group orders, tickets and amounts by exact status under A7 to A9.

Step 4  Reconcile the counts and amounts before comparing with the generated result.



## 3.10 Exercise 5 Build evidence for a useful summary

Step 1  Gather the checked fact table and sales calculations.

Step 2  Create one row per claim with its source and any arithmetic.

Step 3  Label each claim Stated, Calculated or Unresolved.

Step 4  Check that duplicate handling and the unresolved ticket remain visible.



## 3.11.3 Check each sentence

Step 1  Point to A2, A3, or A4 for every event detail in the first paragraph.

Step 2  Recalculate the Paid and Pending ticket counts for the second paragraph.

Step 3  Check the duplicate statement against D04 and D07.

Step 4  Confirm that R010 has not been turned into an active or paid order.

Step 5  Check the proposed next action against A9, and review the word count.

Step 6  Save the corrected summary beside the final evidence table and raw inputs.



## 3.14.1 Questions to answer in your own words

Step 1  Why do 12 source rows not establish 12 different orders?

Step 2  Why do seven Paid orders represent eight Paid tickets?

Step 3  Why is INR 5,988 not a paid-receipt total?

Step 4  What changes when R010 is confirmed Cancelled?

Step 5  Why should the raw dataset remain unchanged?



## 3.14.2 Answer guide

Step 1  One source row repeats R004; the working analysis has 11 distinct orders.

Step 2  R002 contains two tickets, while the other Paid orders contain one each.

Step 3  The face value includes Pending, Cancelled, and unresolved records.

Step 4  Unresolved becomes zero and Cancelled becomes two; paid receipts and known active tickets stay unchanged.

Step 5  It preserves the original evidence and lets another reader reproduce and inspect the working decisions.

