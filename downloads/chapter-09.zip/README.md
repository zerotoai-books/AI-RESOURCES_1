# Chapter 9 Create a learning plan and assess progress

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 9.3 Exercise 1 Convert the syllabus into things you can assess

Step 1  Paste the syllabus and current source brief into a fresh chat.

Step 2  Ask for a task and a check for each unit.

Step 3  Compare the returned tasks with the unit definitions.

Step 4  Remove knowledge that is absent from the syllabus.

Step 5  Save the mapping as the basis for your study plan.



## 9.4 Exercise 2 Build the two week study plan

Step 1  Calculate 390 minutes yourself before asking Gemini.

Step 2  Paste the study windows and prompt below.

Step 3  Check that every date has the correct weekday.

Step 4  Add each session’s component minutes.

Step 5  Check that every unit appears in both initial learning and later practice.



## 9.5 Exercise 3 Create questions and verify the answer guide

Step 1  Ask Gemini for questions without answers first.

Step 2  Try answering them before requesting the key.

Step 3  Ask for answer locations and arithmetic working.

Step 4  Check each key answer against U1–U6 and A.

Step 5  Correct any answer that depends on a missing fact.



## 9.5.2 Six suitable questions

Step 1  Q1 U1: Rewrite “Understand workshop planning” as an outcome that can be checked.

Step 2  Q2 U2: A3 gives capacity 12 but no registration count. Can you calculate available places? Explain.

Step 3  Q3 U3: Calculate A6’s core planned total and remaining budget under A5.

Step 4  Q4 U4: An agenda allocates 20 minutes to lesson, 15 to practice, 20 to discussion, and 10 to assessment. Explain why it fails the 60-minute brief and give a corrected allocation with checking.

Step 5  Q5 U5: Write one access question with a proposed owner.

Step 6  Q6 U6: What should an error record contain after correcting an outdated session time?



## 9.6 Exercise 4 Use a score to identify specific gaps

Step 1  Score the answers yourself with the exact guide.

Step 2  Give a reason for each mark rather than an overall impression.

Step 3  Ask Gemini to score the same responses.

Step 4  Inspect any disagreement against the source and marking rule.

Step 5  Choose practice that addresses the failed tasks.



## 9.7 Exercise 5 Revise the plan after a missed session

Step 1  Mark Tuesday as missed; do not pretend it was completed.

Step 2  Identify U2 as the first gap.

Step 3  Move later tasks in a way that keeps the unit sequence sensible.

Step 4  Keep Saturday within 45 minutes.

Step 5  Recalculate the actual planned study total.



## 9.8 Exercise 6 Assess progress with a fresh case

Step 1  Read F, then cover the answer guide below.

Step 2  Answer the five questions yourself.

Step 3  Ask Gemini for feedback tied to F and the syllabus.

Step 4  Check the arithmetic independently.

Step 5  Record which skill improved and what still needs practice.



## 9.8.2 Fresh questions

Step 1  F1 Write one observable outcome for the paper session.

Step 2  F2 Calculate the planned budget and remaining amount.

Step 3  F3 Calculate available places and explain the waiting requests.

Step 4  F4 Does an agenda of eight minutes lesson, 15 practice, seven checking, 10 assessment, and five corrections fit? Show the total.

Step 5  F5 Can the remaining budget be called profit? Explain.



## 9.11 Check your understanding

Step 1  How many scheduled study minutes does the main two-week plan contain?

Step 2  Why should questions be attempted before viewing the key?

Step 3  What are the sample learner’s two main gaps?

Step 4  How many minutes remain after the missed Tuesday session?

Step 5  What evidence is more useful than a completed-session tick for judging progress?



## 9.11.1 Answer guide

Step 1  390: 195 minutes in each week.

Step 2  The attempt shows what you can do independently; reading the key first changes the task into practice.

Step 3  Including the reserve in costs and correcting an excessive agenda.

Step 4  360 scheduled minutes across the revised two weeks.

Step 5  A fresh answer, its checked working, and a source-based correction record.

