# Chapter 12 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 12.3.2 Worked scoped question

```text
For the fictional Learning Circle team, which of Options A, B and C meets the requirements for one English desktop registration workspace with at least 24 records, CSV export and public form submission without participant accounts, for one organiser over three months within INR 1200 including taxes? Use the supplied current guides and prices, identify outdated evidence and list the tests still needed before selection.
```

## 12.3.3 Answer guide

The question preserves every mandatory requirement. It asks about the full three-month purchase rather than only the lowest monthly price. It does not introduce payment processing, SMS reminders or an attendance guarantee. It also does not imply that the fictional findings apply to real services.

## 12.4.2 Worked findings note

```text
The broad question can return many Canva capabilities without answering the resize eligibility issue. The scoped question directs the search to a particular feature and source. On 14 October 2026 IST, the official Magic Resize help lists eligible plans and does not list Canva Free. A manual rebuild in a new design is a separate workflow, not proof of Free access to Magic Resize. [P6]
```

## 12.4.3 Answer guide

Your first answer need not be poor to demonstrate the difference. Compare relevance, not whether you prefer the writing style. If the feature has changed when you practise, record the current official result rather than repeating this dated example.

## 12.5.2 Worked criteria record

| Type | Criterion | How to check |
| --- | --- | --- |
| Mandatory | At least 24 records | Current plan guide |
| Mandatory | English and desktop browser | Current guide and trial |
| Mandatory | CSV export | Guide and test export |
| Mandatory | No participant account | Public form trial |
| Mandatory | Total at most INR 1200 for three months | Price and purchase term |
| Proposed preference | Organiser can complete the workflow easily | Timed practice task |

## 12.5.3 Answer guide

One organiser is sufficient, so an extra organiser account may be convenient but is not a reason to reject an otherwise compliant option. Data deletion timing remains a question to resolve, not a feature you may assume. A price within budget cannot compensate for a missing mandatory export feature.

## 12.6 Exercise 4 Improve a question without loading the answer

## 12.6.2 Worked revision note

```text
Changed “Why is B the best?” to a comparison against the same mandatory criteria. The revised question allows B to be rejected if a required workflow fails in testing. It also allows A to become preferable if the team's purchase-term preference changes.
```

## 12.6.3 Answer guide

A neutral question still permits a recommendation. It simply requires the recommendation to follow the evidence. You should not balance the wording by inventing a weakness for every option; report real limits in the supplied evidence and tested workflow.

## 12.7.2 Worked findings note

```text
The comparison is ready for review when all three options have been assessed against R0, current guides and prices are logged, the complete three-month cost is calculated and unsupported claims remain marked. The next step is a workflow trial of the proposed option using dummy registration data. Usability, accessibility and deletion timing still need checks. Research completion does not authorise a purchase or prove the software works for the team.
```

## 12.7.3 Answer guide

The note establishes what has to be known and what remains to be done. A valid stopping rule does not require five sources for every claim. A single current primary source may establish a feature; an important practical workflow still needs testing.

## 12.8.1 Answer guide

Your question must include 40 records, two organiser accounts, the supplied workflow requirements, a two-month need and a total budget of INR 900. X has only one organiser account. Z has a three-month minimum purchase, which matters even though the team needs only two months. A monthly-price comparison alone would miss both issues. Do not change the requested organiser count to make X eligible.
