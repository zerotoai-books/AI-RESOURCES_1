# Chapter 17 Improve hierarchy and readability

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 17.2.1 Your task
Word body block 3271

```text
Improve this poster's reading order without changing its words. Make the event title the most prominent text, group date and time, keep the venue readable and make the registration instruction easy to find. Preserve the exact contact and capacity. Use ordinary editable text where possible.
```

## 17.4.1 Your task
Word body block 3301

```text
Make the essential text easier to read. Keep the email on a plain background, align related details and remove decorative elements that compete with the event title. Preserve C1 exactly. Do not describe the design as fully accessible merely because its contrast improves.
```

## 17.6.1 Your task
Word body block 3328

```text
Using my recorded comparison, write an 80 to 120 word rationale for the selected poster. Explain the specific hierarchy, spacing and reading improvements. Keep any remaining issue visible and do not invent user-test results.
```
