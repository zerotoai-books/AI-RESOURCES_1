# Start here

1. Extract the ZIP. Work outside the ZIP preview.
2. Select your numbered chapter in chapters/. Open its README.md, source-inputs.md and prompts.md. Keep the source version beside your prompt.
3. For tables, use that chapter's tables/ CSVs. They preserve printed table cells. Keep the XLSX files for Excel exercises because CSV does not preserve native workbook features.
4. Use a separate working copy. Supply actual source text or an attachment to the AI tool; mentioning a filename does not attach it.
5. Compare with answer-guide.md after attempting the task. Record actual results in Reader_Test_Record.csv or templates/Practice_Log.csv.
6. For Python, read the specific code folder README and run the named tests. The Chapter 33 untouched starter is supposed to fail. Keep it separate from passing suites.
7. The browser calculator opens locally. Cloud AI services need internet and eligible accounts. Downloading files does not provide paid service access.
