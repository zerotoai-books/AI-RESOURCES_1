# Chapter 30 Build a budget and registration tracker

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 30.1.2 Worked input layout
Word body block 4488

```text
Plan a Tracker sheet using E0. Use B5 for capacity, B6 for budget limit, B7 for materials per seat, B8 for printing per seat and B9 for the room estimate. Use CleanRegistrationTable for booking measures. Plan costs for full capacity. Show confirmed seats, available seats, seats over capacity, capacity used, unresolved records, cost lines, remaining budget and a category chart. Keep the raw source unchanged. Show the plan before editing.
```

## 30.3.1 Your task
Word body block 4515

```text
Add data validation to the tracker and cleaned registration table. Capacity accepts whole numbers 1 to 40. Budget and prices accept nonnegative numbers. Category accepts Community or Workplace. Status accepts Confirmed, Waitlisted, Cancelled or Needs review. Seats is one per record. Add conditional formatting for relevant exceptions without changing source values. Keep missing-input messages and unresolved records visible.
```
