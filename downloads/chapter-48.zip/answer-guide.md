# Chapter 48 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 48.2.2 Worked answer guide

The structure helps a reviewer find a factual problem without replaying an unidentified long file. The Activity part must not imply that the event is taught in a second language merely because a later promotional translation exists. The Booking part should preserve the full time range and timezone.

Check your work. The audio piece has no guaranteed length before generation. Record a target as a planning goal and measure each generated part later.

## 48.3.2 Worked answer guide

The project record might list Welcome A, Activity A and Booking A with the same voice and model. If a particular paragraph needs a slower delivery, record that change explicitly. Consistency is an editorial target; even unchanged settings can produce variable delivery, so the joins still need listening.

Check your work. Check the current generation and export notices. An export may require generation of unrendered text; do not assume every export is free of additional usage.

## 48.4.2 Worked answer guide

A hypothetical clipped final syllable at the end of Welcome needs repair before export. A long silent gap may need trimming, while a short breath may sound natural. The correct decision depends on the actual recording. Do not remove every pause simply to make the waveform compact.

Check your work. Headphones can reveal a join that a phone speaker hides, and a phone speaker can reveal that quiet words are hard to hear. Use both where available and record the actual checks.

## 48.5.2 Worked answer guide

The revision explains the learning sequence more directly without adding equipment, food or certificates. Welcome and Booking should remain unchanged unless the tool regenerates them as part of the export. Record what was actually regenerated, then compare the current candidate with the revised script.

Check your work. A paragraph edit can change the project’s total duration. Re measure the assembled version and update the cue sheet; do not carry forward the earlier total.

## 48.6.2 Worked answer guide

Studio documents MP3 and WAV exports and plan dependent quality. [E4] A WAV converted from compressed source does not recover detail that was not present. Choose according to the review or editing need and record the actual output properties. The chapter does not require buying a different plan.

Check your work. Exporting is not publication. Keep review access private within your own practice workflow unless a separate sharing task is explicitly intended.

## 48.7.1 Answer guide after your attempt

The final piece keeps B1 logistics and fee. A suitable revised paragraph says “Please bring your own camera or camera phone for the practice activity.” It does not promise loan devices. The handover identifies which part changed, the regenerated take and rechecked joins. Actual duration is measured after assembly rather than calculated from a planning target.
