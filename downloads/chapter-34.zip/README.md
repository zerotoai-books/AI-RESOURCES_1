# Chapter 34 Add tests and review dependencies

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 34.1.1 Your task

Step 1  Include the baseline and independent quote from K1.

Step 2  Check valid quantity boundaries and valid discount boundaries.

Step 3  Include invalid quantity, price and discount inputs.

Step 4  Include a non-finite price and the small rounding example.

Step 5  State why each group could catch a different defect.



## 34.2.1 Your task

Step 1  Create test_my_calculator.py without overwriting the answer reference.

Step 2  Add a TestCase class with test methods.

Step 3  Assert the baseline's three separate amounts.

Step 4  Add a rejection test for fractional quantity.

Step 5  Add the rounding case with the correct total and discount.



## 34.3.1 Your task

Step 1  Save the source and test files.

Step 2  Run test discovery with verbose output.

Step 3  Inspect the first failure or error before making changes.

Step 4  Check that the imported calculator is your current local file.

Step 5  Fix the program or an incorrectly specified test based on K1, then rerun.



## 34.4.1 Your task

Step 1  Run a valid calculator command as a separate process.

Step 2  Capture its output and exit code.

Step 3  Run a fractional quantity and inspect its error route.

Step 4  Import calculator without calling main and check for unintended printing.

Step 5  Confirm that helper refactoring preserves these behaviors.



## 34.5.1 Your task

Step 1  Read each import and distinguish a local module from the standard library.

Step 2  Confirm that no third-party package is required by the worked code.

Step 3  Document the interpreter requirement and actual test command.

Step 4  Keep secrets and generated personal data out of any shared project copy.

Step 5  Record remaining checks, including the learner's editor and Copilot experience.

