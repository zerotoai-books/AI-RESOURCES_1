# Chapter 48 Prepare and revise a multiscene voiceover

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 48.2 Exercise 1 Divide the script by purpose

Step 1  Read all three supplied parts and identify their jobs.

Step 2  Keep event facts consistent with B0.

Step 3  Copy spoken paragraphs separately from the part headings.



## 48.3 Exercise 2 Create a consistent project baseline

Step 1  Create a Studio project or a local set of three clearly named takes.

Step 2  Apply the same initial voice and supported settings to the three parts.

Step 3  Record the script version and generate one part at a time if practical.



## 48.4 Exercise 3 Review the sequence and joins

Step 1  Listen to each part against its script.

Step 2  Play the end of one part and the start of the next together.

Step 3  Record level, pace, silence, repeated words and missing endings.



## 48.5 Exercise 4 Revise one paragraph and check its impact

Step 1  Save the original project or take set as version one.

Step 2  Replace only the Activity paragraph with the supplied revision.

Step 3  Regenerate the affected part and recheck both neighbouring joins.



## 48.6 Exercise 5 Export a review copy and preserve the source

Step 1  Export the complete project or assemble the three parts in order.

Step 2  Open the downloaded file separately and listen from beginning to end.

Step 3  Save the source script, part list, settings and measured timing with it.

