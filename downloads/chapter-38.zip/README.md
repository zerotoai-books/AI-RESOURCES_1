# Chapter 38 Animate a reference image

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 38.2 Exercise 1 Inspect the reference and its permission record

Step 1  Open the PNG at full size and identify the objects and empty title space.

Step 2  Read the asset note and record the original filename.

Step 3  Reject any replacement image whose permission, identity consent or source is unclear.



## 38.3 Exercise 2 Check the crop before generating

Step 1  Choose Image to Video and attach the PNG itself.

Step 2  Select a landscape ratio matching the source if offered.

Step 3  Preview any crop and verify that the notebook and pencil remain fully useful.



## 38.4 Exercise 3 Prompt for motion rather than redescribing everything

Step 1  Choose a subtle camera movement as the only requested motion.

Step 2  Keep the illustrated objects still.

Step 3  Set a five second duration where supported and record the displayed charge.



## 38.5 Exercise 4 Inspect frames for drift

Step 1  Inspect the first frame, the midpoint and the final frame.

Step 2  Watch the whole clip for sudden changes between those sample points.

Step 3  Record whether pencil count, notebook outline and style remain acceptable.



## 38.6 Exercise 5 Revise the input or prompt deliberately

Step 1  Select the largest observed defect.

Step 2  Choose one input change and predict its intended effect.

Step 3  Save the new version with a distinct name and compare it with the baseline.

