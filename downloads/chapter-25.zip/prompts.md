# Chapter 25 Deliver a complete workshop pitch

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 25.1.1 Your task
Word body block 4028

```text
Using G0, G1 and G2, prepare a five-card organiser pitch plan. The decision is whether to approve the workshop plan and a spending limit of INR 1500. Include the audience, three practice tasks, 60-minute agenda, full-capacity estimates and next actions. Keep approval pending. Allow no more than four minutes for the spoken pitch, including transitions and excluding questions.
```

## 25.3.1 Your task
Word body block 4057

```text
Draft speaker notes for the five checked pitch cards. Use only G0 and G1. Explain the audience, activities, agenda, estimated costs and approval request in plain language. Do not add bookings, supplier quotes, certificates or guaranteed outcomes. Keep the spoken pitch suitable for a four-minute rehearsal, which I will time myself.
```

## 25.5.1 Your task
Word body block 4093

```text
Apply the complete G3 change to the proposal. Capacity is now 10. Materials are 10 times INR 25; printing is 10 times INR 15; the room stays INR 600 and the limit stays INR 1500. Update every affected card and speaker note, but preserve the date, 11 am to noon IST, venue, audience and free attendance. Keep version 3 archived and leave export review and rehearsal pending until recorded.
```
