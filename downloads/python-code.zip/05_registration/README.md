# 05_registration

Printed reference recovered without code changes. Python 3.12 or later and the standard library. The review reran it on 3.12.14.

Use a new database name for each attempt. Run `python app.py --db demo.sqlite3 init --capacity 12`, then `python app.py --db demo.sqlite3 import-csv demo_registrations.csv`, then `python app.py --db demo.sqlite3 summary`. Expect eleven records, eight confirmed and four available. Run `python -m unittest -v test_registration` for eight methods. Read Appendix A6 for full-capacity, rollback and independent scenarios. This CLI uses --db before the subcommand.

Keep the baseline unchanged and use a working copy. This is a local teaching example.
