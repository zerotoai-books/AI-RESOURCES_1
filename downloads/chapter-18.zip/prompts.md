# Chapter 18 Use images and edit individual elements

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 18.2.1 Your task
Word body block 3363

```text
Create a simple flat illustration of paper planning sheets and two pencils on a clean pale background. Use navy and amber accents, generous empty space and no words, letters, logos or people. It will illustrate a fictional paper-based beginner workshop, not an actual venue or past event. Keep the objects easy to recognise at a small size.
```

## 18.3.1 Your task
Word body block 3376

```text
Add this illustrative paper-and-pencils image without changing C1. Keep event text editable and place it so the title, schedule, venue and registration instruction remain easy to read. Do not stretch the illustration or describe it as a photograph of our event.
```

## 18.4.1 Your task
Word body block 3387

```text
Make the title more prominent and align the date and venue text. Keep every word unchanged. If a requested edit affects a grouped element or is unavailable, identify that limitation so I can make the adjustment manually.
```

## 18.5.1 Your task
Word body block 3406

```text
Create an asset record from the details I supply. Keep my own illustration, Canva library content and generated content as different origins. Do not claim exclusive rights, commercial permission or approval without evidence from the relevant current terms and asset information.
```
