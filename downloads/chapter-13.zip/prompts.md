# Chapter 13 Compare evidence and resolve disagreement

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 13.3.1 Your task
Word body block 2876

```text
Using only F1 to F5, make a source log. Separate publication date from effective period. Identify which plan each document describes and which questions it does not answer. Use printed source IDs and headings as locations for these fictional teaching sources.
```

## 13.4.1 Your task
Word body block 2895

```text
Resolve this source disagreement for the fictional case dated 14 October 2026 IST. F1 offered CSV in Free through 31 August; F2 says Free has no CSV from 1 September. Explain the dates and plan scope. Do not say F1 was always wrong.
```

## 13.5.1 Your task
Word body block 2907

```text
Assess these four claims using F2 to F5 only. Return a claim-by-claim result with the source ID and reason. Do not infer that an unspecified feature is absent, and do not invent a deletion policy.
```

## 13.6.1 Your task
Word body block 2919

```text
Find current official Canva evidence about eligibility for Magic Resize. I mean changing an existing design's canvas dimensions. Separate that feature from manually creating another design or resizing an element. State the check date and link the relevant help page.
```

## 13.7.1 Your task
Word body block 2935

```text
Using R0 and F2 to F5, list remaining questions before a software decision. For each, identify the evidence missing and propose a practical next action. Keep product features already established separate from untested workflow quality.
```
