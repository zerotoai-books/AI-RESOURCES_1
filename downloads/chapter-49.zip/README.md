# Chapter 49 Create and check a second language version

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 49.2 Exercise 1 Define the translation brief

Step 1  List the event facts that must remain unchanged.

Step 2  State that the workshop activity remains in English.

Step 3  Identify names and contacts that should retain their literal written form.



## 49.3 Exercise 2 Check the draft facts line by line

Step 1  Pair each required English fact with the corresponding Spanish phrase.

Step 2  Mark unclear or missing facts for review.

Step 3  Check numbers, timezone and the English teaching language explicitly.



## 49.4 Exercise 3 Prepare the spoken contact and names

Step 1  Keep learn@example.com exactly in the title or transcript.

Step 2  Use the draft spoken form “learn arroba example punto com” as a test candidate.

Step 3  Ask a listener to reconstruct the address from the audio.



## 49.5 Exercise 4 Generate a small multilingual test

Step 1  Confirm the target language in the current model guide and account.

Step 2  Record the selected voice, model and script version.

Step 3  Generate a short test and obtain language and factual listening notes.



## 49.6 Exercise 5 Keep language versions aligned

Step 1  Save the English and Spanish scripts with matching event version labels.

Step 2  Record text review, audio review and approval separately.

Step 3  When any source fact changes, list every affected script, title and recording.

