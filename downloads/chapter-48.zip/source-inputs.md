# Chapter 48 source inputs

These are fictional teaching sources from the current printed manuscript. Use the exact source ID and scope named in the exercise. Deliberate defects and old versions remain unchanged.

## ElevenLabs

## Official references for the ElevenLabs chapters

Product guidance was checked on 15 October 2026. The 2027 label identifies the book edition. Use the current official guide and account notices when controls, access or model support differ. The exercises, prompts, scripts and worked answers are original teaching examples.

No signed in product session, generated media, measured recording or video playback is supplied. Complete those steps in your own account where access permits. Do not treat a planning target or worked answer as an observed generation result.

## E1 ElevenLabs Text to Speech product guide

Speech workflow and model dependent controls.

https://elevenlabs.io/docs/eleven-creative/playground/text-to-speech

## E2 ElevenLabs Models

Model families, language support and API route differences.

https://elevenlabs.io/docs/overview/models

## E3 ElevenLabs How do I use the Pronunciations Editor in Studio

Pronunciation rules and phoneme compatibility.

https://elevenlabs.io/docs/help-center/product/studio/studio/how-do-i-use-the-pronunciations-editor-in-studio

## E4 ElevenLabs ElevenCreative Studio overview

Project workflow, export options and plan dependent quality.

https://elevenlabs.io/docs/eleven-creative/products/studio

## Practice sources printed for offline use

These printed briefs supply the exercise facts. Type the text needed for your task or save your own working file. All events, records and reviewer names are fictional. Preserve the stated scope when an update applies only to one exercise.

## B0 Main Workshop

B0 Main workshop baseline version 1 dated 15 October 2026

This is a fictional teaching event. Event name: Plan Your First Workshop. Date: Saturday 21 November 2026. Time: 11 am to noon IST, meaning Indian Standard Time. Venue: Learning Room, Adyar, Chennai. Audience: adult beginners. Attendance is free. Maximum capacity is twelve; this does not state live availability.

The activity is in English and uses paper. Printed materials are provided. No phone or laptop is needed. Booking contact: learn@example.com, a practice placeholder. Step free access is confirmed for this fictional venue, but specific needs should be discussed through the contact route. Do not promise universal suitability.

Certificates, refreshments, parking, transport, loan devices and sponsors are not confirmed. Do not invent them. Any image you create for these exercises is illustrative, not a photograph establishing the fictional venue. Shardha is a fictional reviewer; approval is Pending. No real booking, message or public release is authorised by this practice brief.

## B1 Photography

B1 Separate Photography challenge version 1 dated 15 October 2026

Event: First Steps in Photography. Saturday 28 November 2026, 3 pm to 4.30 pm IST. Venue: Studio Room, Kochi. Audience: adults. Capacity: eight. Fee: INR 650 per person. Participants bring their own camera or camera phone. Booking contact: photos@example.com, a practice placeholder.

Access arrangements are unknown. Do not promise food, certificates, parking, equipment loans or confirmed attendance. This ninety minute event is separate from B0. All details are fictional. Any generated imagery is illustrative. Approval is Pending.

## B5 Voice Production

B5 Voice production brief version 1

Use B0 facts for the main English scripts. Spoken date: the twenty first of November, twenty twenty six. Spoken time: eleven a.m. to noon, Indian Standard Time. Written contact stays learn@example.com. Spoken contact test candidate: learn at example dot com. Review Adyar and Chennai with a knowledgeable listener.

Use an eligible stock or library voice with appropriate use rights. No person imitation or cloning is required. Record voice, model, settings, script version and measured duration. Do not invent generation, listening, native language approval or reviewer signoff. Use Not run and Pending when appropriate.

The short promotion targets thirty seconds to match the Runway edit, whose three eight second visual slots plus six second information card total thirty seconds. Measure actual audio before claiming fit. The longer three part English script is a separate piece with no fixed duration. Spanish is a separate promotional draft, not a change to the English teaching language. Proficient Spanish text and audio review remain Pending. Another target language needs its own supported model and competent reviewer.
