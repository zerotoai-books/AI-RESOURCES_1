# Chapter 40 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 40.2.2 Worked answer guide

The first assembly should run from zero to thirty seconds with no unintended gaps. A still image hold is an acceptable planned fallback if it is identified in the source log. Do not extend a short clip with an unexplained freeze that looks like a playback failure. The project frame rate should be chosen consistently with the actual sources and editor requirements.

Check your work. Play the full assembly, including the last frame. A duration displayed on an individual clip does not prove that the timeline has the intended total.

## 40.3.2 Worked answer guide

The date, time, place, audience, free attendance and contact match the brief. The address is a practice placeholder and must be replaced before any real promotion. Six seconds is the planned final card allowance; test whether the intended viewer can read it. If the card is crowded, distribute some facts over earlier title slots while preserving the full message.

Check your work. Do not add “twelve places left.” Capacity twelve is a maximum, not a live availability count. Do not invent certificates, refreshments or a booking deadline.

## 40.4.2 Worked answer guide

A silent version avoids an unnecessary soundtrack decision and remains useful on muted playback. If you later use ElevenLabs narration, record the chosen voice and applicable use rights, and listen to the final export. A generated voice is not a real participant endorsement. A narration estimate is not a measured recording length.

Check your work. Watch once muted and once with sound if present. Essential dates, booking information and audience details must remain understandable in the muted version.

## 40.5.2 Worked answer guide

A successful record identifies the actual exported file and measured properties. Do not claim an output is high definition solely because the project was set that way. If the final title is clipped or a font changed, correct the project and export again. Keep the first failed export separate so it cannot be confused with the reviewed version.

Check your work. The final check must use the exported file. A screenshot of the editor timeline is evidence of a plan, not proof of the delivered playback.

## 40.6.2 Worked answer guide

The package can be technically ready for review while approval is still pending. A learner should not fill in “approved” simply to make the checklist look complete. For real use, replace fictional contacts and confirm event details with the organiser. That confirmation is outside this controlled practice brief.

Check your work. Keep only one clearly named candidate in the handover folder and archive older exports. A reviewer should not have to guess which file is current.

## 40.7.1 Answer guide after your attempt

A correct title sheet says 28 November 2026, 3 to 4.30 pm IST, Studio Room, Kochi, INR 650, adults, capacity eight and bring your camera or camera phone. The contact is photos@example.com. The video plan totals twenty seconds. It does not inherit free attendance or the Chennai venue. Approval and playback checks remain pending until actually performed.
