from decimal import Decimal, ROUND_HALF_UP


def fixed_total(unit_price, quantity, discount_percent):
    subtotal = Decimal(unit_price) * int(quantity)
    discount = (
        subtotal * Decimal(discount_percent) / Decimal("100")
    ).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return subtotal - discount
