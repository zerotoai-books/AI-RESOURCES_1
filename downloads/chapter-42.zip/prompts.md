# Chapter 42 Write and revise a consistent document set

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 42.2.1 Useful prompt or direction
Word body block 5516

```text
Use plain English for adult beginners. Preserve dates, times, prices, contacts and conditions exactly from the current named brief. Do not invent benefits or availability. When a fact is missing, flag it. Before drafting, state which brief and update you are applying.
```

## 42.3.1 Useful prompt or direction
Word body block 5526

```text
Using B0 only, draft an invitation under 90 words, a reminder under 45 words and a three question FAQ. Include the date, time with IST, venue and contact in the invitation and reminder. Use FAQ questions about audience, materials and capacity. State the source version first.
```

## 42.4.1 Useful prompt or direction
Word body block 5536

```text
Apply B2 to the B0 document set. Capacity changes from 12 to 10 only. Keep all other facts. Produce version two of the invitation, reminder and FAQ, then list exactly what changed and what was checked but did not change.
```

## 42.5.1 Useful prompt or direction
Word body block 5546

```text
Audit version two against B0 plus B2. For each required fact, report the source value and each document’s value or Not mentioned. Distinguish contradiction from acceptable omission. Do not rewrite until the audit is complete.
```

## 42.6.1 Useful prompt or direction
Word body block 5556

```text
Handover cover note: Document set version two applies B0 plus B2. The only source change is capacity ten. Candidate files ___; audit ___; outstanding real world checks ___; approval Pending.
```
