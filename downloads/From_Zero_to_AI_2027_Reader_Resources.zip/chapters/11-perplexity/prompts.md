# Chapter 11 Ask a question and open the sources

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 11.3.1 Your task
Word body block 2687

```text
According to Canva's current official help, what file type is intended for printing a design? Give a short answer with a direct link to the relevant Canva help page. State any important qualification rather than guessing.
```

## 11.4.1 Your task
Word body block 2701

```text
Identify which cited page supports the print-format statement. Tell me the page title and section heading to inspect. Do not add information about my printer or my subscription.
```

## 11.5.1 Your task
Word body block 2714

```text
Review this draft against the source text I provide. Split combined claims into separate statements. Mark any guarantee the source does not support. Do not use outside knowledge to fill missing evidence.
```

## 11.6.1 Your task
Word body block 2728

```text
The cited page does not open for me. Find an accessible primary source for the same claim and link it directly. If you cannot find one, leave the claim unresolved. Do not describe an inaccessible page as verified.
```

## 11.7.1 Your task
Word body block 2739

```text
Using only my verified S1 note, write a short answer to my original question. Keep the qualification about checking printer requirements. Do not introduce a new feature or guarantee.
```
