# Chapter 36 Plan and generate a simple video shot

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 36.2.1 Useful prompt or direction
Word body block 5092

```text
Planning note: Create one five second illustrative shot of a paper planning activity for adult beginners. Keep the action simple. Event facts will be added as editable titles in the final edit.
```

## 36.3.1 Useful prompt or direction
Word body block 5102

```text
Planning checklist: model ___; mode ___; duration ___; ratio ___; displayed cost ___; maximum attempts two; output use classroom practice.
```

## 36.4.1 Useful prompt or direction
Word body block 5112

```text
Medium close shot of a plain notebook and a yellow pencil on a light wooden table. A gentle breeze lifts the corner of one blank page. Soft daylight, calm classroom illustration style. The camera remains still.
```

## 36.5.1 Useful prompt or direction
Word body block 5122

```text
Review direction: Check the notebook shape, pencil count, page motion, camera stability and any unexpected marks. Record what you actually see with a timestamp. Do not infer quality from the thumbnail.
```

## 36.6.1 Useful prompt or direction
Word body block 5132

```text
Handover note: This is an illustrative practice scene. Prompt and settings are in the log. Status ___; observed issue ___; next action ___. Event titles have not yet been added.
```
