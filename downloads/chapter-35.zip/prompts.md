# Chapter 35 Build a local workshop registration application

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 35.1.1 Your task
Word body block 4976

```text
Plan the local registration prototype from K2. Use Python 3.12 or later and the standard library only. Put the command interface in app.py and validation and SQLite operations in registration.py. Store capacity persistently, reject duplicate normalised IDs, enforce one seat per record and keep Needs review visible. Include tests for saving, reopening, full capacity and rollback. Do not create a web service or publish a repository.
```

## 35.2.1 Your task
Word body block 4997

```text
Implement the planned baseline operations from K2. Add init, import-csv, list and summary commands. Initialise only a new database, preserve saved capacity and refuse to replace an existing file. Import the CSV's exact schema and count only Confirmed seats against capacity. Use bound SQL parameters for record data. Show the commands to create and reopen a disposable baseline.
```

## 35.3.1 Your task
Word body block 5013

```text
Implement add and set-status using K2. Normalise and reject duplicate IDs without overwriting records. Check available capacity in the same database transaction as a new confirmation. Reject over-capacity additions or promotions while preserving previous records. Permit saving an already Confirmed record as Confirmed without counting another seat. Do not automatically promote a waitlisted record after cancellation.
```

## 35.4.1 Your task
Word body block 5035

```text
Implement atomic CSV import for K2. Use one transaction for the complete file. Reject a duplicate ID, bad field count, invalid label, impossible date, malformed CSV or capacity overflow, and roll back every new row from that import. Keep existing records unchanged. Bind input values to SQL placeholders rather than formatting them into SQL text.
```

## 35.5.1 Your task
Word body block 5051

```text
Prepare a handover note for this local teaching prototype. State its one-operator scope, setup commands, database location, saved capacity, input rules and test results actually observed. Keep R11 as Needs review. Separate automated Python checks from my own Copilot session, editor checks and human review. Do not claim deployment or production readiness.
```
