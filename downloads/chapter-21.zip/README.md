# Chapter 21 Generate a presentation from a short brief

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 21.2.1 Your task

Step 1  Read all of G0 before writing the prompt.

Step 2  Separate event facts from design preferences.

Step 3  Identify the action the reader should take after the deck.

Step 4  Specify five cards and editable text.

Step 5  State which unsupported claims must stay out.



## 21.3.1 Your task

Step 1  Count the proposed cards.

Step 2  Give each card one main purpose.

Step 3  Put audience and learning activities before the registration request.

Step 4  Keep all essential logistics somewhere in the deck.

Step 5  Revise the plan before allowing generation.



## 21.4.1 Your task

Step 1  Generate from the reviewed plan, or use the classic Paste route.

Step 2  If you use Paste, supply the five-card copy below and request preservation of the facts.

Step 3  Check the card count after creation.

Step 4  Make a small text edit and undo it to confirm editability.

Step 5  Save a clear draft name such as Workshop audience deck v3 draft.



## 21.5.1 Your task

Step 1  Compare each claim with G0.

Step 2  Mark a wrong fact separately from an unsupported promise.

Step 3  Restore missing year, time zone and venue.

Step 4  Replace the draft without adding a new promise.



## 21.6.1 Your task

Step 1  Find the event name without searching through body text.

Step 2  Read the date, time and venue at a comfortable viewing size.

Step 3  Find the exact registration contact.

Step 4  Check that every card has a clear purpose.

Step 5  Record remaining corrections and keep the editable source.

