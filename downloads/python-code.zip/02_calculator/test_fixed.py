import unittest
from decimal import Decimal
from calculator import quote

class RegressionTests(unittest.TestCase):
    def test_baseline(self):
        self.assertEqual(quote("25", "12", "10").total,
                         Decimal("270.00"))

    def test_independent(self):
        self.assertEqual(quote("40", "5", "15").total,
                         Decimal("170.00"))

if __name__ == "__main__":
    unittest.main()
