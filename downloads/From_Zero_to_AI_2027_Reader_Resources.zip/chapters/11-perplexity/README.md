# Chapter 11 Ask a question and open the sources

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 11.3.1 Your task

Step 1  Write this question in your research record before sending it.

Step 2  Submit the prompt below using the search available to you.

Step 3  Save the response and the source links it provides.

Step 4  Underline each factual statement that you plan to use.

Step 5  Do not correct the answer yet; keep the original for comparison.



## 11.4.1 Your task

Step 1  Check that the address belongs to canva.com.

Step 2  Read the page title and the relevant section, not only the search snippet.

Step 3  Identify the sentence or list entry supporting the print-format claim.

Step 4  Write a short paraphrase in your own words.

Step 5  Add the full URL, section heading and access date to S1.



## 11.5.1 Your task

Step 1  Name each claim separately.

Step 2  Mark supported, unsupported or unresolved.

Step 3  Remove a guarantee that the page does not establish.

Step 4  Explain one practical check you would still perform.



## 11.6.1 Your task

Step 1  Record the attempted URL and access problem.

Step 2  Search the publisher's official site for the same topic.

Step 3  If you find a replacement, open and inspect it.

Step 4  Keep the original failure in your log and add the replacement as a new source.

Step 5  If there is no replacement, mark the claim unresolved.



## 11.7.1 Your task

Step 1  Compare the final answer with the original AI reply.

Step 2  Record any claim you removed or narrowed.

Step 3  Count the answer's words, excluding the separate source log.

Step 4  Save the question, prompt, original answer, checked answer and evidence note.

