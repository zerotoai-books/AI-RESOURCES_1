# Chapter 8 Review supplied files and images

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 8.5.1 Prompt to try
Word body block 1984

```text
Before analysing these sources, list the file names you can access, their visible version labels, and the type of content in each. State any reading or image limitation. Do not infer facts from a file name alone. Do not summarise a source you cannot read.
```

## 8.5.3 If the source is not readable
Word body block 1992

```text
Source A did not upload successfully. I will paste its text below. Analyse that pasted text as Source A and say that your answer is based on the pasted version. Do not claim to have inspected the failed attachment.
```

## 8.6.1 Prompt to try
Word body block 2002

```text
Using only Source A version 1.1, extract the project name, date, current time and time zone, audience, capacity, venue status, budget cap, cost inputs, and open questions. Give the A paragraph label for each item. Distinguish planned inputs from actual spending. Do not infer registrations or revenue.
```

## 8.7.1 Prompt to try
Word body block 2027

```text
Describe Source B as an illustration. Transcribe the visible version, date, and time labels. Count the chair symbols and describe their arrangement. Identify the labelled door, screen, and table. Separate visible observations from unknown real-world facts. If a label or count is unclear, say so rather than guessing. Do not claim this proves a room booking or accessibility.
```

## 8.7.4 A useful follow-up
Word body block 2039

```text
You described the drawing as showing 12 registered attendees. Change that to 12 chair symbols arranged in three rows of four. Explain that actual registrations are not supplied in either source.
```

## 8.8.1 Prompt to try
Word body block 2048

```text
Compare Source A version 1.1 with Source B version 1.0. A is the current authority for project facts. List agreements, conflicts, and facts that one source does not establish. State the current session time, record the older image time, and identify which material needs updating. Do not treat a chair count as a booking count.
```

## 8.9.1 Prompt to try
Word body block 2069

```text
Audit the flawed summary against A and B. Identify every incorrect or unsupported claim, cite the relevant A label or visible B detail, and explain the repair. Then rewrite it under 100 words. Distinguish proposed venue, planned cost, remaining budget, attendance, and profit. Do not invent missing evidence.
```

## 8.10.1 Prompt to try
Word body block 2091

```text
Build an evidence sheet from our checked work. Include claim, source location, whether it is directly supplied or calculated, and any limitation. Then write a summary under 140 words using only supported or explicitly qualified claims. Include the time conflict and open arrangements. Do not treat your own previous answers as additional sources.
```

## 8.11.1 Extract with locations
Word body block 2114

```text
Extract [specified facts] from [source]. Give a source location for each. Separate supplied facts, calculations, observations, and unknowns. Do not fill gaps with plausible details.
```

## 8.11.2 Observe an image
Word body block 2116

```text
Describe only what is visible in [image]. Transcribe readable labels and state unclear details. Separate visual observations from real-world claims that the image cannot establish.
```

## 8.11.3 Compare versions
Word body block 2118

```text
Compare [sources and versions]. Use [stated authority rule]. Record agreements, conflicts, and unresolved points. Do not choose a current value when the evidence does not settle it.
```
