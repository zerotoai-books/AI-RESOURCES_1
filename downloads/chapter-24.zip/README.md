# Chapter 24 Review visuals and exported files

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 24.1.1 Your task

Step 1  State what the visual should help the reader understand.

Step 2  Use the drawing you made using Appendix A7, your own permitted image, or a text-only layout.

Step 3  If you use image generation, ask for decoration without embedded event wording.

Step 4  Add checked event words as editable text.

Step 5  Record the image source and inspect its use terms when relevant.



## 24.2.1 Your task

Step 1  Confirm room INR 600, materials INR 300 and printing INR 180.

Step 2  Check that the planned total is INR 1080.

Step 3  Check that remaining budget is INR 420.

Step 4  Inspect currency, scale and category labels.

Step 5  Confirm that no chart suggests revenue, profit or actual expenditure.



## 24.3.1 Your task

Step 1  Read each title and key point without zooming in.

Step 2  Check contact addresses, tables and agenda lines for cropping.

Step 3  Inspect text placed over images or low-contrast backgrounds.

Step 4  Check the five-card sequence and full source coverage.

Step 5  Make local corrections and inspect the affected card again.



## 24.4.1 Your task

Step 1  Open the export controls and inspect available options.

Step 2  Select the intended full deck and all five cards.

Step 3  Download the chosen format.

Step 4  Open the file outside Gamma and inspect every page or slide.

Step 5  Compare facts, cropping, layout and page count with presentation view.



## 24.5.1 Your task

Step 1  Open the PPTX outside Gamma.

Step 2  Select ordinary text and a table cell to test editability.

Step 3  Check fonts, line breaks and numerical labels.

Step 4  Inspect whether speaker notes are included before sharing a file.

Step 5  Record export format, version, coverage and remaining limitations.

