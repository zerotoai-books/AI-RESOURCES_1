# Chapter 38 Animate a reference image

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 38.2.1 Useful prompt or direction
Word body block 5230

```text
Asset record: Tabletop_Reference.png; my own tabletop drawing made using Appendix A7; illustrative use only; creation date ___; editor or drawing method ___; changes made ___; reviewer ___.
```

## 38.3.1 Useful prompt or direction
Word body block 5240

```text
Setup direction: Use my drawing from Appendix A7 as the starting image. Preserve the notebook and pencil within the chosen crop. Record any crop before generating; use the same crop for comparisons.
```

## 38.4.1 Useful prompt or direction
Word body block 5250

```text
The camera moves slowly closer to the notebook. The notebook and pencil remain resting in place. The movement is gentle and steady throughout.
```

## 38.5.1 Useful prompt or direction
Word body block 5260

```text
Review direction: Compare each sampled frame with the source. Note changes in object count, shape, colour and framing. Then watch every transition at normal speed. Mark unreviewed checks as pending.
```

## 38.6.1 Useful prompt or direction
Word body block 5270

```text
Revision direction: If the approach crops the pencil, reduce the camera movement while keeping the same image and duration. If the source crop already cuts the pencil, fix the crop first and label that as an input revision.
```
