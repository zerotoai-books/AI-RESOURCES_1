# Voice scripts

These are the printed promotional practice scripts, not audiobook chapter narrations or completed recordings. In the three-part script, section headings are production labels. Spanish review is Pending. Compare facts with B0 and B5 before generating any take.
