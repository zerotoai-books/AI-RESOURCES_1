# Chapter 45 Deliver a complete workshop operations pack

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 45.2 Exercise 1 Define the pack and source hierarchy

Step 1  List the event fact sheet, invitation and FAQ, agenda, budget, registration briefing and calculator note.

Step 2  Assign B0 to event facts, B3 to counting rules and B4 to budget and agenda.

Step 3  Mark approval and real world confirmation as pending.



## 45.3 Exercise 2 Build and verify the agenda

Step 1  Add the allocations before drafting the agenda.

Step 2  Start at 11 am IST and calculate each end time.

Step 3  Check that the last segment ends at noon.



## 45.4 Exercise 3 Verify the budget assumptions

Step 1  Calculate room, materials and printing from B4.

Step 2  Add the total and subtract it from the INR 1500 limit.

Step 3  Label the result as a planning estimate with unallocated budget.



## 45.5 Exercise 4 Assemble and audit the pack

Step 1  Draft the pack with clear headings and a concise organiser summary.

Step 2  Audit repeated logistics, agenda arithmetic, budget and registration counts.

Step 3  Check every proposed action for an owner and status, leaving unknown owners unassigned.



## 45.6 Exercise 5 Prepare a final review handover

Step 1  Save editable content, source files and calculation evidence together.

Step 2  Add the calculator and its limits plus the actual test log.

Step 3  List next checks without claiming they are complete.

