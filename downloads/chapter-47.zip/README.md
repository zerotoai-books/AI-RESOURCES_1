# Chapter 47 Control pronunciation pacing and expression

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 47.2 Exercise 1 Identify words that need listening checks

Step 1  List Adyar, Chennai, the event date, IST and the booking address.

Step 2  Write the intended spoken form without claiming a phonetic standard you have not checked.

Step 3  Choose a short test sentence for each item.



## 47.3 Exercise 2 Compare punctuation before adding markup

Step 1  Save the baseline sentence and settings.

Step 2  Split a crowded sentence into two short sentences.

Step 3  Generate one comparison test and listen for clarity and completeness.



## 47.4 Exercise 3 Use a pronunciation rule only where supported

Step 1  Check whether your Studio or synthesis route offers a pronunciation dictionary.

Step 2  If supported, add IST with alias Indian Standard Time in a test project.

Step 3  Generate a sentence containing IST and verify the spoken result.



## 47.5 Exercise 4 Adjust expression without exaggerating the message

Step 1  Identify a single tone or pace problem in the baseline.

Step 2  Change one available control or one supported direction.

Step 3  Listen for both the intended improvement and new defects.



## 47.6 Exercise 5 Confirm the revised take in context

Step 1  Generate the affected sentence or paragraph in its final context.

Step 2  Listen to the full candidate and compare with the current script.

Step 3  Record which pronunciation items passed and which still need review.

