# Chapter 7 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 7.3.2 A checked requirements record

| Requirement | Source detail |
| --- | --- |
| Duration | 60 minutes, proposed 10 am–11 am IST. |
| Audience | Adult beginners; English. |
| Capacity | At most 12 attendees. |
| Method | Paper activities; no required attendee devices. |
| Budget | At most INR 2400, including reserve. |
| Review | Shardha reviews; venue and access questions resolved before release. |

## 7.4.2 One possible set of proposals

| Concept | Learner activity | Additional requirement |
| --- | --- | --- |
| Plan Your First Workshop | Draft a brief, calculate costs, and sketch an agenda. | None beyond the core inputs. |
| Write a Clear Invitation | Revise a fictional invitation against its fact sheet. | None beyond the core inputs. |
| Check a Simple Budget | Calculate quantities, totals, and remaining budget. | None beyond the core inputs. |
| Virtual Reality Discovery | Explore a virtual scene and discuss it. | Rental: INR 2800 extra. |
| Phone Photography Basics | Take and improve a photograph. | Each attendee must bring a phone. |
| Two Facilitator Planning Lab | Practise with a second facilitator. | Extra facilitator: INR 700. |

The first three are proposals that can use the paper format. The final three illustrate requirements you should inspect, not recommendations to override the brief. You may generate different ideas, but they need enough detail to test.

## 7.5.2 The checked core calculation

Printed learner packs cost 12 × 20 = INR 240. The core total is 800 + 900 + 240 + 200 = INR 2140. Remaining budget is 2400 − 2140 = INR 260. The reserve is already included; it must not be added again.

| Proposal | Total INR | Status | Reason |
| --- | --- | --- | --- |
| Plan Your First Workshop | 2140 | Pass | Paper format and core inputs fit. |
| Write a Clear Invitation | 2140 | Pass | Paper format and core inputs fit. |
| Check a Simple Budget | 2140 | Pass | Paper format and core inputs fit. |
| Virtual Reality Discovery | 4940 | Reject | 2140 + 2800 exceeds the cap. |
| Phone Photography Basics | Not fully priced | Reject | Requires attendee phones, which the brief excludes. |
| Two Facilitator Planning Lab | 2840 | Reject | 2140 + 700 exceeds the cap. |

Passing this screen means a concept can proceed to comparison. It does not confirm venue availability or settle the open access question. If an idea has an unknown cost or resource requirement, record that dependency; do not assign a zero price to make it pass.

## 7.6.3 A possible agenda outline

| Activity | Min | Learner result |
| --- | --- | --- |
| Welcome and goals | 5 | Know what the session will assess. |
| Short lesson and demonstration | 10 | See a brief, calculation, and agenda. |
| Brief and budget practice | 15 | Extract facts and calculate costs. |
| Compare the budget with the key | 5 | Correct arithmetic or omitted costs. |
| Create and check an agenda | 10 | Allocate all 60 minutes. |
| Independent assessment | 10 | Complete a short individual check. |
| Correct and save the work | 5 | Keep a checked result. |

The total is 5 + 10 + 15 + 5 + 10 + 10 + 5 = 60 minutes. Materials are the supplied brief, printed activity sheets, and an answer guide. The facilitator can use a paper demonstration if equipment is unavailable. Confirm any additional stationery arrangements rather than assuming they are included in a room booking.

## 7.6.4 Check your result

• The session contains a task for each of the three outcomes.

• The agenda totals 60 minutes and includes checking time.

• The format works without attendee phones or laptops.

• The budget retains the reserve and stays at INR 2140.

• Venue and access questions remain visible.

This is an outline. The full lesson, worksheet, facilitator notes, and assessment will be developed in Chapter 10. You are establishing the shape of the work before writing every part.

## 7.7.2 Checked decisions

| Suggested change | Result | Decision |
| --- | --- | --- |
| Refreshments for 12 | 2140 + (12 × 30) = INR 2500. This is INR 100 over the cap. | Reject under the current budget. |
| 20 attendees and 20 learner packs | 800 + 900 + 400 + 200 = INR 2300, but capacity is 12. | Reject under the current capacity rule. |
| Advertise confirmed access | The brief says step-free access is not confirmed. | Keep access as an open question. |

Do not remove the reserve simply to make refreshments fit. The reserve is a required part of this brief. You could propose a revised brief for a real project, but that requires an explicit change decision; it cannot be silently hidden inside an AI-generated outline.

## 7.7.4 A possible change record

```text
Refreshments were excluded because they would raise the planned total to INR 2500. Capacity remains 12 even though the 20-person print calculation would fit the budget. Access wording remains pending confirmation because no access evidence has been supplied. The selected topic, core costs, reserve, and 60-minute outline are unchanged.
```

## 7.8.2 A possible decision note

```text
We propose Plan Your First Workshop for 12 adult beginners on 21 November 2026, from 10 am to 11 am IST. Learning Room, Adyar, Chennai is the proposed venue; booking remains unconfirmed.
```

```text
The concept combines a fact brief, a budget calculation, and an agenda. Paper activities make it workable without attendee devices. The planned core total is INR 2140, including the reserve, leaving INR 260 against the INR 2400 limit.
```

```text
Write a Clear Invitation and Check a Simple Budget are suitable alternatives. The virtual-reality and second-facilitator options exceed the cap. Phone photography requires devices that the brief excludes.
```

```text
We have excluded refreshments and retained capacity 12. Vishva must confirm the room and access arrangements, and the equipment coordinator must check the equipment needed. Shardha will review the materials before release.
```

## 7.10.1 Answer guide after your attempt

The core total is 500 + 600 + (8 × 15) + 150 = INR 1370. The remaining budget is INR 130. Sticker kits add 8 × 25 = INR 200, raising the total to INR 1570, which is INR 70 over the cap. A phone-based cataloguing concept fails the device rule even if you invent a free app.

Acceptable paper concepts include planning a small book swap, writing a clear swap notice, or sorting example swap records. Choose based on the organiser’s need. One valid 45-minute structure is welcome five, lesson eight, practice 15, checking seven, individual assessment five, and corrections five. The sum is 45.

```text
We propose a paper-based planning session for eight Book Swap Helpers. Volunteers will draft a short brief and check a simple budget. The core planned total is INR 1370, leaving INR 130 under the INR 1500 cap. Sticker kits are excluded because they would raise the total to INR 1570.
```

```text
The 45-minute outline includes a lesson, practice, checking, assessment, and corrections. It requires no attendee devices. Community Room, Kochi remains a proposed venue, and its booking must be confirmed before invitations are released. A clear-notice workshop is a useful alternative if volunteers mainly need communication practice.
```

## 7.11 Check your understanding

## 7.11.1 Answer guide
