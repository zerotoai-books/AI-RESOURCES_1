# Chapter 49 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 49.2.2 Worked answer guide

The brief prevents a misleading sentence such as “Join our Spanish workshop.” The translated copy should explain the English activity clearly. Learning Room, Adyar and Chennai remain identifiable names. The email should remain learn@example.com in written materials even if a spoken form is prepared separately.

Check your work. A translation brief is a specification, not a completed translation review. Record the reviewer and status separately.

## 49.3 Exercise 2 Check the draft facts line by line

Your task. Compare the supplied Spanish draft with B0 before generating audio. Use a fact matrix so a fluent sentence cannot hide a changed time or omitted condition.

## 49.3.2 Worked answer guide

The draft includes “veintiuno de noviembre de dos mil veintiséis,” “once de la mañana hasta el mediodía” and “hora estándar de la India.” It states “La actividad se realiza en inglés.” These phrases are intended to preserve the date, time and English activity. A proficient reviewer still needs to assess naturalness and audience understanding.

Check your work. Back translation can help detect drift, but it is not independent proof of a good translation. Compare directly with the source and obtain competent language review.

## 49.4.2 Worked answer guide

A listener who writes the correct address has supplied useful evidence for that test. One listener does not guarantee universal comprehension, so retain the literal address in the accompanying text. Place names may need an additional review by someone familiar with the location. Do not silently translate the event venue into an invented local name.

Check your work. The test should be performed on the actual candidate audio. Reading the spoken form from a page is a script review, not a listening result.

## 49.5.2 Worked answer guide

The target is clear Spanish speech that preserves the English activity and Indian timezone. A pleasing accent is not enough if a number is misread. If the selected route does not support the language, change to a supported route or stop at the prepared script. Do not label an ungenerated file as a completed language version.

Check your work. Record whether the reviewer checked meaning, pronunciation or both. Someone able to verify the date may not be qualified to approve the naturalness of the whole script.

## 49.6.2 Worked answer guide

The Spanish audio may run longer than English. Do not force both into the same edit slot by removing essential conditions. Shorten the translation with a qualified reviewer or revise the visual timing. Your handover should identify the current candidate in each language and archive older versions.

Check your work. The provided Spanish draft is not approved for public release. A completed classroom fact comparison can coexist with pending native language and audio review.

## 49.7.1 Answer guide after your attempt

A complete plan preserves the English teaching language, Indian timezone, date, venue and contact. It checks support for the selected model rather than all ElevenLabs models in general. It names the need for a proficient target language reviewer and local place name checks. No translated script, audio or approval should be invented merely to fill a checklist.
