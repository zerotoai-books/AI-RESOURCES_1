# Chapter 28 Clean data and build summaries

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 28.1.1 Your task

Step 1  Count raw rows and inspect the column types.

Step 2  Find duplicate IDs and compare all their fields.

Step 3  Find missing statuses and nonstandard categories.

Step 4  Inspect dates that remain text.

Step 5  Record proposed changes before permitting them.



## 28.2.1 Your task

Step 1  Preserve the raw file and stable IDs.

Step 2  Trim ordinary leading and trailing spaces in labels.

Step 3  Standardise only recognised category and status values.

Step 4  Keep missing status as Needs review.

Step 5  Remove only the verified exact duplicate.



## 28.3.1 Your task

Step 1  Copy all twelve raw rows into a working sheet.

Step 2  Make the three type or label corrections.

Step 3  Remove one exact R03 duplicate after comparing its fields.

Step 4  Keep R11 and set its status to Needs review.

Step 5  Record the old value, new value and reason for each change.



## 28.4.1 Your task

Step 1  Count all eleven cleaned records by status.

Step 2  Sum confirmed seats for Community and Workplace separately.

Step 3  Reconcile the category total to the overall confirmed-seat sum.

Step 4  Keep Needs review visible in the status summary.

Step 5  Check that the duplicate raw row is no longer included.



## 28.5.1 Your task

Step 1  Reconcile twelve raw rows minus one exact duplicate to eleven cleaned records.

Step 2  Confirm that the original raw sheet remains unchanged.

Step 3  Check that all retained IDs and meaningful source values are accounted for.

Step 4  Record eight confirmed seats and the unresolved status.

Step 5  Keep the change log with the cleaned file.

