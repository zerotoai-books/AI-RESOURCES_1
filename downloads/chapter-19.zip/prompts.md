# Chapter 19 Adapt a design for different formats

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 19.2.1 Your task
Word body block 3458

```text
Create an output specification from C0. Keep the square, vertical and A4 formats separate. List the title, date, time and IST, venue and registration contact as essential information on each standalone version. Label these sizes as exercise specifications rather than universal platform rules.
```

## 19.4.1 Your task
Word body block 3484

```text
Adapt the checked workshop copy to a 1080 by 1920 pixel vertical story. Keep essential facts readable, preserve the exact contact and leave space around the title and registration instruction. Do not assume a universal platform safe area. Keep the illustration secondary to the information.
```

## 19.6.1 Your task
Word body block 3513

```text
Compare my three checked versions with C0 version 2. Check event title, date, time and time zone, venue, fee, capacity, contact and device requirement. List a mismatch by asset and proposed correction. Do not mark unreadable text as correct merely because the words exist in the editor.
```
