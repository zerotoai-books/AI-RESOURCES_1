# Chapter 24 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 24.1.2 Answer guide

Paper and pencils match the supplied activity format. A picture of a crowded classroom would not prove bookings, attendance or the appearance of Learning Room. An AI-created graphic with a misspelled contact inside it should be replaced or have the words rebuilt as editable text. A text-only card can be the better choice when the picture makes the content smaller.

## 24.2.2 Answer guide

A bar labelled “Room 600” needs the INR unit somewhere the reader can see. A scale labelled “thousands” would represent 600 differently and must be deliberate; this small case is clearer in whole INR. A chart's length cannot establish numerical correctness. Read the underlying values or data labels and check their sum independently.

## 24.3.2 Worked observation form

For each card, record its number, the exact item inspected, the viewing condition, the observed problem and the correction made. Examples of useful findings are “the last digit of INR 1080 is cropped” and “the contact wraps into two unreadable lines.” Leave a field untested when you have not actually looked at it.

## 24.3.3 Answer guide

If a budget table does not fit, simplify its layout or move detailed calculations to notes while retaining the headline estimates and total. Do not remove a currency label or a necessary qualification just to make the card fit. Check the resulting presentation view after the edit.

## 24.4.2 Answer guide

Check whether the downloaded file includes all five parts; exporting one current card is incomplete for this task. A PDF is static, so interactive behaviour should not be assumed. Gamma's current help does not list Word DOCX as an export format. [GREF4] A Word document you create from the printed source text is a separate working document, not a Gamma export.

If an export scales unexpectedly, review Gamma's available Zoom to fit option and its guidance for the chosen slide format, then export again. [GREF5] Correcting the source deck does not update an older downloaded file. Keep the revised source and new export clearly named.

## 24.5.2 Worked delivery manifest

| Item | Intended use | Check required |
| --- | --- | --- |
| Editable Gamma source | Future revisions | Correct version and access |
| Full PDF review copy | Static reading | Every card and all facts inspected |
| PPTX if produced | Editing and presenting | Layout and actual editability inspected |
| Separate notes | Rehearsal support | Match the five cards |

## 24.5.3 Answer guide

Current help describes editable PowerPoint table export, but inspect the actual file rather than assuming every object is editable. [GREF4] Font handling and some visuals can differ between applications. A reviewed PDF does not establish that the PPTX passed the same checks.

If you later deliver a Gamma link, review its view, comment or edit permissions and the relevant workspace settings. Available controls depend on the plan. [GREF8] View access is not a promise that viewers cannot copy visible content. For this exercise, prepare the permission record and keep the deck private; no real recipient or public release is required.

## 24.6.1 Answer guide

The file must retain INR 650 per person, photos@example.com and 3 pm to 4.30 pm IST on Saturday 28 November 2026. The supplied case does not establish access arrangements. A correct workshop export from G0 cannot stand in for reviewing this separate deck.
