# 04_tests

Printed reference recovered without code changes. Python 3.12 or later and the standard library. The review reran it on 3.12.14.

Run `python -m unittest -v test_calculator` for six reference methods. This repeats the complete calculator suite for the Chapter 34 route, so do not count it twice when reporting distinct core test methods.

Keep the baseline unchanged and use a working copy. This is a local teaching example.
