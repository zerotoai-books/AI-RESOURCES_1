# Chapter 7 source inputs

These are fictional teaching sources from the current printed manuscript. Use the exact source ID and scope named in the exercise. Deliberate defects and old versions remain unchanged.

## 7.1 The community workshop brief

Brief version 1.0: propose a session on 21 November 2026, from 10 am to 11 am IST. The proposed venue is Learning Room, Adyar, Chennai, and booking is not confirmed. The audience is adult beginners, with capacity limited to 12 attendees. Use English and paper activities. Attendees must not be required to bring a phone or laptop.

The total planned budget must be at most INR 2400, including the reserve. The core costs below apply to any of the paper-based concepts. The printing figure covers complete learner resources and facilitator copies. These are supplied fictional planning figures, not estimates Gemini should replace. No participant fee or revenue is agreed, and no registration count is supplied.

| Core cost | Qty | Unit INR | Amount INR |
| --- | --- | --- | --- |
| Venue | 1 | 800 | 800 |
| Facilitation | 1 | 900 | 900 |
| Printed learner packs | 12 | 20 | 240 |
| Planning reserve | 1 | 200 | 200 |

Optional extras are additional costs: refreshments for 12 people at INR 30 each; one extra facilitator at INR 700; a virtual-reality equipment rental at INR 2800. Do not include an extra unless the selected concept uses it. The brief does not promise certificates, parking, access arrangements, or loan devices. Step-free access and available equipment remain open questions.

Your choice is a planning decision, not approval to release an invitation. Shardha must review the materials, and the venue and access questions must be resolved before public invitations are released.

## 7.10 Independent challenge

A different organiser wants a 45-minute paper-based session called Book Swap Helpers for eight adult volunteers. The proposed venue is Community Room, Kochi. The planned budget cap is INR 1500 including reserve. Core costs are venue INR 500, facilitation INR 600, eight printed learner packs at INR 15 each, and reserve INR 150. Optional sticker kits cost INR 25 per attendee. No participant fee, confirmed registration count, or venue booking is supplied. Attendee devices must not be required.

Generate three concepts, screen them, and choose one with a reason. Create a 45-minute outline with practice and checking. Test the sticker-kit suggestion, retain the unresolved room booking, and write a decision note under 150 words. Save a record of one improvement to your original prompt.


## Official tool references

## Gemini

## Official references for the Gemini chapters

Product guidance was checked on 12 October 2026. The references support the Gemini access, file, privacy, and optional learning-tool instructions. The scenarios, source notes, illustrations, budgets, schedules, prompts, worked answers, and marking guides are teaching material created for this book. Follow the current official help if your account or interface differs.

1 Google  Use Gemini Apps
https://support.google.com/gemini/answer/13275745?hl=en
Official web app: https://gemini.google.com

2 Google  Upload and analyse files in Gemini Apps
https://support.google.com/gemini/answer/14903178?hl=en

3 Google  Gemini Apps Privacy Hub
https://support.google.com/gemini/answer/13594961?hl=en

4 Google  Use learning tools in Gemini Apps
https://support.google.com/gemini/answer/16448384?hl=en
