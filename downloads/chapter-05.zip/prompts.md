# Chapter 5 Build a small business communication pack

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 5.4.1 Prompt to try
Word body block 1275

```text
Create Master Brief v4 dated 6 November 2026 using the approved project inputs, budget inputs, and decision record in this chapter. Separate confirmed event facts, the ticket snapshot, planned budget inputs, and unresolved joining details or policies. Do not copy superseded times from earlier exercises. Then create a fact register for the values that must agree across the communication pack.
```

## 5.5.1 Invitation prompt
Word body block 1305

```text
Using Master Brief v4 only, write an invitation email for adults new to AI. Include a subject and keep the body under 140 words. State the event date, session time and time zone, venue, fee, capacity, included printed sheets, own-laptop requirement, and booking contact. Describe capacity without claiming that 12 places remain. Do not invent certificates, refreshments, trainer qualifications, refunds, or payment instructions.
```

## 5.5.3 Reminder prompt
Word body block 1310

```text
Using Master Brief v4, draft a reminder for existing participants under 90 words. Include the workshop date, session time and time zone, 10.40 am arrival, venue, own-laptop requirement, and contact. Do not repeat an invitation to book or imply loan devices exist. Present it as a draft awaiting exact street-address and accessible-route details.
```

## 5.6.1 Prompt to try
Word body block 1329

```text
Create a concise FAQ using Master Brief v4. Answer questions about audience, date and time, arrival, venue, fee, capacity, included materials, laptops, booking, and refunds. Use only confirmed facts. For unresolved details, state that the organiser must confirm them and give the supplied contact when appropriate. Do not promise a refund, certificate, refreshment, payment method, or equipment loan.
```

## 5.6.3 Test the FAQ with a specific question
Word body block 1343

```text
Check the FAQ answer to “Can you lend me a laptop?” against Master Brief v4. Explain why the correct answer is that loan devices are not available, even though an earlier chapter said their availability had not been confirmed. Identify the dated decision that changed the status.
```

## 5.7.1 Prompt to try
Word body block 1353

```text
Using the supplied budget inputs and Master Brief v4, calculate each line and total planned allowance. Include the reserve in that total. Show fee revenue if all 12 tickets are Paid, the projected balance against the planned allowance, and the minimum whole number of Paid tickets needed to cover it at INR 499 each. Separately show recorded paid receipts for eight tickets and the two Pending-ticket amount. Do not treat projections or pending fees as collected cash. Do not add unsupplied costs.
```

## 5.7.4 Challenge a wrong budget conclusion
Word body block 1369

```text
A draft budget note says “We have collected INR 5,988 and already earned INR 1,468 profit.” Check it against the ticket snapshot and cost inputs. Identify which amounts are projections, which fees are recorded as Paid, and which expenses have not been established as actual. Rewrite the note accurately.
```

## 5.8.1 Prompt to try
Word body block 1379

```text
Using Master Brief v4 and the Chapter 4 event-day timings, create a six-part presentation outline for Shardha. Include a title, purpose, key teaching points, one practice action per teaching part, and allocated minutes. The workshop is 11 am–1 pm, with a 10-minute break, two teaching blocks totaling 95 minutes, and 15 minutes for questions. Keep event facts consistent. Do not invent a trainer biography, certificate, or guaranteed result.
```

## 5.9.1 Prompt to try
Word body block 1397

```text
Review all six labelled outputs against Master Brief v4 and its decision record. Check event name, date, session time, arrival time, venue, fee, capacity, materials, laptop policy, contact, ticket snapshot, budget calculations, and presentation timings. For each mismatch, cite the document and exact claim, the correct source value, and the needed correction. Keep unresolved joining details visible. Do not grant release approval or treat a draft’s unsupported claim as a new fact.
```

## 5.10.1 Prompt to try
Word body block 1428

```text
Approved change: capacity becomes 10 participants and printed-material quantity becomes 10. Create Master Brief v5 and update every affected output. Preserve the fee, time, venue, contact, and ticket statuses. All 10 places are allocated to eight Paid and two Pending tickets, so change booking language to enquiries rather than implying new places are available. Recalculate the budget, full Paid-capacity projection, and minimum Paid-ticket count. Keep the raw dataset unchanged and add a document-by-document change log.
```

## 5.11.2 Prompt to try
Word body block 1469

```text
Prepare a README and handover checklist for the current v5 pack. Include the source versions, document contents, checked figures, allocation status, current review status, and outstanding joining details. Distinguish a checked draft from permission to send. Assign the next confirmation to Vishva and the release review to Shardha as supplied. Do not claim the folder has been saved unless it actually exists and its files can be opened.
```
