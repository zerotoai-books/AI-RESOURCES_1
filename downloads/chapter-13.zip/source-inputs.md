# Chapter 13 source inputs

These are fictional teaching sources from the current printed manuscript. Use the exact source ID and scope named in the exercise. Deliberate defects and old versions remain unchanged.

## Perplexity

## Official references for the Perplexity chapters

Product guidance was checked on 14 October 2026 IST. The 2027 Edition label is the book edition, not a claim that product features were verified in 2027. Features, plan eligibility and help pages can change. Use the current official source and your account notice when practising.

The worked answers are editorial teaching examples. They are not transcripts captured from Perplexity or Canva. Fictional source files, prices, event arrangements, trial records, illustrations and sample layouts were created for this book. Pending tests and approvals are not presented as completed results.

## P1 Perplexity What is a Session

Sessions and follow-up conversations.

https://www.perplexity.ai/help-center/en/articles/10354769-what-is-a-thread

## P2 Perplexity What is Pro Search

Source links and checking answers.

https://www.perplexity.ai/help-center/en/articles/10352903-what-is-pro-search

## P3 Perplexity What is Research mode

Optional research workflow and access.

https://www.perplexity.ai/help-center/en/articles/10738684-what-is-research-mode

## P4 Perplexity What are Projects

Optional project organisation.

https://www.perplexity.ai/help-center/en/articles/10352961-what-are-projects

## P5 Canva Choose the right download file type for your Canva design

Live source checking exercise.

https://www.canva.com/help/download-file-types/

## P6 Canva Resize designs and size limits

Live plan and feature comparison.

https://www.canva.com/help/resize/

## Practice sources printed for offline use

These source documents are printed here for the controlled exercises. Type the source text into your tool or create your own saved copy. They are fictional teaching material. Additional datasets and creation instructions appear in the Printed practice materials appendix.

## R0 Research Brief

R0 Research brief version 1

Fictional teaching case created for From Zero to AI by SUNDAR P.

Decision date: 14 October 2026 IST. Learning Circle needs one registration workspace for three consecutive months. Mandatory requirements: at least 24 registration records, English interface, desktop browser use, CSV export, and no account required for a participant to submit the public form. One organiser will operate the workspace. No payment collection is needed. The total three-month software budget is INR 1200. All prices in this exercise include taxes. There are no other purchase costs in the supplied case. Data deletion timing, actual usability and accessibility have not been tested. Do not treat the fictional products as real services. The team will not purchase anything until the chosen workflow has been tested.

## F1 Older Option A Announcement

F1 Older announcement for fictional Option A

Published 1 June 2026. Archived teaching source. The Free plan collects up to 50 registration records in a workspace. CSV export is included in Free during the introductory period, ending 31 August 2026. This announcement does not describe arrangements after that date.

## F2 Current Option A Guide

F2 Current guide for fictional Option A

Published 20 September 2026. Applies from 1 September 2026. The Free plan collects up to 50 records but does not export CSV. The Plus plan collects up to 100 records and exports CSV from the desktop browser. The interface is English. Participants can submit the public form without creating an account. One organiser account is included. This guide does not specify price or deletion timing. A help button is available; response time is not specified. These are invented exercise facts.

## F3 Current Option A Price

F3 Current price note for fictional Option A

Published 21 September 2026. Applies from 1 September 2026. Plus costs INR 400 per workspace per month, including taxes. It can be purchased month by month. There is no setup fee or other purchase cost in this fictional case. The price note does not establish usability, deletion timing or response time for help requests.

## F4 Current Option B Guide and Price

F4 Current guide and price for fictional Option B

Published 25 September 2026. Applies to the three-month period in this case. The paid workspace includes 100 records, English interface, desktop browser use, CSV export and public form submission without participant accounts. It allows two organiser accounts. The price is INR 350 per month including taxes, with a minimum purchase of three months paid upfront. No setup fee or other purchase cost applies in this fictional case. A help button is available; response time and data deletion timing are not specified. Usability and accessibility have not been tested.

## F5 Current Option C Guide and Price

F5 Current guide and price for fictional Option C

Published 26 September 2026. Applies to the three-month period in this case. The paid workspace includes 20 records, English interface, desktop browser use, CSV export and public form submission without participant accounts. It allows one organiser account. It costs INR 250 per month including taxes, with no setup fee or other purchase cost in this fictional case. No larger record allowance is supplied. Help response time, deletion timing, usability and accessibility have not been established.

## R1 Independent Research Challenge

R1 Independent research challenge

All products and prices below are fictional teaching facts.

Need: 40 records, English interface, desktop browser, CSV export, no participant account, two organiser accounts and a two-month total budget of INR 900. All prices include taxes and there are no additional purchase costs in this case.

X: 50 records, all required workflow features, one organiser account, INR 300 per month. No second organiser option is supplied.

Y: 80 records, all required workflow features, two organiser accounts, INR 450 per month. No minimum term beyond two months is imposed in this case.

Z: 100 records, all required workflow features, two organiser accounts, INR 400 per month, but a minimum purchase of three months paid upfront is required. Usability, accessibility and data deletion timing are untested for X, Y and Z.
