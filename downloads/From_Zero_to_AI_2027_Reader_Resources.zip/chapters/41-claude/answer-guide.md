# Chapter 41 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 41.2.2 Worked answer guide

The fact list should include Plan Your First Workshop, 21 November 2026, 11 am to noon IST, Learning Room in Adyar, Chennai, adult beginners, free attendance, capacity twelve and learn@example.com. Parking, refreshments and certificates are not confirmed. Capacity does not establish how many places remain available.

Check your work. A useful extraction preserves qualifications. “Step free access is confirmed for the fictional venue” does not justify “suitable for every access need.” Discuss specific requirements using the brief’s contact route.

## 41.3.2 Worked answer guide

One suitable answer is: “Join Plan Your First Workshop on 21 November 2026, from 11 am to noon IST, at Learning Room, Adyar, Chennai. This free session is for adult beginners. Try a paper based planning activity with printed materials provided. No phone or laptop is needed. To book, email learn@example.com.” It preserves the practical message without turning capacity into availability.

Check your work. Count words using one consistent method if the limit matters. A shorter answer that omits the timezone or contact still needs correction.

## 41.4.2 Worked answer guide

A compact answer can read: “Join Plan Your First Workshop on 21 November 2026, 11 am to noon IST, at Learning Room, Adyar, Chennai. Free for adult beginners. Book via learn@example.com.” The activity description disappears before the required logistics. This is a deliberate editing choice, not a change to what the workshop offers.

Check your work. Save the revised text with a version number. Do not overwrite the source brief when changing only the length of the invitation.

## 41.5.2 Worked answer guide

The flawed text gives 10 am, a fee of INR 499, certificates and lunch, ten available places and a laptop requirement. The correct time is 11 am to noon IST, attendance is free, certificates and lunch are not confirmed, availability is unknown, and no phone or laptop is needed. The correction should remove the invented benefits rather than describe them as likely.

Check your work. Check the corrected text yourself. An audit that finds five errors and leaves the sixth in the final paragraph is incomplete.

## 41.6.2 Worked answer guide

A good record points to the actual candidate and says which checks were performed. “Claude said it was correct” is not an independent check. An unresolved real world contact remains a release issue even when the fictional exercise is internally consistent. Keep the practice placeholder visible in the handover note.

Check your work. A filename should identify the chapter and version. Store discarded drafts separately so the current invitation can be found without reading the whole chat.

## 41.7.1 Answer guide after your attempt

The answer uses 28 November 2026, 3 to 4.30 pm IST, Studio Room, Kochi, INR 650, adults and capacity eight. It asks attendees to bring a camera or camera phone and uses photos@example.com. Suitable FAQ topics are who may attend, what to bring and how to book. It must not inherit free attendance, printed workshop materials or step free access from B0.
