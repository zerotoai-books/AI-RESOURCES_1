# Chapter 43 Analyse supplied files with traceable answers

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 43.2.1 Useful prompt or direction
Word body block 5585

```text
Inspect Registrations.csv before calculating. Report its columns, data row count, distinct ID count and status labels. Identify missing values or duplicate IDs. Do not change or silently clean any record.
```

## 43.3.1 Useful prompt or direction
Word body block 5595

```text
Using only Registrations.csv, count records by status and list the IDs supporting each count. Show a reconciliation to the total rows. Do not merge Waitlisted or Needs review into Confirmed.
```

## 43.4.1 Useful prompt or direction
Word body block 5605

```text
Apply B0 capacity 12 and B3 rules. Calculate confirmed places, available places and confirmed counts by category. List the relevant IDs. Do not count cancelled, waitlisted or review records as confirmed.
```

## 43.5.1 Useful prompt or direction
Word body block 5615

```text
Summarise Feedback.txt using comment IDs as evidence. Identify repeated themes and one practical action for each. Do not calculate population percentages, infer demographics or claim that these six comments represent all attendees.
```

## 43.6.1 Useful prompt or direction
Word body block 5625

```text
Write a briefing under 180 words using B0, B3, Registrations.csv and Feedback.txt. Include exact totals and supported themes. Mark proposed actions as proposals. State that the records are fictional practice data and give the calculation method.
```
