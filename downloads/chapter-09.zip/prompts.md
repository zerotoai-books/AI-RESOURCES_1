# Chapter 9 Create a learning plan and assess progress

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 9.3.1 Prompt to try
Word body block 2186

```text
Using only U1–U6 and Source A version 1.1, map each unit to an observable practice task and a way to check it. Keep the work suitable for an adult beginner. Do not add marketing, software setup, or legal topics that are outside the supplied syllabus. Use source labels beside the checks.
```

## 9.3.3 A useful follow-up
Word body block 2198

```text
Replace any task described only as learn, understand, or explore. Give something the learner can write, calculate, classify, or correct, with a check tied to U1–U6 or Source A.
```

## 9.4.1 Prompt to try
Word body block 2207

```text
Create a dated study plan for 2–15 November 2026 from U1–U6. Weekdays allow 30 minutes at 7 pm IST; Saturdays allow 45 minutes at 10 am IST; Sundays are unavailable. Introduce the units in week 1 and revisit them in week 2. Include practice, checking, and independent assessment. Show dates, durations, units, timed activities, and weekly and overall totals. Add no work outside these windows.
```

## 9.5.1 Prompt to try
Word body block 2241

```text
Create six short practice questions, one for each unit U1–U6, using Source A version 1.1. Test application, not just definitions. Include a budget calculation and an agenda that needs correction. Give only the questions first. When I ask for the key, provide checked answers, source labels, and marks totalling 10. Do not invent registrations, revenue, or venue confirmation.
```

## 9.5.4 A useful correction prompt
Word body block 2258

```text
Your Q3 key left out the required reserve. Recalculate from A6, include the reserve inside the cap, and correct the remaining amount. Update the answer guide and any score that depended on the wrong key. Keep unrelated answers unchanged.
```

## 9.6.1 Prompt to try
Word body block 2268

```text
Mark the sample responses using the verified Q1–Q6 guide exactly. Give marks, the specific error or strength, and the source rule. Do not award marks for confident wording. Identify two priority practice tasks. Do not claim the sample learner completed the study plan.
```

## 9.7.1 Prompt to try
Word body block 2293

```text
Tuesday 3 November was missed. Revise the remaining first week without adding time to any study window or using Sunday. Introduce U2 before the budget work, cover U1–U6 by Saturday, and keep some checking. Show what is shortened or moved. Retain week 2, unless you identify a necessary change. Recalculate the two-week scheduled minutes.
```

## 9.8.1 Prompt to try
Word body block 2317

```text
Assess these answers against new case F and U1–U6. Use two marks per question. Check the supplied facts and arithmetic, allow equivalent correct wording, and explain each correction. Keep the answer guide separate from my responses. Do not infer revenue or accept waiting requests as confirmed.
```

## 9.9.1 Plan from a syllabus
Word body block 2339

```text
Build a study plan using [syllabus] and [available windows]. Give an observable task and checking time in each session. Show dates, durations, and totals. Do not add work outside the supplied windows.
```

## 9.9.2 Generate a traceable answer guide
Word body block 2341

```text
Create practice questions from [source]. Supply answers only after my attempt. Tie each answer and marking rule to a source location, show calculation working, and flag any question the source cannot answer.
```

## 9.9.3 Revise from evidence
Word body block 2343

```text
Using [missed sessions or assessed errors], revise the remaining plan within [unchanged availability]. State what moves, what is reduced, and the new total. Prioritise the failed skills and keep time to check them.
```
