# Chapter 37 Describe motion and improve a clip

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 37.2 Exercise 1 Describe the defect without guessing its cause

Step 1  Watch take A from beginning to end.

Step 2  Record the time and visible defect in plain language.

Step 3  Choose one issue that matters to the shot objective.



## 37.3 Exercise 2 Distinguish subject motion from camera motion

Step 1  Underline the subject action in the original prompt.

Step 2  Mark any camera instruction separately.

Step 3  Write two short versions that change only the camera treatment.



## 37.4 Exercise 3 Make a controlled prompt revision

Step 1  Copy the original prompt into a new log row.

Step 2  Change one sentence to address the chosen defect.

Step 3  Keep the settings fixed and generate one comparison take if available.



## 37.5 Exercise 4 Compare against the same criteria

Step 1  Score object stability, requested motion and framing on a zero to two scale.

Step 2  Use zero for unusable, one for partial and two for suitable for the exercise.

Step 3  Write an observed reason for each score and keep critical defects visible.



## 37.6 Exercise 5 Decide when to stop iterating

Step 1  Compare the observed result with the acceptance criteria.

Step 2  Check the remaining attempt or credit budget.

Step 3  Write Accept, Revise once or Replace with a still image, with a reason.

