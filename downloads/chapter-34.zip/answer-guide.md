# Chapter 34 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 34.1.2 Answer guide

The matrix should explain the requirement behind each expectation. For example, True is rejected by the reference's text-input API. That is different from a valid string containing digits. A hundred-percent discount is valid under K1, while a quantity of zero is not.

The independent INR 19.99 example has subtotal INR 59.97. Ten percent is INR 5.997, rounded to a discount of INR 6.00. Subtracting that discount gives INR 53.97. Calculate this before inspecting the program's answer.

## 34.2.2 Worked test excerpt

The following small test can be saved beside calculator.py before expanding the suite. Appendix A4 prints the complete six-method reference suite and its exact run command:

```text
from decimal import Decimal
import unittest
from calculator import quote
```

```text
class MyQuoteTests(unittest.TestCase):
    def test_baseline_total(self):
        result = quote("25", "12", "10")
        self.assertEqual(result.total, Decimal("270.00"))
```

```text
    def test_fractional_quantity_is_rejected(self):
        with self.assertRaises(ValueError):
            quote("25", "12.5")
```

```text
if __name__ == "__main__":
    unittest.main()
```

This excerpt starts the suite; it does not yet cover every item in the matrix. The full reference test file checks the missing cases. Compare its expected values with your own arithmetic rather than copying all its assertions without review.

## 34.2.3 Answer guide

An assertion that a result merely exists would accept an incorrect amount. An assertion that a result equals the output of the same function called again also provides little independent evidence. The expected INR 270.00 should come from the brief and calculation.

## 34.3.2 Worked output guide

From the folder containing calculator.py and the printed test_calculator.py, the command python -m unittest -v test_calculator should report six passing test methods. Several methods use subtests. Elapsed time depends on the machine. A failed assertion normally returns a nonzero exit status. Keep the deliberate Chapter 33 failure in its separate folder.

Test discovery looks for importable test modules. [PY3] Use the exact named-module command in Appendix A4, from the folder containing the code and tests. Run the registration suite separately as described in Appendix A6. No downloaded check runner or extracted archive is needed.

## 34.3.3 Answer guide

If the output says Ran 0 tests, check the folder, filename and test method names. If it reports a module import error, fix the file layout or imports first. Changing the expected total to match whatever the program printed does not resolve a calculation defect.

## 34.4 Exercise 4 Check the public command interface

## 34.4.2 Worked interface checks

The reference valid command prints subtotal 300.00, discount 30.00 and total 270.00 with INR labels and returns zero. Fractional quantity returns two and an explanatory error. Importing calculator produces no terminal output because the main guard separates import from execution.

Using sys.executable in a Python test selects the interpreter running that test. It avoids accidentally launching another Python installation. This does not prove that a separately configured editor run button uses the same interpreter; check that path in your own workspace log.

## 34.4.3 Answer guide

An additional useful check is that total plus discount equals subtotal for valid inputs. Add this check to your own suite. This relationship can detect inconsistencies, but it does not replace the independently calculated examples. A program can satisfy an algebraic relationship while using the wrong discount rule.

## 34.5.2 Worked dependency review

calculator.py uses argparse, dataclasses, decimal and re. Its tests use unittest, pathlib, subprocess and sys, plus the local calculator module. These are standard-library modules. VS Code, Python language support and GitHub Copilot are separate development tools, not runtime imports of this calculator.

If keeping your work in a local Git repository, create a .gitignore yourself with these lines: __pycache__/; *.pyc; *.sqlite3; .env. Put each pattern on its own line. This excludes matching untracked files; it does not remove a secret already committed. A repository and public sharing are not required for the exercises.

## 34.5.3 Answer guide

Passing tests establish the results of the cases actually run on the recorded interpreter. They do not prove every possible input, every operating system or a production accounting workflow. A useful handover states the scope and leaves unperformed editor or human review checks pending.

## 34.6.1 Answer guide

Subtotal is INR 0.15, rounded discount INR 0.02 and total INR 0.13. Both invalid text cases must be rejected. The rounding example detects the per-unit rounding defect described in Chapter 33. Save the new test and its actual result rather than only the expected value.
