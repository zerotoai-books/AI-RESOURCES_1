# From Zero to AI 2027 Book 1 reader resources

Companion version 2027.1-preview. Prepared from the supplied Word manuscript on 26 October 2026.

Open START_HERE.md. Each of the fifty chapter folders contains README.md, prompts.md, source-inputs.md and answer-guide.md. Chapter tables are CSV files. Shared tool sources, printed appendix reference, figures, code, voice scripts and blank review logs are included.

The three rebuilt native Excel files are in workbooks/. Start Chapters 26 to 29 with Excel_Copilot_Starter.xlsx. It contains the ten-record initial table and twelve-record dirty sheet. Compare after cleaning with Excel_Copilot_Cleaned_Reference.xlsx. Chapter 30's answer reference is Excel_Copilot_Worked_Tracker.xlsx. The formula summary and chart are not a prebuilt PivotTable: creating and refreshing one is the Chapter 29 exercise.

This is a usable companion preview, not final publication approval. Original code suites and workbook calculations were checked locally. Signed-in product use, native Excel user interaction, media generation/playback, Spanish review and a publisher's final print approval remain separate tasks. No generated video, speech or audiobook tracks are included.

The public companion contains practice material, not the complete manuscript. The original copyright and personal practice permission apply. All events and contact addresses are fictional.
