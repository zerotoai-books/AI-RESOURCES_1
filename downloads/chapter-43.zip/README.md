# Chapter 43 Analyse supplied files with traceable answers

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 43.2 Exercise 1 Inspect the file before asking for totals

Step 1  Open the CSV in a text editor or spreadsheet viewer.

Step 2  Identify ID, status and category columns.

Step 3  Check for duplicate IDs, blanks and unexpected status labels.



## 43.3 Exercise 2 Calculate the status summary

Step 1  Request counts by exact status label.

Step 2  Ask for supporting IDs for each count.

Step 3  Add the counts and compare the sum with the data row count.



## 43.4 Exercise 3 Compute capacity and category figures

Step 1  Subtract eight confirmed places from capacity twelve.

Step 2  Count categories within Confirmed only.

Step 3  Explain why remaining budget and available places are different quantities.



## 43.5 Exercise 4 Summarise feedback without overstating it

Step 1  Read all six comments before asking for a summary.

Step 2  Request themes linked to comment IDs.

Step 3  Separate observations, proposed actions and unanswered questions.



## 43.6 Exercise 5 Write a checked organiser briefing

Step 1  Draft a short summary naming the fixture and source version.

Step 2  Include status totals, capacity arithmetic and limited feedback themes.

Step 3  Add pending actions and an independent checking note.

