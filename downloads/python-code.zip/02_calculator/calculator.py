import argparse
import re
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP


@dataclass(frozen=True)
class Quote:
    subtotal: Decimal
    discount: Decimal
    total: Decimal


def text(value):
    if not isinstance(value, str):
        raise ValueError("Inputs must be text")
    return value.strip()


def whole(value, low, high):
    value = text(value)
    if not re.fullmatch(r"[0-9]+", value):
        raise ValueError("Use whole-number text")
    # Length guard avoids converting an unbounded integer.
    value = value.lstrip("0") or "0"
    if len(value) > len(str(high)):
        raise ValueError("Whole number outside allowed range")
    number = int(value)
    if not low <= number <= high:
        raise ValueError("Whole number outside allowed range")
    return number


def quote(unit_price, quantity, discount_percent="0"):
    raw = text(unit_price)
    if not re.fullmatch(r"[0-9]+(?:\.[0-9]{1,2})?", raw):
        raise ValueError("Use a price with up to two decimals")
    raw = raw.lstrip("0") or "0"
    if raw.startswith("."):
        raw = "0" + raw
    if len(raw.split(".")[0]) > 6:
        raise ValueError("Price outside 0 to 100000")
    price = Decimal(raw)
    if not 0 <= price <= 100000:
        raise ValueError("Price outside 0 to 100000")
    count = whole(quantity, 1, 40)
    percent = whole(discount_percent, 0, 100)
    subtotal = price * count
    discount = (subtotal * percent / 100).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP
    )
    return Quote(subtotal, discount, subtotal - discount)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("price")
    parser.add_argument("quantity")
    parser.add_argument("--discount", default="0")
    args = parser.parse_args()
    try:
        result = quote(args.price, args.quantity, args.discount)
    except ValueError as error:
        parser.error(str(error))
    for name in ("subtotal", "discount", "total"):
        value = getattr(result, name)
        print(f"{name.title()} INR {value:.2f}")


if __name__ == "__main__":
    main()
