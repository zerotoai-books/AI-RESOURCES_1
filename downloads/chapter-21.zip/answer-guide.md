# Chapter 21 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 21.2.2 Worked instruction record

The purpose is to help a prospective attendee understand the workshop and register. The essential facts are Saturday 21 November 2026, 11 am to noon IST, Learning Room in Adyar, Chennai, free attendance and capacity 12. The checked contact is learn@example.com. Navy and amber are styling choices; they are not facts about the event. The brief supplies practice activities, rather than evidence that attendees will achieve a guaranteed result.

## 21.2.3 Check your work

If your instruction asks Gamma to research venues or prices, remove that request. This exercise already supplies its facts. Researching a real venue would introduce a different task and would not confirm a fictional booking.

## 21.3.2 Worked outline

| Card | Main purpose | Information to include |
| --- | --- | --- |
| 1 | Introduce the workshop | Event name and a short description |
| 2 | Help readers recognise themselves | Adult beginners and no device requirement |
| 3 | Explain the practice | Learning outcome, budget and agenda tasks |
| 4 | Make attendance practical | Date, time, venue, free attendance and capacity |
| 5 | Give the next action | Exact contact and careful access wording |

## 21.3.3 Answer guide

An outline with three promotional cards and no venue is incomplete. A sixth card containing essential information needs to be combined with an appropriate card, rather than deleted without checking what it contains. Card count and content coverage are separate checks.

## 21.4.2 Worked five card copy

```text
Card 1
Plan Your First Workshop
A practical session for adult beginners, using English and paper activities.
```

```text
Card 2
Who should attend
Adult beginners who want to practise planning a workshop. Printed practice materials are included. You do not need a phone or laptop.
```

```text
Card 3
What you will practise
Write one learning outcome. Calculate a supplied budget. Build a timed agenda.
```

```text
Card 4
When and where
Saturday 21 November 2026
11 am to noon IST
Learning Room, Adyar, Chennai
Free to attend. Capacity 12.
```

```text
Card 5
How to register
Email learn@example.com. Step-free access is confirmed in the fictional venue note. Discuss specific access needs with the organiser.
Fictional practice event.
```

## 21.4.3 Answer guide

This copy gives a complete starting point. It does not establish an actual account action, a real registration address or a finished visual design. Use the text to build your own deck, then inspect the resulting cards. A correct copy can still become unreadable if the layout crops it or reduces the type too much.

## 21.5.2 Answer guide

The time must be 11 am to noon IST, with the full date Saturday 21 November 2026. Capacity 12 does not mean 12 confirmed learners. No device is needed. Certificates, refreshments and guaranteed skills are unsupported. The contact is learn@example.com, not learning@example.com. The venue is missing. The revised card must restore these details and keep the event clearly fictional.

Keep a correction record with the original claim, the relevant G0 fact and the replacement. This makes it possible to explain a change instead of repeatedly generating until something looks plausible.

## 21.6.2 Worked review record

Record five observations: whether the title is readable, whether the practical details are complete, whether the contact is correct, whether text is editable, and whether any unsupported claim remains. Use observed results from your own deck. Leave the review pending until those checks are performed.

## 21.6.3 Answer guide

A successful draft has five purposeful cards and preserves G0. It may still need design improvements; that is the work of Chapter 22. If a venue line is cropped, record the cropping as an unresolved defect even when the text exists in the editor.

## 21.7.1 Answer guide

The deck must show Saturday 28 November 2026, 3 pm to 4.30 pm IST, Studio Room in Kochi, capacity eight and INR 650 per person. Attendees bring a camera or camera phone. The contact is photos@example.com. Access arrangements are unknown; do not borrow the step-free statement from G0. No registration count or profit is established.
