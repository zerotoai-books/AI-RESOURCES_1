# Chapter 42 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 42.2.2 Worked answer guide

These instructions can guide many workshop documents without embedding one event’s details forever. Putting “capacity twelve” into a permanent style instruction would create a conflict when B2 changes it to ten. If using Projects, add the instruction note and relevant source through the available controls, then confirm the current source in the chat.

Check your work. A project name is not proof of its contents. Inspect the actual files and remove or clearly label superseded versions when a later exercise changes the brief.

## 42.3.2 Worked answer guide

A valid FAQ says the audience is adult beginners, printed materials are provided with no device needed, and maximum capacity is twelve. It does not say twelve places remain. The reminder can be brief while still preserving 21 November, 11 am to noon IST and the Chennai venue. Keeping outputs in one response helps comparison, but does not remove the need to check them.

Check your work. If a document is too long, remove optional description before required facts. Do not abbreviate a timezone into an unexplained or misleading label.

## 42.4.2 Worked answer guide

The FAQ capacity answer becomes ten. An invitation or reminder that never mentioned capacity may remain word for word unchanged. The change log should say those documents were checked and unaffected, rather than inventing a wording change. Maximum capacity ten still does not establish current availability.

Check your work. A correct log names the updated brief and version. Do not change the fee, date or duration simply because the assistant offers a more attractive event description.

## 42.5.2 Worked answer guide

The source capacity is ten. A FAQ saying twelve is a contradiction. A forty word reminder omitting capacity may be acceptable if capacity was not required there. A reminder saying 10 am is wrong even if every other document repeats that mistake. This is why the source column belongs in the matrix.

Check your work. Review all repeated facts, including contact spelling. Similar looking addresses are different addresses; a single extra character can make a handover unusable.

## 42.6.2 Worked answer guide

The handover identifies a single current set. It preserves the older version for comparison without presenting it as ready for use. For this exercise the workshop and contact remain fictional. A real organiser must confirm replacements before publication; producing the copy does not send or publish anything.

Check your work. Open the saved files outside the conversation and check that headings and paragraphs survived copying. If you exported a document, inspect that export rather than relying only on the chat preview.

## 42.7.1 Answer guide after your attempt

Only capacity changes. If all six places were eventually sold at INR 650, the maximum fee revenue would be INR 3900; this is conditional revenue, not collected money or profit. No financial calculation is required in the public copy. The change log identifies which documents mention capacity and checks the others without unnecessary rewriting.
