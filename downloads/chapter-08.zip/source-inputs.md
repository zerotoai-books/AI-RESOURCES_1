# Chapter 8 source inputs

These are fictional teaching sources from the current printed manuscript. Use the exact source ID and scope named in the exercise. Deliberate defects and old versions remain unchanged.

## 8.3 Source A Community workshop brief

CURRENT PRACTICE SOURCE  |  VERSION 1.1

A1 Project
Plan Your First Workshop is a proposed community learning session coordinated by Vishva. The equipment coordinator is the proposed facilitator and Shardha is the reviewer.

A2 Date and time
The date is 21 November 2026. Version 1.1 sets the session time to 10.30 am to 11.30 am IST. It replaces the 10 am to 11 am time in version 1.0.

A3 Audience and capacity
The session is for adult beginners. Capacity is 12 attendees. No registration count is supplied.

A4 Learning format
Use English, paper activities, and a 60-minute session. Attendees must not be required to bring a phone or laptop.

A5 Budget limit
The total planned budget must be at most INR 2400, including the reserve. No participant fee or revenue is agreed.

A6 Supplied costs
Venue: INR 800. Facilitation: INR 900. Printed learner packs: 12 at INR 20 each. The printing figure covers learner resources and facilitator copies. Planning reserve: INR 200. Optional refreshments: 12 at INR 30 each, additional to the core budget. These are fictional planning figures, not current market quotations.

A7 Venue status
Learning Room, Adyar, Chennai is proposed. The room booking is not confirmed.

A8 Open questions
Step-free access and available room equipment have not been confirmed. The brief does not promise refreshments, certificates, parking, or loan devices.

A9 Review condition
The materials must be checked by Shardha. Venue and access questions must be resolved before public invitations are released.

A10 Source status
This is practice brief version 1.1. A room sketch labelled version 1.0 is an illustration and has an outdated time. It does not establish room availability or actual attendance.

## 8.4 Source B Room sketch

OLDER ILLUSTRATION  |  VERSION 1.0

Figure 1 Source B is a supplied practice drawing. Inspect its labels and symbols; it is not a photograph or a measured plan of the venue.

The complete drawing is printed above. Photograph or scan the drawing if an upload is needed. It is intentionally labelled version 1.0 and retains the earlier session time. Do not alter that source before comparing it with version 1.1.

## 8.12 Independent challenge

Source D is the current brief for Book Swap Helpers, version 1.0. The session is planned for 28 November 2026, from 3 pm to 3.45 pm IST, at proposed Community Room, Kochi. Capacity is eight adult volunteers. The venue is not booked. Core costs are venue INR 500, facilitation INR 600, eight learner packs at INR 15, and reserve INR 150. The budget cap is INR 1500. No registration count or fee is supplied.

Source E is the older practice poster printed below, version 0.9, showing 2 pm–2.45 pm IST and “8 volunteers.” Source D governs current facts. If an image upload is needed, capture the complete printed poster and save it as Challenge_Poster_v0_9.png. Its audience wording does not establish registrations.

Figure 2 Source E is an older practice poster. Compare its visible wording with current Source D.

Create an observation and evidence sheet, identify the conflict, calculate the budget and remaining amount, and write a summary under 100 words. Do not turn the poster’s audience wording into a claim that eight people have registered.


## Official tool references

## Gemini

## Official references for the Gemini chapters

Product guidance was checked on 12 October 2026. The references support the Gemini access, file, privacy, and optional learning-tool instructions. The scenarios, source notes, illustrations, budgets, schedules, prompts, worked answers, and marking guides are teaching material created for this book. Follow the current official help if your account or interface differs.

1 Google  Use Gemini Apps
https://support.google.com/gemini/answer/13275745?hl=en
Official web app: https://gemini.google.com

2 Google  Upload and analyse files in Gemini Apps
https://support.google.com/gemini/answer/14903178?hl=en

3 Google  Gemini Apps Privacy Hub
https://support.google.com/gemini/answer/13594961?hl=en

4 Google  Use learning tools in Gemini Apps
https://support.google.com/gemini/answer/16448384?hl=en
