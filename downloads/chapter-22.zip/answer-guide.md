# Chapter 22 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 22.1.2 Worked sequence explanation

Order B introduces the event before asking the reader to register. The audience card lets someone judge whether the session suits them. The practice card explains what they will do. The details card makes attendance practical. The final card gives the contact and access enquiry instruction. Other orders can work, but they must establish the event and its relevance before relying on the registration request.

## 22.1.3 Check your work

Read only the five headings. If they make sense only after reading the body text, revise the headings or order. Do not label every card “About the workshop”; the title should identify its specific purpose.

## 22.2.2 Worked replacement

```text
For adult beginners
Practise planning a workshop through English and paper activities. Write one learning outcome, calculate a supplied budget and build a timed agenda. Printed practice materials are included. No phone or laptop is needed.
```

## 22.2.3 Answer guide

The replacement is specific enough for a reader to decide whether the session is relevant. It retains the supplied tasks and materials while removing claims about mastery, guaranteed confidence and certification. Shortening the original promotional paragraph without removing those claims would leave the main factual problem intact.

## 22.3.2 Worked card and notes

```text
On the card
Write one learning outcome.
Calculate a supplied budget.
Build a timed agenda.
```

```text
Separate speaker notes
A learning outcome describes what a participant should be able to do after a session. The budget exercise uses supplied numbers so learners can check their arithmetic. The agenda exercise gives activities a realistic order and time allowance. These are practice tasks; the brief does not guarantee professional competence.
```

## 22.3.3 Answer guide

The notes expand the card rather than adding essential facts that the audience cannot see. Gamma supports speaker notes and presenter view, but keep a separate text copy for this course so the script remains available during review. [GREF6] Speaker notes being hidden in audience view does not make an exported or shared file confidential; inspect what the chosen export contains.

## 22.4.2 Answer guide

A clear card makes the title and three tasks easy to identify. It does not need a background image, decorative chart or animation to meet this goal. Inspect the actual text contrast and line breaks; selecting a theme does not establish readability. If a contact address wraps awkwardly, adjust its text area and check it again in presentation view.

## 22.5.2 Worked comparison record

| Item | Earlier draft | Revised draft |
| --- | --- | --- |
| Sequence | Record the observed order | Record the observed order |
| Event time | Record readability and accuracy | Record readability and accuracy |
| Practice card | Record crowding or missing tasks | Record the actual change |
| Contact | Record whether it is easy to find | Record whether it is easy to find |

## 22.5.3 Worked rationale for the teaching example

```text
The revised sequence introduces the workshop and its audience before asking for registration. The practice card now gives each of the three tasks its own readable line. Speaker detail is kept separately, so it does not compete with the card's main message. The practical details and exact contact remain visible elsewhere in the deck. This choice follows the teaching comparison; it is not evidence of a completed user test. For my own deck I would replace this note with observations from the actual presentation view and keep any unresolved reading problem in the review record.
```

## 22.5.4 Check your work

“It looks professional” does not explain whether the reader found the time or contact. A useful observation describes the specific item, viewing condition and result. Do not invent a reviewer, a test time or positive feedback to fill the record.

## 22.6.1 Answer guide

The revised deck must still state INR 650 per person and the requirement to bring a camera or camera phone. A title alone is insufficient to explain the session. The 3 pm to 4.30 pm IST event lasts 90 minutes; the three-minute pitch limit used later does not change that duration. Unknown access arrangements should remain unknown.
