## Microsoft Copilot in Excel

## Official references for the Microsoft Copilot in Excel chapters

Product guidance was checked on 14 October 2026 IST. The 2027 label identifies the book edition. Use current official help and account notices because features and eligibility can change.

Worked answers are editorial examples, not captured Gamma or Copilot responses. Practice events, registrations and estimates are fictional. Reviews, rehearsals and app checks remain pending until actually performed.

## EREF1 Microsoft Get started with Copilot in Excel

Current edit plan and chat modes.

https://support.microsoft.com/en-us/excel/copilot/get-started-with-copilot-in-excel

## EREF2 Microsoft Frequently asked questions about Copilot in Excel

Availability licensing formats and calculation settings.

https://support.microsoft.com/en-us/excel/copilot/frequently-asked-questions-about-copilot-in-excel

## EREF3 Microsoft Copilot in Excel tips

Prompt context AutoSave and undo.

https://support.microsoft.com/en-us/excel/copilot/copilot-in-excel-tips

## EREF4 Microsoft Visualize data with Copilot in Excel

Charts and PivotTables.

https://support.microsoft.com/en-us/excel/copilot/visualize-your-data-with-copilot-in-excel

## EREF5 Microsoft Use structured references with Excel tables

Table names and calculated columns.

https://support.microsoft.com/en-us/excel/using-structured-references-with-excel-tables

## EREF6 Microsoft COUNTIFS function

Counts with matching criteria.

https://support.microsoft.com/en-gb/excel/functions/countifs-function

## EREF7 Microsoft SUMIFS function

Conditional seat totals.

https://support.microsoft.com/en-us/excel/functions/sumifs-function

## EREF8 Microsoft Create a PivotTable

Native PivotTable source fields and refresh.

https://support.microsoft.com/en-us/excel/get-started/create-a-pivottable-to-analyze-worksheet-data

## EREF9 Microsoft Apply data validation to cells

Lists numeric rules and error alerts.

https://support.microsoft.com/en-us/excel/get-started/apply-data-validation-to-cells

## Practice sources printed for offline use

These source documents are printed here for the controlled exercises. Type the source text into your tool or create your own saved copy. They are fictional teaching material. Additional datasets and creation instructions appear in the Printed practice materials appendix.

## E0 Excel Practice Brief

E0 Excel practice brief

Fictional workshop records and planning estimates for From Zero to AI by SUNDAR P. They are not real personal data, invoices, market quotes or Copilot transcripts. Event context: Plan Your First Workshop on Saturday 21 November 2026 from 11 am to noon IST. Attendance is free. Capacity is 12. This dataset is an additional Excel teaching scenario; the Gamma brief alone does not establish its registrations.

Each registration row represents one anonymous person and one requested seat. RegistrationID is the stable key; RegistrationDate is the date of the record, not the workshop date. Category is Community or Workplace. Status is Confirmed, Waitlisted, Cancelled or Needs review. Only Confirmed seats count against capacity. Needs review is a placeholder requiring a human decision, not a booking. The initial clean sample has 10 rows: eight Confirmed, one Waitlisted and one Cancelled. Four confirmed seats are Community and four Workplace. The dirty sample has 12 rows, including an exact duplicate of R03 and a new R11 with a missing status.

Approved cleaning rules: preserve the raw sheet; trim ordinary spaces from category and status; standardise the two category names and recognised status spelling; remove one exact repeated R03 record after comparing every field; convert the missing R11 status to Needs review without treating it as Confirmed. The cleaned result has 11 distinct IDs and eight confirmed seats. A repeated ID with conflicting fields must be investigated, not automatically deleted.

Planning inputs: budget limit INR 1500, materials INR 25 per capacity seat, printing INR 15 per capacity seat, one room estimate INR 600. Plan for full capacity, not only confirmed attendees. Supplied estimates include all costs assumed in this exercise; no participant revenue is assumed. At capacity 12 the planned cost is INR 1080 and remaining budget INR 420. These are estimates, not actual spending or profit. The tracker must show available seats and over-capacity seats separately. Missing or invalid inputs must remain visible. Use one authoritative input for each driver. The exercise capacity input accepts whole numbers 1 to 40; this practice range does not authorise a real venue change. Price and budget inputs accept nonnegative numbers.

Build the Starter workbook from Appendix A1 for Chapters 26 to 29. In Chapter 30, build your own Tracker using Appendix A2 and save the completed calculation example yourself. The printed formulas and checks replace a prebuilt workbook. Create and refresh a real PivotTable in Chapter 29; a formula summary or chart does not replace it.

## E1 Independent Cleaning Challenge

E1 Independent cleaning challenge

Use E0’s cleaning rules on the independent Excel records printed in Appendix A1. The repeated I02 is exact. The missing I03 status becomes Needs review. Retain four distinct IDs. Only I01 and I02 are Confirmed, giving two confirmed seats. I04 remains Cancelled.

## E2 Tracker Change Tests

E2 Tracker change tests

Run each change separately, then restore the baseline before the next test. Baseline: capacity 12, budget INR 1500, materials INR 25 per seat, printing INR 15 per seat, room INR 600, eight confirmed seats. Planned cost INR 1080, remaining budget INR 420, available seats four, over-capacity seats zero, capacity used 66.6667 percent. Materials price becomes INR 30: planned cost INR 1140 and remaining budget INR 360. Capacity becomes 10: planned cost INR 1000 and remaining budget INR 500; available seats two; capacity used 80 percent. R07 changes from Waitlisted to Confirmed: confirmed seats nine, available seats three, capacity used 75 percent. Planned cost stays INR 1080 because the basis is full capacity. Budget becomes INR 1000: planned cost stays INR 1080 and remaining budget is negative INR 80. Display Over budget. Clear the materials price: show a missing input and no numeric total or budget remainder. A genuine zero materials price remains valid: planned cost INR 780 and remaining budget INR 720. Set capacity to zero: reject it by validation during normal entry; if an invalid value gets pasted, show an invalid capacity and no percentage pretending to be valid. Duplicate a confirmed registration in a disposable copy: detect repeated IDs and investigate before relying on the increased seat total. Independent Chapter 30 challenge: capacity six and budget INR 900, other prices unchanged. Planned cost INR 840, remaining budget INR 60, available seats zero, over-capacity seats two, capacity used 133.3333 percent. A positive budget remainder does not resolve the booking problem.
