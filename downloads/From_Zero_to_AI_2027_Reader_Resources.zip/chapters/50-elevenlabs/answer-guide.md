# Chapter 50 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 50.2.2 Worked answer guide

The manifest should not claim a Spanish recording exists if only a draft script was prepared. The thirty second field belongs to the promotion target; the longer explanation has its own measured length. A good source map makes these distinctions visible without opening every audio file.

Check your work. Do not apply the B2 capacity update here. The capstone uses the B0 baseline, though the short script does not need to mention capacity.

## 50.3.2 Worked answer guide

The short script printed in Appendix A11 has 46 whitespace-separated words. At an assumed 140 words per minute, its planning estimate is about 19.7 seconds before delivery variation and pauses. This does not establish fit. Measure the actual take. If longer, remove optional description or revise the edit without making critical facts hard to understand.

Check your work. Listen after every timing revision. A take that fits but makes the email or timezone unintelligible does not meet the brief.

## 50.4.2 Worked answer guide

The contact may be spoken before the final card while the literal address remains on screen. A small pause at the end can help the viewer read. If the longer Studio explanation was imported by mistake, replace it with the promotion take rather than speeding the entire explanation into thirty seconds.

Check your work. If you have no video export, submit the alignment plan and mark combined playback Not run. A checked audio file alone does not prove that a future video mix is correct.

## 50.5.2 Worked answer guide

A technically clean file can remain pending language approval. A language approved script can still have a mispronounced audio take. Keep those checks separate. If music is absent, record absent rather than inventing a licence entry. If a file is missing or fails playback, list it as incomplete and repair or regenerate it.

Check your work. For audio quality claims, record what was observed. Do not describe a converted file as original lossless audio merely because its extension is WAV.

## 50.6.2 Worked answer guide

The finished handover is honest about scope. A learner who completed generation includes reviewed audio. A learner without access keeps the full production plan with Not run fields. Neither should invent a recording, approval or audience test. The scripts and record layouts needed for either route are printed in Appendix A11 and A12; there is no required media download.

Check your work. Archive old candidates separately and keep one current manifest. A reviewer should be able to identify the exact English promotion and its script in under a minute.

## 50.7.1 Answer guide after your attempt

A suitable script starts “Join First Steps in Photography on the twenty eighth of November, twenty twenty six, from three to four thirty p.m., Indian Standard Time, at Studio Room, Kochi.” It must also communicate INR 650, bring your camera or camera phone and photos@example.com. That much information may require more than twenty seconds at a clear pace. The correct response is to measure a take and revise the edit or distribute facts across readable titles, not falsely claim an untested script fits.
