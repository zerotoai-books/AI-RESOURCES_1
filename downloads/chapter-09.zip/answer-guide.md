# Chapter 9 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 9.3.2 A checked mapping

| Unit | Practice task | Evidence of learning |
| --- | --- | --- |
| U1 | Write one observable outcome. | It names a task and how to check it. |
| U2 | Sort facts and unknowns from A. | Capacity is separate from registrations. |
| U3 | Calculate the core budget. | Working gives INR 2140 and INR 260 remaining. |
| U4 | Build a 60-minute agenda. | Intervals and durations total 60 with checking. |
| U5 | Assign owners to open questions. | Venue, access, and equipment remain unresolved. |
| U6 | Repair and save a flawed summary. | Each correction has its source and reason. |

Use the table to prevent a common planning mistake: scheduling reading without any checkable output. “Read U3” is an activity. “Calculate the supplied budget and compare the working with the key” tells you what evidence to save.

## 9.4.3 Check your result

• No session starts outside the supplied study window.

• Every session’s activities fit its duration.

• U1–U6 are all covered, with later practice rather than only repeated reading.

• The final assessment has time for corrections.

• The plan states 390 scheduled minutes and gives Sundays zero.

The plan estimates how long the activities will take. If a task proves harder, revise the remaining allocation explicitly. The date table is not evidence that the learner has completed the work; completion belongs in a separate progress record.

## 9.5 Exercise 3 Create questions and verify the answer guide

Goal: produce practice that tests the supplied syllabus. Materials: U1–U6 and A version 1.1. Output: six questions and a source-checked answer guide.

## 9.5.3 A checked answer guide

Q1: One valid outcome is “Calculate the supplied workshop budget and show the working.” It names an action and a way to inspect the result. Basis: U1. Two marks: one for a concrete action and one for a checkable result.

Q2: No. Capacity is supplied, but registrations are not. You cannot subtract an unknown confirmed count. Basis: U2 and A3. Two marks: one for recognising that the answer is unknown and one for naming the missing count.

Q3: Printed learner packs cost 12 × 20 = INR 240. The total is 800 + 900 + 240 + 200 = INR 2140. Remaining budget is 2400 − 2140 = INR 260. Basis: U3, A5, and A6. Two marks: one for the total including reserve and one for the correct remaining budget.

Q4: The given total is 20 + 15 + 20 + 10 = 65 minutes, which exceeds 60 by five. One valid repair is welcome five, lesson 10, practice 15, checking 10, discussion 10, and assessment 10. The sum is 60. Basis: U4 and A4. Two marks: one for identifying the five-minute excess and one for a corrected 60-minute allocation that includes checking.

Q5: “Vishva: confirm what step-free access is available at the proposed venue and whether it meets the audience’s needs.” This is a proposed assignment, not evidence of completion. Basis: U5 and A8. One mark for a specific access action with an owner.

Q6: Record the original time, corrected time, current source version and location, and what output was updated. For this project, A2 version 1.1 replaces 10 am–11 am with 10.30 am–11.30 am IST. Basis: U6 and A2. One mark for an error record that includes the correction and source.

The maximum is 2 + 2 + 2 + 2 + 1 + 1 = 10 marks. Alternative wording can earn full credit when it meets the same rule. The answer guide should not require readers to copy a single sentence word for word.

## 9.6.2 A checked mark record

| Item | Earned | Reason |
| --- | --- | --- |
| Q1 | 2 of 2 | Concrete calculation task with working. |
| Q2 | 2 of 2 | Unknown answer and missing registration count identified. |
| Q3 | 0 of 2 | Reserve omitted; total and remaining amount are wrong. |
| Q4 | 0 of 2 | No five-minute excess identified and no repaired agenda. |
| Q5 | 1 of 1 | Owner and access action are supplied. |
| Q6 | 1 of 1 | Old value, correction, and source are recorded. |

The sample earns six out of 10. The useful diagnosis is more specific: practise including the reserve and checking total durations. The correct answers do not need to be rewritten simply because two other answers failed.

## 9.7.3 A possible change note

```text
Tuesday’s session was missed. U2, U3, and U4 moved one available day later. Saturday now introduces U5 and U6 with 15 minutes each, followed by 15 minutes of checking. Week 2 stays unchanged. The revised total is 360 minutes, not 390. The next review will check whether the shorter U5 and U6 introductions need more practice within the remaining windows.
```

## 9.8.3 Checked answer guide

F1: “Calculate the supplied session budget and show the working” is one valid outcome. Give one mark for a concrete action and one for a checkable result. F2: printing costs 10 × 25 = INR 250; total 700 + 850 + 250 + 150 = INR 1950; remaining 2200 − 1950 = INR 250. Give one mark for each correct result.

F3: available places are 10 − 7 = 3. The two unaccepted requests are not confirmed. Give one mark for the available count and one for the waiting-list distinction. F4: 8 + 15 + 7 + 10 + 5 = 45, so it fits and includes checking. Give one mark for the total and one for the fit and checking conclusion.

F5: no. Remaining budget is unallocated spending capacity, while profit requires revenue information that F does not supply. Give one mark for rejecting the profit claim and one for explaining the missing revenue. The maximum is 10. Do not award a full result for a correct final number with contradictory working.

## 9.9.2 Generate a traceable answer guide

## 9.10.1 Answer guide after your attempt

| Date | Min | One valid allocation |
| --- | --- | --- |
| Mon 16 Nov | 20 | S1: read 10, write an outcome 5, check 5. |
| Tue 17 Nov | 20 | S2: calculate 10, compare working 5, correct 5. |
| Wed 18 Nov | 20 | S3: read 10, classify status 5, check 5. |
| Thu 19 Nov | 20 | S4: compare versions 10, record change 5, check 5. |
| Fri 20 Nov | 20 | Mixed practice 10, corrections 10. |
| Sat 21 Nov | 30 | Independent assessment 20, review 10. |
| Sun 22 Nov | 0 | No study. |

The original total is (5 × 20) + 30 = 130 minutes. If Wednesday is missed, move S3 to Thursday and S4 to Friday, replacing Friday’s mixed practice. Keep Saturday’s assessment and review. The revised total is 110 minutes. State that the extra mixed practice was lost rather than claiming all original activities remain.

Four suitable assessment questions ask for an observable outcome, the budget calculation, the venue status, and the current time. The checked key is: an action with a checkable result; total INR 1370 and remaining INR 130; the venue is proposed and unbooked; use 3 pm–3.45 pm IST from the current brief and record the older poster’s conflict. A score guide can give two marks per question, for a maximum of eight.

## 9.11 Check your understanding

## 9.11.1 Answer guide
