# Chapter 26 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 26.2.2 Worked inspection

The clean starting table is RegistrationTable at A6:E16, with ten records below its header. RegistrationID identifies a record, RegistrationDate is the date it was recorded, Category groups the enquiry, Status records its booking state and Seats is one. RegistrationDate is not the workshop date. Only Confirmed seats count against the capacity.

## 26.2.3 Answer guide

The table has eight Confirmed records, one Waitlisted and one Cancelled. All Seats values are one, so counting confirmed records and adding confirmed seats happen to give the same answer here. They are different measures in a dataset where a row can request several seats. E0 fixes this case to one person per record.

## 26.3.2 Answer guide

If creating the table manually, use Insert, Table and confirm that the selected range has headers. Give the table its intended name. Structured references use table and column names, so the name matters for later formulas. [EREF5] Formatting a range with a blue header does not create a native table or automatic table references.

## 26.4.2 Worked answer

```text
Confirmed seats: 8.
Matching IDs: R01, R02, R03, R05, R06, R08, R09 and R10.
Each matching record requests one seat. R04 is Cancelled and R07 is Waitlisted, so neither is included.
```

## 26.4.3 Check your work

The expected result is eight, not ten. If the reply gives ten, ask which statuses it counted and review the source rows. The presence of ten records does not mean ten confirmed bookings.

## 26.5 Exercise 4 Verify the answer with a formula

## 26.5.2 Answer guide

SUMIFS adds values in a sum range where the corresponding criteria are met. [EREF7] The sum range is Seats and the criterion is Confirmed in Status. Filtering the display does not automatically make an ordinary SUMIFS count only visible rows; this formula applies its stated status criterion to the table. A different visible-row calculation would require a different design.

The manual count of matching IDs and the formula should agree. If they differ, inspect data types, spelling, table coverage and the formula references. Do not replace the formula with the desired number simply to make the checks agree.

## 26.6 Exercise 5 Write a checked explanation

## 26.6.2 Worked explanation

```text
The initial teaching table contains ten records. Eight seats are Confirmed against a capacity of twelve, leaving four available seats. One record is Waitlisted and one is Cancelled. Neither is included in the confirmed total. This is a checked sample calculation, not evidence of real workshop bookings.
```

## 26.6.3 Answer guide

The explanation must match the table and the stated capacity. Four available seats does not decide whether a particular waitlisted person should be confirmed. That would be a separate booking action and would need to be recorded in the table.

## 26.7.1 Answer guide

The raw file has three rows labelled Confirmed because I02 appears twice. It has only two distinct confirmed people, I01 and I02. The duplicate must be resolved before relying on a seat total. I03 has a missing status and I04 is Cancelled. Chapter 28 provides the cleaning rules; do not silently treat the blank as a confirmed booking.
