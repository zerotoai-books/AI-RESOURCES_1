# Chapter 3 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 3.6.2 A possible source inventory

| Source | Version and scope | Check |
| --- | --- | --- |
| Workshop brief | v3; issued 3 November 2026 | Sections A1–A10 readable |
| Ticket sales | Raw v1; orders dated 1–3 November 2026 | 12 rows and six columns |

The fields are Row, OrderID, Date, Quantity, UnitPriceINR, and Status. There are 12 data rows, including one repeated order and one blank status. A row count alone does not establish 12 different orders or 12 people. You will check those quantities in later exercises.

## 3.7.2 Worked evidence table

| Fact | Value | Source |
| --- | --- | --- |
| Event | Everyday AI Workshop | A1 |
| Purpose and audience | Introductory prompting and draft checking for adults new to AI | A1 |
| Date | Saturday 7 November 2026 | A2 |
| Time | 11 am to 1 pm IST | A2 |
| Venue | Learning Room, Adyar, Chennai; confirmed | A3 |
| Fee and capacity | INR 499 per ticket; 12 participants | A4 |
| Materials and devices | Printed learning sheets included; bring own laptop | A4 |
| Booking contact | learn@example.com | A5 |
| Communication owner | Vishva | A5 |
| Equipment and content | the equipment coordinator checks equipment; Shardha reviews content | A5 |

## 3.7.4 Make a targeted correction

Use this correction only if the defect appears in your result. Do not instruct ChatGPT to remove a claim that it never made. Your improvement record should describe what happened in your actual attempt.

## 3.8.2 A checked review note

```text
Raw rows: 12. Distinct OrderIDs: 11. D04 and D07 are identical business records for R004. Retain D04 in the working view and exclude D07 from totals, recording the reason. No conflicting repeated OrderID appears in this dataset. D11, order R010, has a blank status and remains unresolved. All supplied quantities and prices can be read as numbers. The raw source stays unchanged.
```

Keeping D04 rather than D07 is a documented choice between identical records, not evidence that the earlier row was more accurate. If the repeated records disagreed, A8 would require clarification. Do not apply the exact-duplicate rule to records that merely share a name, amount, or date.

## 3.9.2 Checked status totals

| Status | Orders | Tickets | Fee amount INR |
| --- | --- | --- | --- |
| Paid | 7 | 8 | 3,992 recorded receipts |
| Pending | 2 | 2 | 998 not collected |
| Cancelled | 1 | 1 | 499 face value excluded |
| Unresolved | 1 | 1 | 499 face value excluded |
| All distinct orders | 11 | 12 | 5,988 face value |

Paid tickets are 1 + 2 + 1 + 1 + 1 + 1 + 1 = 8, using D01, D02, D04, D05, D08, D10, and D12. Paid receipts are 8 × 499 = INR 3,992. D07 would add INR 499 a second time if it were counted, producing the incorrect total INR 4,491.

Pending tickets are D03 and D09: 1 + 1 = 2. Their fee amount is INR 998, but A7 says it is not paid receipts. The known active total is 8 Paid tickets + 2 Pending tickets = 10. D11 contributes one unresolved ticket, whose active status cannot yet be decided.

The all-orders face value of INR 5,988 includes cancelled and unresolved tickets. It is not a revenue total. Its equality with 12 × 499 at full capacity is a numerical coincidence in this sample; those 12 tickets do not all have the same status.

## 3.11.2 A possible checked summary

```text
The Everyday AI Workshop is on 7 November 2026, from 11 am to 1 pm IST, at Learning Room, Adyar, Chennai. The fee is INR 499 per ticket and capacity is 12 participants.
```

```text
For orders dated 1–3 November, the working analysis records eight Paid tickets and INR 3,992 in paid receipts. Two Pending tickets add to 10 known active tickets but contribute no paid receipts. R004 was counted once; source row D07 exactly repeats D04.
```

```text
R010 has one ticket with an unresolved status. Confirm that status before publishing an exact remaining-place count. Refund terms and loan-device availability are not confirmed in the brief.
```

## 3.13.1 Answer guide after your attempt

There are six raw rows and five distinct orders. C04 exactly repeats C01 and is excluded from the working totals. Two Paid orders contain three tickets, giving paid receipts of INR 600. One Pending ticket gives four known active tickets. One Cancelled ticket is inactive, and X04 has one unresolved ticket. The total distinct-order ticket quantity is six.

A good summary states the Photography event facts and these checked figures, then asks for X04’s status before publishing remaining availability. It does not infer that six unique people have registered from six source rows. Your sentences can differ if the facts, calculations, and limitations remain correct.

## 3.14.1 Questions to answer in your own words

## 3.14.2 Answer guide
