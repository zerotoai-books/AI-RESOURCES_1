# Chapter 27 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 27.1.2 Answer guide

The three lines are one room booking at INR 600, twelve materials sets at INR 25 and twelve printing sets at INR 15. Their quantities have different meanings even though the same multiplication applies. The sample supplies no actual invoices or participant revenue.

## 27.2.2 Worked formula

```text
=[@Quantity]*[@UnitCost]
```

## 27.2.3 Worked results

| Item | Quantity | Unit cost INR | Total INR |
| --- | --- | --- | --- |
| Room | 1 | 600 | 600 |
| Materials | 12 | 25 | 300 |
| Printing | 12 | 15 | 180 |

## 27.2.4 Answer guide

The @ reference means the current row of the Excel Table. [EREF5] An ordinary cell formula such as =B7*C7 can also be correct for the first cost row, provided it is copied correctly. Check later rows instead of assuming that a formula which works once will work throughout the table.

## 27.3.1 Your task

Add a small summary outside the cost table. Keep the spending limit as one labelled input, then calculate the total and remaining amount from formulas.

```text
B13: =SUM(CostTable[LineTotal])
B14: =B12-B13
```

## 27.3.2 Answer guide

The total is INR 1080 and the remaining budget INR 420. SUM adds the three cost lines. A formula that includes both the lines and another total would double-count the estimate. The remaining amount is a difference between a proposed limit and planned costs, not cash in a bank account or event profit.

If you use different cells, record their actual locations and update the references consistently. Formatting the remaining amount as INR does not establish that its formula points to the right cells.

## 27.4.2 Answer guide

Both formulas return eight in this one-person-per-row case. COUNTIFS counts records that satisfy the criterion; SUMIFS adds their Seats. [EREF6, EREF7] Eight divided by twelve is approximately 0.666667, displayed as 66.7% with one decimal. Formatting 66.6667 as a percentage would instead show about 6666.7%, because the value has already been multiplied by 100.

Treat a missing or zero capacity as a problem to resolve, rather than a genuine 0% utilisation result. Chapter 30 will add the necessary input guards and separate available seats from over-capacity seats.

## 27.5.2 Worked guarded formula

```text
=IF(AND(ISNUMBER([@Quantity]),ISNUMBER([@UnitCost])),
  [@Quantity]*[@UnitCost],"Missing input")
```

## 27.5.3 Answer guide

At INR 30, materials cost INR 360, total planned cost INR 1140 and remaining budget INR 360. A simple multiplication may turn a blank into zero, so it can conceal the missing price. The guard keeps the omission visible. A numeric zero price remains valid and would give materials cost zero, total INR 780 and remaining budget INR 720.

SUM ignores text such as Missing input. Therefore a guarded line alone is insufficient if the total still silently adds only the available costs. Check that all three LineTotal cells are numeric before displaying a complete total. For example, use IF with COUNT and ROWS before SUM; Chapter 30 gives the complete pattern.

## 27.6.1 Answer guide

The starting lines are INR 450, INR 120 and INR 60, giving total INR 630 and remaining budget INR 270. At INR 22, materials become INR 132, total INR 642 and remaining budget INR 258. Retain formulas and restore the starting price after recording the test.
