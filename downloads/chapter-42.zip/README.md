# Chapter 42 Write and revise a consistent document set

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 42.2 Exercise 1 Write reusable instructions

Step 1  Create an instruction note for plain English, adult beginners and concise logistics.

Step 2  Require unknown facts to stay unknown and sources to be named.

Step 3  Keep the actual date, capacity and venue in the source brief.



## 42.3 Exercise 2 Create the first document set

Step 1  Ask for three labelled sections in one response.

Step 2  Specify the required facts and a practical length for each.

Step 3  Compare repeated facts across all three sections.



## 42.4 Exercise 3 Apply a specific update

Step 1  Save the B0 set as version one.

Step 2  Supply B2 and ask for a version two set.

Step 3  Require a change log and list any document that did not need wording changes.



## 42.5 Exercise 4 Audit the set for consistency

Step 1  Create rows for date, time, venue, fee, capacity and contact.

Step 2  Compare each document with B0 plus B2.

Step 3  Mark Not mentioned where a short document legitimately omits a non required fact.



## 42.6 Exercise 5 Prepare an editable handover

Step 1  Save the three final sections as editable text or documents.

Step 2  Include the source brief and B2 update in the review folder.

Step 3  Add the change log, factual audit and approval status.

