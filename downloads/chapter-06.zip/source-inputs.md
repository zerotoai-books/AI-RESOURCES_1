# Chapter 6 source inputs

These are fictional teaching sources from the current printed manuscript. Use the exact source ID and scope named in the exercise. Deliberate defects and old versions remain unchanged.

## 6.3 The topic for your first conversation

We will learn the difference between a venue’s capacity, confirmed bookings, and places still available. These are ordinary planning ideas that you can verify with a few numbers. Keeping them separate will matter when you later turn a brief or image into a summary.

## 6.3.1 Source note C1 for this chapter

Capacity is the maximum number of attendees allowed for the session. A confirmed booking is a place that the organiser has accepted. In this practice scenario, each confirmed booking reserves one place. Places available equal capacity minus confirmed places, provided there are no other holds or restrictions. A waiting-list request is not a confirmed booking unless the organiser accepts it. If the booking count is not supplied, the number of places available is unknown.

Practice case: the room capacity is 12 attendees. Eight places are confirmed. There are no other holds. Three people are on a waiting list. The organiser has not accepted those three requests.

This note defines the rules for our fictional example. Real organisations may use different booking rules. Use the supplied rules when checking these exercises, and ask for the actual rules when working on a real event.

## 6.11 Independent challenge

Use a fresh topic: stock, reservations, and units available. Source C3 defines the rules. Stock is the number of units physically held. A reservation sets aside one unit for an accepted customer request. Units available for a new request equal stock minus reserved units when no other restrictions apply. A request waiting for acceptance does not reserve a unit.

A fictional bookshop has 30 notebooks in stock, 12 reserved units, and no other restrictions. Five requests are waiting. The shop accepts three requests, reserving one unit for each, and receives four more notebooks into stock. No notebooks have yet been collected or sold.

Write your own prompt and obtain an explanation under 120 words. Ask one follow-up, check every number, then write a summary yourself. Save a record explaining how the revision improved the response.


## Official tool references

## Gemini

## Official references for the Gemini chapters

Product guidance was checked on 12 October 2026. The references support the Gemini access, file, privacy, and optional learning-tool instructions. The scenarios, source notes, illustrations, budgets, schedules, prompts, worked answers, and marking guides are teaching material created for this book. Follow the current official help if your account or interface differs.

1 Google  Use Gemini Apps
https://support.google.com/gemini/answer/13275745?hl=en
Official web app: https://gemini.google.com

2 Google  Upload and analyse files in Gemini Apps
https://support.google.com/gemini/answer/14903178?hl=en

3 Google  Gemini Apps Privacy Hub
https://support.google.com/gemini/answer/13594961?hl=en

4 Google  Use learning tools in Gemini Apps
https://support.google.com/gemini/answer/16448384?hl=en
