# Chapter 20 Build a workshop promotion kit

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 20.2.1 Your task
Word body block 3562

```text
Plan a coordinated fictional workshop promotion kit from C0 version 2 and C1. List the five designs and the text caption, their dimensions, essential facts and intended exports. Keep publication and reviewer approval pending until they are recorded. Do not add an event fee, sponsor or promise.
```

## 20.5.1 Your task
Word body block 3623

```text
Write a handover note for my completed practice kit using the actual file and design records I supply. Name the current brief and release version, list remaining review or print checks and state the next decision. Do not invent approval, publication, bookings or audience reactions.
```

## 20.6.1 Your task
Word body block 3637

```text
Apply C3 to the entire promotion kit. Change 10.30 am to 11.30 am IST to 11 am to noon IST everywhere. Preserve the event date, venue, audience, free attendance, capacity, contact and device requirement. Create a v3 change record and keep v2 archived. Do not claim that every export changed until I have inspected the actual files.
```
