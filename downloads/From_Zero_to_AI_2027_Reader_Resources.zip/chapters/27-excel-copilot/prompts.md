# Chapter 27 Create formulas and inspect the results

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 27.1.1 Your task
Word body block 4214

```text
Explain the required calculation for CostTable on Costs. Quantity is the number of units and UnitCost is INR per unit. LineTotal should be Quantity multiplied by UnitCost. Check for missing or nonnumeric inputs and explain any issue. Do not edit the sheet yet.
```

## 27.2.1 Your task
Word body block 4225

```text
In CostTable on Costs, fill LineTotal with formulas that multiply each row's Quantity by its UnitCost. Keep Item, Quantity and UnitCost unchanged. Explain the formula and tell me which cells you changed. Do not replace formulas with fixed amounts.
```

## 27.5.1 Your task
Word body block 4269

```text
Review CostTable's LineTotal formulas for missing or nonnumeric Quantity and UnitCost. Revise them to display Missing input when either required value is absent or not numeric. Preserve a genuine numeric zero price. Explain the revised formula and keep the original input values unchanged.
```
