# Chapter 11 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 11.3.2 Worked answer after checking

```text
Canva describes PDF Print as its download format for printing. Its help also lists print-related export options. I still need to check the printer's required page size, bleed and colour settings before sending the file. [P5]
```

This is an editorial worked answer based on the official page, not a captured Perplexity response. Your result may use different wording or sources. Check the underlying claim against the current page. Do not copy a statement about printer settings into your record as though Canva promised that every printer accepts the same settings.

## 11.3.3 Check your work

You should have one question, the original AI response and at least one source URL. A reply with no inspectable source is unfinished. If the app gives a general Canva homepage, ask for the specific help page; a homepage does not locate the evidence.

## 11.4.2 Worked evidence note

```text
S1 — Canva, Choose the right download file type for your Canva design.
URL: https://www.canva.com/help/download-file-types/
Location: Document section, PDF Print entry.
Accessed: 14 October 2026 IST.
My paraphrase: Canva identifies PDF Print as intended for print output.
Claim status: Supported for the stated file type. Printer-specific requirements remain to be checked.
```

The location makes the note reproducible even if the browser does not give paragraph numbers. If you use a PDF source with page numbers, record the page as well. If a web page changes later, the access date tells a reviewer when you inspected it.

## 11.4.3 Check your work

Close the tab, reopen the URL from your note and find the same section. If you cannot reproduce your own route, improve the record. A useful source note lets another reader repeat the check without asking you where to look.

## 11.5.2 Answer guide

The source supports choosing PDF Print for printing. It does not establish that a low-resolution source image becomes sharp, that every colour will print exactly as it looks on your screen, or that every print provider accepts every exported file. Those guarantees should be removed. One valid practical check is to open the actual export and ask the intended printer to confirm the required specifications.

Your revised answer might say: “Use PDF Print as the starting format for a print design, then inspect the exported file and confirm the printer's requirements.” This is a recommendation derived from the workflow, rather than a promise from the source.

## 11.5.3 Check your work

Give each remaining factual claim a source or a clear label explaining that it is your recommendation. Do not let a supported first clause hide unsupported claims later in the same sentence.

## 11.6.2 Worked limitation note

```text
S2 — Original page unavailable during my check. Its claim remains unresolved.
Next action: look for an official replacement and compare its scope. If no usable source is found, omit the claim from the final answer or state that it could not be verified.
```

Do not change unresolved to supported because two other AI answers repeat the sentence. Repetition may trace back to the same missing source. When the original evidence is unavailable, describe that limit plainly.

## 11.7 Exercise 5 Save a checked answer

## 11.7.2 Worked final answer

```text
Canva's official help identifies PDF Print as the format intended for printing a design. Before sending the file, check the print provider's page size, bleed and colour requirements and inspect the actual export. [S1]
```

## 11.7.3 Answer guide

The answer is concise, gives the main result and preserves the practical condition. S1 must point to your inspected page, not to a list of unrelated sources. A correction log could read: “Removed the claim that PDF Print guarantees sharp images because the source did not establish it.”

## 11.8.1 Answer guide

Canva's file-type help states that DOCX download applies to Canva Docs, rather than every Canva design type. [P5] A poster should not be described as automatically becoming an editable Word layout. Record the exact current scope when you check. The existence of a DOCX option also does not prove that formatting will be identical in Word.
