# Chapter 10 Build a training resource pack

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 10.2 Exercise 1 Align the outcomes with practice and assessment

Step 1  Paste A and U1–U6 into a fresh chat.

Step 2  State the selected concept and 60-minute limit.

Step 3  Ask for the outcome mapping below.

Step 4  Check that each outcome can be demonstrated within the supplied project.

Step 5  Save the mapping before generating the lesson.



## 10.3 Exercise 2 Write the short lesson

Step 1  Ask for a lesson script with clear learner actions.

Step 2  Read it aloud to check the pace and vocabulary.

Step 3  Check every project fact against A.

Step 4  Recalculate any example before keeping it.

Step 5  Use the facilitator plan to allocate the pauses rather than assuming text length alone establishes duration.



## 10.4 Exercise 3 Create a worksheet learners can use

Step 1  Ask for the learner version without answers.

Step 2  Check that the instructions provide all necessary inputs.

Step 3  Make the writing spaces and calculation fields readable.

Step 4  Create the answer guide separately.

Step 5  Compare every answer with A and the syllabus.



## 10.5 Exercise 4 Write facilitator notes with a realistic schedule

Step 1  State the actual start and end times before generating the schedule.

Step 2  Ask for notes that use the completed resources.

Step 3  Check every clock interval and its duration.

Step 4  Read the notes as a facilitator who has not seen the chat.

Step 5  Run a rehearsal and record where the plan needs adjustment.



## 10.6 Exercise 5 Create an assessment that matches the outcomes

Step 1  Ask for an assessment tied to L1–L3.

Step 2  Check that every question can be answered from the source and lesson.

Step 3  Separate the learner sheet from the key.

Step 4  Apply the marking rule to a sample answer.

Step 5  Correct the key before using a score to judge a learner.



## 10.6.2 Complete learner assessment

Step 1  T1 Write three supplied project facts and one unresolved fact, with source labels. Four marks.

Step 2  T2 Calculate the core planned total and remaining amount under the cap. Show the reserve in your working. Two marks.

Step 3  T3 Write a 60-minute agenda that includes a checking stage. Give durations and the total. Two marks.

Step 4  T4 A note says “The workshop starts at 10 am and 12 people are registered.” Correct both claims from the current brief. Two marks.



## 10.7 Exercise 6 Review the complete pack and prepare a handover

Step 1  Build a consistency checklist from A version 1.1.

Step 2  Compare each fragment with the source and completed resources.

Step 3  Record the defect, affected resource, and repair.

Step 4  After correcting, inspect every occurrence of the changed fact.

Step 5  Save a review note with open arrangements and review status.



## 10.9.3 Worked challenge worksheet

Step 1  CW1 Write two supplied facts and one unresolved arrangement from the brief.

Step 2  CW2 Calculate each core cost, total, and remaining budget. Show the reserve.

Step 3  CW3 Test the sticker-kit proposal and state the amount above or below the cap.

Step 4  CW4 Create a 45-minute agenda with practice and checking; give the total.



## 10.9.5 Worked challenge assessment and key

Step 1  CA1 Calculate the core total and remaining budget. Two marks: INR 1370 and INR 130, with correct working.

Step 2  CA2 Does adding sticker kits fit? Two marks: new total INR 1570 and rejection because it exceeds the cap by INR 70.

Step 3  CA3 Name one unresolved arrangement and give a 45-minute agenda containing checking. Two marks: a genuine unknown, such as venue booking, and a complete checked agenda.



## 10.10 Check your understanding

Step 1  Why write the outcome map before the lesson?

Step 2  Which resources should keep the answer guide separate?

Step 3  What makes the main assessment’s marking transparent?

Step 4  Why does a nine-out-of-10 learner still need to repair a registration claim?

Step 5  What is complete when the mini-course is ready for human review?



## 10.10.1 Answer guide

Step 1  It ties the explanations, practice, and assessment to tasks the learner can demonstrate.

Step 2  The learner worksheet and individual assessment.

Step 3  Each question has a stated mark rule, a source basis, and allowance for equivalent correct answers.

Step 4  The score does not make an unsupported claim acceptable.

Step 5  The learning resources and checked working are present; unresolved venue and approval conditions remain visible.

