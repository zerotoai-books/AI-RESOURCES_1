# Chapter 47 Control pronunciation pacing and expression

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 47.2.1 Useful prompt or direction
Word body block 5871

```text
Pronunciation planning: Read IST as Indian Standard Time. Read the date as the twenty first of November, twenty twenty six. Test Adyar and Chennai with a listener who recognises those place names. Keep the literal email spelling in the text handover.
```

## 47.3.1 Useful prompt or direction
Word body block 5881

```text
Test A: Join us on the twenty first of November, twenty twenty six, from eleven a.m. to noon, Indian Standard Time. Test B: Join us on the twenty first of November, twenty twenty six. The session runs from eleven a.m. to noon, Indian Standard Time.
```

## 47.4.1 Useful prompt or direction
Word body block 5891

```text
Dictionary test rule: written term IST; alias Indian Standard Time. Test sentence: The workshop runs from eleven a.m. to noon IST. Record the model and dictionary version used.
```

## 47.5.1 Useful prompt or direction
Word body block 5901

```text
Delivery direction for your review sheet: friendly, clear and unhurried. If the chosen model supports expressive tags, test one restrained direction in a short sentence before using it throughout. Otherwise keep ordinary text and available settings.
```

## 47.6.1 Useful prompt or direction
Word body block 5911

```text
Pronunciation signoff: item ___; intended reading ___; actual observation ___; reviewer ___; status Pass, Needs revision or Pending. Record the take and timestamp for every issue.
```
