# Chapter 1 source inputs

These are fictional teaching sources from the current printed manuscript. Use the exact source ID and scope named in the exercise. Deliberate defects and old versions remain unchanged.

## 1.7.1 The supplied facts

Event: Everyday AI Workshop. Date: 7 November 2026. Time: 10 am to noon, India Standard Time. Venue: Learning Room, Adyar, Chennai. Audience: adults new to AI. Fee: INR 499 per person. Capacity: 12 attendees. Materials: included. Booking contact: learn@example.com. The address is an example for practice; do not send messages to it.

## 1.8.1 Meeting notes to paste

Workshop planning meeting on 20 October 2026. Vishva to draft the invitation by 22 October. The equipment coordinator to check the projector; no date agreed. Registration cap stays at 12. Venue confirmation is still pending. Poster needs a final reviewer but nobody assigned. Ask attendees to bring laptops, but loan laptop availability has not been confirmed. Next meeting date not decided.

Use these meeting notes only for this extraction exercise. They describe an earlier planning stage. Later versioned workshop briefs establish the current project facts; do not silently overwrite them with an old unresolved note.

## 1.9.1 Order details

| Item | Quantity | Unit price INR |
| --- | --- | --- |
| Notebooks | 12 | 40 |
| Pens | 20 | 10 |
| Folders | 5 | 30 |

## 1.10.2 Make a controlled revision

A controlled revision changes only the authorised facts while keeping the rest of the pack consistent. In this exercise, change the workshop time to 11 am–1 pm IST on the same date. Ask for the update across every affected item, then compare the old and new versions. Check that the date, venue, contact and other unchanged details are preserved and that no old time remains.

## 1.17 Independent challenge

Create an invitation and reminder for a fictional “First Steps in Photography” session. Date: 14 November 2026. Time: 3 pm to 5 pm IST. Location: Studio Room, Kochi. Fee: INR 650. Capacity: 10. Participants must bring their own camera or camera phone. Booking: photos@example.com. This is a practice contact, not a sending destination.

Write your own prompt before using any prompt from this chapter. Produce an email body under 100 words and a reminder under 50 words. Then change the capacity to eight and update the materials. Save a note explaining what changed. Do not add refreshments, certificates, parking, or equipment loans.


## Official tool references

## ChatGPT

## Official references for the ChatGPT chapters

The references support the general product use and prompting guidance. The workshop scenarios, datasets, prompts, sample answers, plans, and assessments are teaching material. Product guidance was checked on 11 October 2026. Follow the current official instructions if your account or screen differs.

1 OpenAI  Use ChatGPT
https://learn.chatgpt.com/docs/use-chatgpt

2 OpenAI  Prompting
https://learn.chatgpt.com/docs/prompting

3 OpenAI  ChatGPT on the web
https://learn.chatgpt.com/docs/web
