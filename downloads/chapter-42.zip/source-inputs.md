# Chapter 42 source inputs

These are fictional teaching sources from the current printed manuscript. Use the exact source ID and scope named in the exercise. Deliberate defects and old versions remain unchanged.

## Claude

## Official references for the Claude chapters

Product guidance was checked on 15 October 2026. The 2027 label identifies the book edition. Use the current official guide and account notices when controls, access or model support differ. The exercises, prompts, scripts and worked answers are original teaching examples.

The supplied fixture arithmetic and the reference calculator core were executed and checked. Browser interaction and any separately generated Claude artifact still require learner testing. No signed in Claude session was performed.

## C1 Anthropic Upload files to Claude

Supported files and text extraction limitations.

https://support.claude.com/en/articles/8241126-upload-files-to-claude

## C2 Anthropic What are projects

Project instructions, files and staged beta differences.

https://support.claude.com/en/articles/9517075-what-are-projects

## C3 Anthropic What are artifacts and how do I use them

Artifacts and account dependent options.

https://support.claude.com/en/articles/17153992-what-are-artifacts-and-how-do-i-use-them

## Practice sources printed for offline use

These printed briefs supply the exercise facts. Type the text needed for your task or save your own working file. All events, records and reviewer names are fictional. Preserve the stated scope when an update applies only to one exercise.

## B0 Main Workshop

B0 Main workshop baseline version 1 dated 15 October 2026

This is a fictional teaching event. Event name: Plan Your First Workshop. Date: Saturday 21 November 2026. Time: 11 am to noon IST, meaning Indian Standard Time. Venue: Learning Room, Adyar, Chennai. Audience: adult beginners. Attendance is free. Maximum capacity is twelve; this does not state live availability.

The activity is in English and uses paper. Printed materials are provided. No phone or laptop is needed. Booking contact: learn@example.com, a practice placeholder. Step free access is confirmed for this fictional venue, but specific needs should be discussed through the contact route. Do not promise universal suitability.

Certificates, refreshments, parking, transport, loan devices and sponsors are not confirmed. Do not invent them. Any image you create for these exercises is illustrative, not a photograph establishing the fictional venue. Shardha is a fictional reviewer; approval is Pending. No real booking, message or public release is authorised by this practice brief.

## B1 Photography

B1 Separate Photography challenge version 1 dated 15 October 2026

Event: First Steps in Photography. Saturday 28 November 2026, 3 pm to 4.30 pm IST. Venue: Studio Room, Kochi. Audience: adults. Capacity: eight. Fee: INR 650 per person. Participants bring their own camera or camera phone. Booking contact: photos@example.com, a practice placeholder.

Access arrangements are unknown. Do not promise food, certificates, parking, equipment loans or confirmed attendance. This ninety minute event is separate from B0. All details are fictional. Any generated imagery is illustrative. Approval is Pending.

## B2 Capacity Update

B2 Scoped update for Chapter 42 only

Apply this update only to the Chapter 42 main workshop document set: maximum capacity changes from twelve to ten. Every other B0 fact remains unchanged. Capacity is not a count of places left. Save the updated set as version two and keep the B0 baseline intact. Chapters 43 to 45 and the voice capstone return to B0 capacity twelve unless a separate challenge says otherwise.

## B3 Registration Rules

B3 Registration fixture rules version 1

The Claude registration table printed in Appendix A8 has eleven fictional records, one per ID R01 through R11. Only Confirmed consumes a place. Cancelled, Waitlisted and Needs review do not consume confirmed places. Available places equal B0 capacity twelve minus Confirmed records. Do not infer that a waiting-list request is accepted.

Count category only within Confirmed for the category summary. The baseline has four confirmed Community and four confirmed Workplace records. All records are teaching fixtures, not live bookings. Preserve the baseline when making challenge copies. The local calculator takes counts only and neither stores nor reserves places.

## B4 Budget and Agenda

B4 Full capacity planning version 1

Use capacity twelve for the baseline budget even when only eight fixture records are Confirmed. Room cost INR 600. Materials cost INR 25 per planned attendee. Printing costs INR 15 per planned attendee. Budget limit INR 1500. Attendance is free; no ticket revenue is supplied. The difference between limit and planned cost is unallocated budget, not profit.

The agenda runs 11 am to noon IST: welcome five minutes, example ten, guided practice fifteen, independent practice fifteen, review ten and close five. The agenda is a plan, not evidence that a session ran. Reviewer approval remains Pending.
