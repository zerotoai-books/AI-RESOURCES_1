# Chapter 33 Debug problems using reproducible examples

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 33.1.2 Worked observations
Word body block 4786

```text
I am debugging my calculator_buggy.py, typed from the printed listing. K1 says price 25, quantity 12 and discount 10 percent should give total 270.00, but the program prints 290.00. The printed regression test fails. Read this exact file and the failure I supply. First explain a minimal reproduction and likely calculation mismatch. Do not edit files yet.
```

## 33.2.1 Your task
Word body block 4797

```text
Trace buggy_total("25", "12", "10") without changing it. Show the subtotal, the value subtracted and the returned result. Explain the units at each step. Compare them with K1's percentage and rounding rules. Do not change the expected test value to make the test pass.
```

## 33.3.1 Your task
Word body block 4815

```text
Help me inspect this Python failure in VS Code. Identify a useful breakpoint and the variables to watch for the 25, 12, 10 input. Explain what should be visible before the return line executes. Do not claim a debugging session happened unless I provide observations or the relevant tool run is recorded.
```

## 33.4.1 Your task
Word body block 4829

```text
Patch only the percentage calculation in my learning copy of calculator_buggy.py. Keep the existing function name and arguments so the original failing test still calls it. Compute and round the discount as K1 specifies. Show the exact change and rerun the original failing test if execution is available. Do not add dependencies or rewrite the project.
```

## 33.5.1 Your task
Word body block 4844

```text
Review the repair using the original 25, 12, 10 case and the independent 40, 5, 15 case. Explain why one passing example is insufficient. Preserve the independently calculated expected totals. Identify which validation remains outside the minimal reproduction and where the complete calculator handles it.
```
