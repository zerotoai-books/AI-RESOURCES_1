# Chapter 17 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 17.2.2 Answer guide

A successful revision changes emphasis, spacing or placement while preserving the facts. If the tool changes “Capacity 12” to “Only 12 spots left,” restore the original copy. If a chat-based edit is unavailable, make the same changes manually and record the route.

## 17.3.2 Worked design note

```text
Version B uses one type family with two weights. The title is largest. Date and time are a second group. Venue and contact are large enough to read without searching. Supporting details are smaller but remain legible. The email address is on one line and has space above and below it.
```

## 17.3.3 Check your work

Font size alone does not prove readability. A condensed typeface, a long line or poor contrast can still make the text difficult. If you rebuild the design for a phone format, set the type in that format and test it again rather than carrying over print point sizes mechanically.

## 17.4.2 Answer guide

One valid solution uses a white background with navy text and a small amber accent. Another uses a navy title panel with white lettering and a white information area. A successful choice has legible text, a clear grouping and a visible contact. Improved visual contrast does not establish complete accessibility for all users or delivery channels.

## 17.5.2 Worked observation template

| Item | Version A | Version B |
| --- | --- | --- |
| Event name | Record what happened | Record what happened |
| Date and time | Record what happened | Record what happened |
| Venue | Record what happened | Record what happened |
| Registration | Record what happened | Record what happened |

## 17.5.3 Answer guide

Fill the table with real observations. Do not invent a reviewer or a response time. A useful note says “The contact needed zooming” or “The date and time were found together.” “B is more professional” is a judgement without enough detail to explain what improved.

## 17.6.2 Worked rationale for the teaching layouts

```text
I would select version B from the supplied teaching comparison because its title is clearly larger than the supporting text, and its date and time sit together. The venue and registration instruction have separate space, making the next action easier to locate. Both versions must still be checked against C1 before use. This choice is based on inspecting the teaching layouts, not on a recorded user test. For my own poster, I would replace this note with observations from the actual exported files at phone size and keep any unreadable line in the correction record.
```

## 17.6.3 Answer guide

The rationale states what improved and the limits of the observation. Your selected version does not have to be B if your actual A is clearer. Choose on the evidence from your files rather than matching the letter in the worked example.

## 17.7.1 Answer guide

The selected design should preserve the fee of INR 650, capacity eight, the correct time and venue, and the requirement to bring a camera or camera phone. A design that hides that requirement below an oversized picture is weak even if the image looks attractive. Do not add a promise of loan equipment to avoid the space problem.
