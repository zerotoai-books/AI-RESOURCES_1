import subprocess
import sys
import unittest
from decimal import Decimal
from pathlib import Path
from calculator import quote

HERE = Path(__file__).resolve().parent


class QuoteTests(unittest.TestCase):
    def test_baseline_components(self):
        q = quote("25", "12", "10")
        self.assertEqual(q.subtotal, Decimal("300.00"))
        self.assertEqual(q.discount, Decimal("30.00"))
        self.assertEqual(q.total, Decimal("270.00"))

    def test_independent(self):
        self.assertEqual(quote("40", "5", "15").total,
                         Decimal("170.00"))

    def test_rounding_order(self):
        self.assertEqual(quote("0.05", "3", "10").total,
                         Decimal("0.13"))
        self.assertEqual(quote("0.05", "1", "50").total,
                         Decimal("0.02"))

    def test_other_valid_inputs(self):
        cases = [("0", "1", "0", "0"),
                 ("25", "12", "100", "0"),
                 ("19.99", "3", "10", "53.97"),
                 (" 25 ", "12", "0", "300"),
                 ("100000", "40", "0", "4000000")]
        for price, count, percent, expected in cases:
            with self.subTest(price=price, percent=percent):
                self.assertEqual(quote(price, count, percent).total,
                                 Decimal(expected))

    def test_invalid_inputs(self):
        cases = [("NaN", "1", "0"), ("Infinity", "1", "0"),
                 ("25.001", "1", "0"), ("-1", "1", "0"),
                 ("INR25", "1", "0"), ("1e2", "1", "0"),
                 ("1,000", "1", "0"), ("100000.01", "1", "0"),
                 ("", "1", "0"), ("25", "0", "0"),
                 ("25", "41", "0"), ("25", "12.5", "0"),
                 ("25", "1", "101"), ("25", "1", "-1"),
                 (True, "1", "0"), ("25", 1, "0")]
        for args in cases:
            with self.subTest(args=args):
                with self.assertRaises(ValueError):
                    quote(*args)

    def test_command_and_import(self):
        def run(*args):
            return subprocess.run(
                [sys.executable, *args], cwd=HERE,
                capture_output=True, text=True
            )
        result = run("calculator.py", "25", "12", "--discount",
                     "10")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Total INR 270.00", result.stdout)
        self.assertNotEqual(
            run("calculator.py", "25", "12.5").returncode, 0
        )
        self.assertEqual(run("-c", "import calculator").stdout, "")


if __name__ == "__main__":
    unittest.main()
