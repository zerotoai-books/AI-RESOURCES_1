# Chapter 15 Build a research dossier for a decision

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 15.3.1 Your task
Word body block 3061

```text
Create a decision checklist from R0. Assess eligibility before preferences. A candidate must meet every mandatory requirement and the full-period budget. Use unresolved when evidence is missing. Do not make up weighted scores or treat cheapness as compensation for a failed requirement.
```

## 15.4.1 Your task
Word body block 3076

```text
Compare A Plus, B and C using only the supplied current sources. Show record capacity, workflow requirements, full three-month cost, purchase term and eligibility against R0. Separate documented results from untested usability and accessibility.
```

## 15.5.1 Your task
Word body block 3098

```text
Assemble the Learning Circle dossier from my checked brief, source log, matrix and calculations. Preserve source IDs. Include an eligible alternative, unresolved questions, trial tasks and a decision record that says approval is pending. Do not convert a proposed trial into a completed result.
```

## 15.6.1 Your task
Word body block 3118

```text
Turn the proposed trial into a checklist with expected result, observed result and status. Do not claim a pass until I supply an observation. Explain what three dummy records can establish and what they cannot establish about capacity.
```

## 15.7.1 Your task
Word body block 3137

```text
Reassess the dossier for three independent changes: B costs INR 400 per month; B costs INR 450 per month; or R0 needs 110 records. Keep every other fact unchanged for each case. Explain whether the current evidence supports a candidate and what must be checked next.
```
