# 01_workspace

Printed reference recovered without code changes. Python 3.12 or later and the standard library. The review reran it on 3.12.14.

Run `python hello_workshop.py`. Expect Available seats: 4. Use the interpreter command appropriate to your computer.

Keep the baseline unchanged and use a working copy. This is a local teaching example.
