import unittest
from decimal import Decimal
from calculator_buggy import buggy_total


class BugTest(unittest.TestCase):
    def test_original_failure(self):
        self.assertEqual(
            buggy_total("25", "12", "10"), Decimal("270.00")
        )


if __name__ == "__main__":
    unittest.main()
