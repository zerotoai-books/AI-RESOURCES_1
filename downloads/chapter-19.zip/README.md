# Chapter 19 Adapt a design for different formats

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 19.2.1 Your task

Step 1  Read C0 and define the purpose of the square, vertical and A4 outputs.

Step 2  Write a specification row for each using the exercise dimensions.

Step 3  List the essential facts every standalone version must retain.

Step 4  Keep design size, preview pixels and any print-export size distinct.



## 19.3.1 Your task

Step 1  Preserve the checked event name and schedule.

Step 2  Keep the venue and contact on readable lines.

Step 3  Use a short supporting phrase rather than shrinking every word.

Step 4  Check for text extending beyond the page.

Step 5  Export and inspect the square version at phone size.



## 19.4.1 Your task

Step 1  Place the event name high enough to identify it quickly.

Step 2  Put date, time and venue in the central information group.

Step 3  Keep the registration instruction clear of decorative elements.

Step 4  Restore any fact lost during resizing.

Step 5  Inspect the exported vertical image from top to bottom.



## 19.5.2 Worked handout content

Step 1  Check the handout against C0 rather than the short square copy alone.

Step 2  Export a print review using the available PDF options.

Step 3  Open the PDF outside Canva and check every page.

Step 4  Inspect a physical proof if printing is part of your actual task.

Step 5  Record page size, version and outstanding print questions.



## 19.6.1 Your task

Step 1  Open the square, story and handout together beside C0 version 2.

Step 2  Compare each fact and device requirement in every actual export.

Step 3  Record mismatches by asset and identify the corrected source.

Step 4  Keep consistency and export-property checks separate, with unperformed checks Pending.

