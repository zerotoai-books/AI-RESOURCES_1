# Chapter 29 Build and check charts and PivotTables

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 29.2.1 Your task
Word body block 4407

```text
Create an editable bar or column chart from Summary A5:B7. Title it Confirmed seats by category. Use Community and Workplace as categories and Confirmed seats as the values. Include zero on the count axis and use whole-number labels. Keep the source table visible and do not include its total as a third category.
```

## 29.3.1 Your task
Word body block 4419

```text
Create a native Excel PivotTable from CleanRegistrationTable on a new PivotSummary worksheet. Put Category in Rows, Seats in Values as Sum, and Status in Filters. Select Confirmed only. Keep the source records unchanged. Do not substitute a hardcoded summary or an image. Explain the source and field arrangement.
```
