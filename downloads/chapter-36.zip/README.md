# Chapter 36 Plan and generate a simple video shot

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 36.2 Exercise 1 Turn the brief into a shot objective

Step 1  Read B0 and list the audience and purpose.

Step 2  Write one sentence describing what the shot should communicate visually.

Step 3  List facts that belong in an editor title rather than the generation prompt.



## 36.3 Exercise 2 Check the generation route

Step 1  Open the video tool and record the model name exactly.

Step 2  Confirm Text to Video is supported and choose five seconds and 16 by 9 if offered.

Step 3  Record the displayed charge and your own maximum number of attempts before generating.



## 36.4 Exercise 3 Write a clear first prompt

Step 1  Name the subject, setting and framing.

Step 2  Choose one modest action and one camera treatment.

Step 3  Remove unrelated scene changes and requests for readable event lettering.



## 36.5 Exercise 4 Generate and inspect the whole clip

Step 1  Save the exact prompt and settings in the generation log.

Step 2  Generate once and download the original output if available.

Step 3  Watch at normal speed, then inspect the first, middle and last frames.



## 36.6 Exercise 5 Name and hand over the first take

Step 1  Name the take ch36_tabletop_A with the actual file extension.

Step 2  Record whether the clip is accepted, needs revision or was not generated.

Step 3  Open the downloaded file outside the generation page and verify that it plays.

