# Chapter 2 Write prompts that produce usable drafts

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 2.4.2 Start with a broad request

Step 1  Enter the broad request in a fresh conversation. Save the answer as Version A.

Step 2  Mark anything the answer assumes: a recipient, deadline, attachment, or permission to send.

Step 3  Write your own improved prompt using the supplied facts. Try this before reading the example below.

Step 4  Enter the improved prompt in a fresh conversation so the comparison is easier to interpret.

Step 5  Save the new answer as Version B and compare it with the source facts.



## 2.6.1 Make a focused revision

Step 1  Paste the original facts and your checked email into one conversation.

Step 2  Ask for a warmer version using the prompt below.

Step 3  Compare the revised request and deadline with the original.

Step 4  Ask for the concise version in the next section.

Step 5  Choose the wording that fits the relationship, then save both versions with your reason.



## 2.8.2 Decide what the learner needs

Step 1  Count the Paid rows yourself and write the three names in your log.

Step 2  Paste the lesson facts and all six table rows into a fresh conversation.

Step 3  Try the broad request: “Explain spreadsheet filters.” Note any unexplained terms.

Step 4  Use the specific prompt in the next section with the same source material.

Step 5  Compare the meaning, names, and numbers with your own check before accepting the explanation.



## 2.10.1 The supplied planning brief

Step 1  Add the task durations independently before asking AI.

Step 2  Calculate the available time as five sessions multiplied by 45 minutes.

Step 3  Paste the brief and task table into a fresh conversation.

Step 4  Use the prompt in the next section and check every daily total.



## 2.13.1 The incomplete brief

Step 1  List the missing details yourself before looking at the example questions.

Step 2  Paste the incomplete brief into a fresh conversation.

Step 3  Use the prompt below and inspect the questions.

Step 4  Supply the exercise answers in the next section.

Step 5  Request the message, then check that every new detail came from those answers.



## 2.15 Exercise 6 Use an example without copying its facts

Step 1  Read the style example and label it as a reference for tone and structure only.

Step 2  Write the new sender, recipient role, projector checks and noon deadline beside it.

Step 3  Send the prompt with the reference and task facts clearly separated.

Step 4  Check the new email for the old room booking task and date, and remove any facts copied from them.



## 2.19.1 Check before reading the answer guide

Step 1  Write a prompt for each of the three requested outputs.

Step 2  Run the prompts and preserve the first versions, even if they need correction.

Step 3  Check the event facts and the two different dates in the reminder explanation.

Step 4  Add every task duration and compare it with the four-session capacity.

Step 5  Revise the capacity from 15 to 12 wherever it appears, then inspect all three final outputs.



## 2.20.1 Questions to answer in your own words

Step 1  What did the specific email brief establish that the broad request left open?

Step 2  Why can “whenever you have time” be a bad revision of the Shardha email?

Step 3  Which three records remain visible under the Paid filter, and are the other records deleted?

Step 4  Why does the added 45-minute poster task exceed the original weekly capacity by 25 minutes?

Step 5  What should happen before drafting a notice when the replacement workshop date is unknown?

Step 6  What may be copied from a style example, and what must come from the new task brief?



## 2.20.2 Answer guide

Step 1  The recipient, review items, deadline, reply action, pasted-draft status, and pending approval.

Step 2  It weakens a fixed deadline.

Step 3  Vishva, Shardha, and Participant 03 are visible. The other rows are hidden and still stored.

Step 4  205 + 45 = 250 minutes of work. Capacity is 225, leaving a 25-minute shortfall.

Step 5  Ask for the missing schedule or agree how to display unknown details.

Step 6  Copy tone and structure only. Get the new names, dates, tasks, and commitments from the new brief.

