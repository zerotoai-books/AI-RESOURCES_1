# Chapter 35 Build a local workshop registration application

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 35.1.1 Your task

Step 1  Read the complete K2 brief and identify the five record fields.

Step 2  List the permitted category and status labels.

Step 3  Define duplicate handling and when a confirmed place uses capacity.

Step 4  Separate the command interface, storage rules and tests into readable files.

Step 5  Review the plan before implementing it in a working folder.



## 35.2.1 Your task

Step 1  Open your registration working folder.

Step 2  Initialise a new database with capacity twelve.

Step 3  Import the supplied clean demo CSV once.

Step 4  Run summary and list as separate commands.

Step 5  Inspect the saved records after closing and reopening the terminal or program.



## 35.3.1 Your task

Step 1  Initialise full.sqlite3 and import the baseline once.

Step 2  Import the four extra confirmed records and verify that capacity is full.

Step 3  Try the overflow import and promotion of R07.

Step 4  Cancel R01 and inspect R07 before promoting anyone.

Step 5  Explicitly confirm R07 and check the resulting status counts.



## 35.4.1 Your task

Step 1  Create a fresh baseline named rollback.sqlite3.

Step 2  Count its eleven records before the test.

Step 3  Import bad_import.csv, which contains new R20 followed by duplicate R01.

Step 4  Inspect the records after the expected rejection.

Step 5  Test an unknown status and rerun the automated suite.



## 35.5.1 Your task

Step 1  Save the source code, fixtures, tests and run instructions together.

Step 2  Verify a clean baseline in a newly named database.

Step 3  Run the printed registration suite and repeat the command-line scenarios in Appendix A6.

Step 4  Record the interpreter, actual outcomes and any unperformed editor checks.

Step 5  Leave reviewer status Pending until a real review is recorded.

