# Chapter 29 Build and check charts and PivotTables

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 29.1.1 Your task

Step 1  Put Category and Confirmed seats in A5:B5.

Step 2  Put Community in A6 and Workplace in A7.

Step 3  Write the conditional seat formula in B6 and copy it to B7.

Step 4  Add a total in B8.

Step 5  Reconcile that total to the overall confirmed-seat measure.



## 29.2.1 Your task

Step 1  Use the two categories and confirmed-seat values as the source.

Step 2  Give the chart a specific title.

Step 3  Include zero on the count axis.

Step 4  Keep the categories readable and avoid three-dimensional effects.

Step 5  Confirm that selecting the chart exposes native chart controls and data references.



## 29.3.1 Your task

Step 1  Select a cell in CleanRegistrationTable.

Step 2  Use Insert, PivotTable and choose a new worksheet, or ask Copilot to create it.

Step 3  Place Category in Rows and Seats in Values.

Step 4  Set the Values calculation to Sum of Seats.

Step 5  Put Status in Filters and select Confirmed only.



## 29.4.1 Your task

Step 1  Locate R07 by RegistrationID, not by a row number you remember.

Step 2  Change only its Status.

Step 3  Check the formula summary and cell-linked chart.

Step 4  Refresh the PivotTable using its refresh controls.

Step 5  Restore Waitlisted, refresh again and confirm the baseline.



## 29.5.1 Your task

Step 1  Confirm that the formula summary and refreshed PivotTable both total eight.

Step 2  Check that the chart shows the same two values.

Step 3  Inspect the chart title, units and zero baseline.

Step 4  Record the test and restoration of R07.

Step 5  Mention the one Needs review record without including it in confirmed seats.

