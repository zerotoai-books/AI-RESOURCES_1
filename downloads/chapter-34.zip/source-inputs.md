# Chapter 34 source inputs

These are fictional teaching sources from the current printed manuscript. Use the exact source ID and scope named in the exercise. Deliberate defects and old versions remain unchanged.

## GitHub Copilot

## Official references for the GitHub Copilot chapters

Product guidance was checked on 15 October 2026 IST. The 2027 label identifies the book edition. Use current official instructions and account notices when features, access or editor controls differ.

The code printed in Appendix A3 to A6 was checked with Python 3.12.14 on Linux. Fourteen test methods passed across the calculator and registration suites, and the separate intentional debugging failure was reproduced. The command-line registration scenarios and rollback were also checked. These are local code checks, not a signed-in Copilot session or VS Code interface test. Type the listings and rerun the printed checks yourself.

## GH1 GitHub Install GitHub Copilot in your environment

Access and automatic extension setup in VS Code.

https://docs.github.com/en/copilot/how-tos/copilot-in-your-ide/set-up-copilot/install-copilot-extension

## GH2 Visual Studio Code Set up GitHub Copilot in VS Code

Account setup and current product entry point.

https://code.visualstudio.com/docs/setup/copilot

## GH3 Visual Studio Code Choose an agent harness

Choose Copilot and distinguish Ask from Agent.

https://code.visualstudio.com/docs/agents/run/agent-harnesses

## GH4 Visual Studio Code Plan work with agents

Review a plan before implementation.

https://code.visualstudio.com/docs/agents/run/planning

## GH5 Visual Studio Code Manage approvals and permissions

File edits terminal commands and permission controls.

https://code.visualstudio.com/docs/agents/run/approvals

## GH6 GitHub Application card for GitHub Copilot Chat

Review generated code explanations and tests.

https://docs.github.com/en/copilot/responsible-use/chat

## PY1 Visual Studio Code Getting started with Python in VS Code

Separate editor extension interpreter and running a file.

https://code.visualstudio.com/docs/python/python-tutorial

## PY2 Python Decimal arithmetic

Exact decimal inputs and explicit rounding.

https://docs.python.org/3.12/library/decimal.html

## PY3 Python Unit testing framework

Assertions and test discovery.

https://docs.python.org/3.12/library/unittest.html

## PY4 Python SQLite database interface

Persistent data transactions and parameter binding.

https://docs.python.org/3.12/library/sqlite3.html

## Practice sources printed for offline use

These printed briefs supply the exercise facts and acceptance rules. Appendix A3 to A6 prints the programs, tests and coding datasets. Workshop records, Guest aliases and prices are fictional teaching material.

## K0 Coding Workspace Brief

K0 Coding workspace brief From Zero to AI 2027 Edition Book 1 by SUNDAR P. Use a local practice folder, VS Code and Python 3.12 or later. The worked programs use only the Python standard library. A GitHub account with eligible Copilot access is needed for the Copilot exercises. A remote repository, cloud agent, API key and paid Python package are not required for the programs.

The introductory one-seat example has capacity 12 and eight confirmed places. There are no other holds. Available places are four. Waiting-list requests do not count as confirmed places. Confirmed places greater than capacity are an error in this first example, rather than a negative count labelled available.

The registration app is a separate controlled coding example based on the Excel teaching sample. The fictional workshop remains Plan Your First Workshop on Saturday 21 November 2026, 11 am to noon IST. Attendance is free. The coding baseline capacity is 12. Gamma's separate capacity-change exercise does not change this coding dataset. The programs do not make real bookings.

## K1 Materials Quote Rules

K1 Materials quote rules This is a separate fictional materials order. It does not revise the estimates in the Excel tracker or the Gamma pitch. No attendance fee is introduced.

Inputs are typed text. Unit price accepts plain nonnegative decimal numbers from 0 to 100000 INR, with at most two digits after the decimal point. Surrounding spaces are trimmed. Reject currency symbols, separators, exponent notation, NaN, Infinity, negative numbers and prices with more than two decimal places. Quantity is a whole number from 1 to 40. Discount is a whole percent from 0 to 100. The prototype rejects non-text arguments passed directly to its quote API.

Subtotal is unit price times quantity. Compute the discount on the subtotal. Round the discount once to two decimal places using ROUND_HALF_UP. Subtract that rounded discount from the subtotal. Do not round the net amount separately using a different policy. This is this exercise's rule, not a universal tax or invoicing rule. No extra tax, delivery charge or other cost is assumed.

Baseline: price 25, quantity 12, discount 10 percent. Subtotal INR 300.00, discount INR 30.00, total INR 270.00. Independent: price 40, quantity 5, discount 15 percent. Subtotal INR 200.00, discount INR 30.00, total INR 170.00. Additional check: price 19.99, quantity 3, discount 10 percent. Subtotal INR 59.97, discount INR 6.00, total INR 53.97. Rounding check: price 0.05, quantity 1, discount 50 percent. Discount INR 0.03 and total INR 0.02 under the specified policy.

## K2 Registration App Rules

K2 Registration app rules Build a local command line prototype for one operator. Store records in a SQLite database file. Each unique RegistrationID represents one fictional person and one seat. Guest aliases are teaching labels, not actual identities.

Capacity is a whole number from 1 to 40, chosen only when a new database is initialised. Default is 12. Reopening reads the saved capacity. Initialisation must refuse to replace an existing file. Listing or counting a missing database must fail rather than silently create another empty database.

RegistrationID is trimmed and converted to upper case after validating its ASCII form. It has 2 to 12 characters, begins with a letter, and uses only letters, digits, underscore and hyphen. IDs are unique after this normalisation. Alias is trimmed, has 1 to 40 characters and contains no ASCII control characters. RegistrationDate uses YYYY-MM-DD and must be a valid calendar date. It is the record's date, not the workshop date. No real-time cutoff is imposed.

Approved categories are Community and Workplace. Approved statuses are Confirmed, Waitlisted, Cancelled and Needs review. Trim and standardise these recognised labels without guessing an unknown status. Each operation supplies an explicit status. Only Confirmed uses capacity. Confirming an additional record at full capacity must fail and preserve the previous records. Cancelling does not automatically promote anyone. A status change is an explicit fictional operator decision. Needs review remains visible until such a decision is recorded.

The CSV schema in this exact order is RegistrationID, Alias, RegistrationDate, Category, Status. Import all valid rows in one transaction or import none. Refuse a duplicate, invalid row, malformed CSV or a capacity overflow. Do not overwrite an existing record. Use parameter binding for data in SQL statements.

The clean coding sample printed in Appendix A6 has eleven unique records: eight Confirmed, one Waitlisted, one Cancelled and one Needs review. Capacity twelve leaves four available. Dates and IDs follow the printed Excel sample; fictional Guest aliases are added. The coding CSV has a different schema and no raw duplicate.

## K3 Registration Acceptance Checks

K3 Registration acceptance checks Use a disposable database. Save actual observations separately from expected answers. Baseline import yields 11 records, eight Confirmed, four available, one Waitlisted, one Cancelled and one Needs review. Close and reopen before claiming that records persist. Confirm that the same absolute database path is used by both runs.

Adding R01 again, including r01 or surrounding spaces, is rejected without overwriting Guest 01. Unknown categories and statuses, invalid IDs, blank aliases and impossible dates are rejected. A failed multirow import leaves all previously saved records unchanged and leaves none of that import's new rows behind.

In a separate baseline copy, add four unique Confirmed IDs R12 through R15. Confirmed then equals 12 and available equals zero. R16 Confirmed and promotion of R07 must both fail. Cancelling R01 frees one place without promoting R07. Explicitly confirming R07 then fills that place. Test restoration by creating another fresh baseline database; do not delete a row and assume every test side effect has been undone.

The printed registration tests use temporary databases and do not alter a learner’s saved database. Automated checks are separate from a signed-in Copilot session, VS Code button checks, human review and suitability for actual event use.

## K4 Independent App Challenge

K4 Independent app challenge Create a new database with capacity three. Type the coding Independent_Registrations.csv printed in Appendix A6. I01 and I02 are Confirmed, I03 Waitlisted and I04 Needs review. Four records use two places, leaving one. Add I05 Confirmed with the printed command. Confirmed becomes three and available zero. Promotion of I03 must fail while full.

Cancel I02. Confirmed becomes two and one place becomes available; I03 remains Waitlisted. Explicitly confirm I03. There are now five records: three Confirmed, one Cancelled, one Needs review and zero Waitlisted. Available is zero. Close and reopen to verify that the new statuses persist. This is separate practice data and must not change the workshop baseline.
