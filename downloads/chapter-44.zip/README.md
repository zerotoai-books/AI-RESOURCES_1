# Chapter 44 Build and test an interactive artifact

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 44.2 Exercise 1 Write the acceptance rules first

Step 1  Require positive whole number capacity and nonnegative whole number confirmed count.

Step 2  Reject confirmed counts above capacity.

Step 3  Define remaining places as capacity minus confirmed only after validation.



## 44.3 Exercise 2 Ask for the smallest useful artifact

Step 1  Ask for one HTML file using ordinary browser controls.

Step 2  Require visible error messages and keyboard operation.

Step 3  State that the tool is a practice calculator and makes no bookings.



## 44.4 Exercise 3 Test normal and boundary inputs

Step 1  Test twelve and eight, twelve and twelve, and one and zero.

Step 2  Record the actual displayed answer for each.

Step 3  Check that repeating a calculation replaces the previous answer.



## 44.5 Exercise 4 Test errors and recovery

Step 1  Try blank, negative, fractional, nonnumeric and over capacity values.

Step 2  Check that the result area shows an error instead of a misleading count.

Step 3  Correct the values and test again, then use Reset.



## 44.6 Exercise 5 Review and package the tool

Step 1  Save the implementation with a versioned filename.

Step 2  Complete the test log using actual results.

Step 3  Include instructions, known limits and a review status.

