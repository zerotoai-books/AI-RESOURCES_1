# Chapter 44 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 44.2.2 Worked answer guide

With capacity twelve and eight confirmed, the answer is four. With twelve confirmed, it is zero. Thirteen confirmed is an error, not negative one available. A waiting list is outside this tool’s input rule. It should not be subtracted unless the specification is deliberately changed.

Check your work. The input labels must make it clear that the second field is confirmed places, not all requests. Accurate labels are part of correctness.

## 44.3.2 Worked answer guide

The intended result is a page with two labelled inputs, a Calculate button, a Reset button and a result or error area. It should work without entering personal data. If Claude offers a richer template, retain the same simple rules and inspect any added capability before using it.

Check your work. Download or copy the actual implementation before testing. A screenshot can show layout but cannot establish input validation or arithmetic.

## 44.4.2 Worked answer guide

All three cases should pass in the reference implementation. The zero result is important: a full event is valid, not an input error. A new result should replace the old message rather than leaving contradictory numbers visible. Use the normal and invalid-input cases printed here to check the calculation; record browser and keyboard checks separately.

Check your work. Run the same cases against your own generated artifact. Passing the supplied reference does not prove that a separately generated version behaves the same way.

## 44.5.2 Worked answer guide

The reference accepts decimal digit strings representing safe whole numbers. It rejects signs, decimal points, scientific notation and values beyond JavaScript’s safe integer range. Those are deliberate input rules, not universal requirements for every calculator. A generated version must either match the stated rules or explain an agreed specification change.

Check your work. Test keyboard focus, visible labels and result announcements in your browser as well. Automated arithmetic checks do not substitute for those interaction checks.

## 44.6.2 Worked answer guide

A complete handover distinguishes code tests from browser checks. The printed reference calculation logic was checked separately; a learner still needs to inspect its own browser experience and any generated replacement. Public sharing is unnecessary for this chapter, and no upload should be implied by saving a local file.

Check your work. If your artifact introduces network requests, storage or a booking button, remove those additions or treat them as a separate project requiring new requirements and review.

## 44.7.1 Answer guide after your attempt

The defaults produce three, ten confirmed produces zero, and eleven confirmed is rejected. Changing defaults must not remove validation. Keep the original reference untouched so the baseline tests remain reproducible. Explain that defaults are examples and do not read live bookings or update any event record.
