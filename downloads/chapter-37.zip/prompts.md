# Chapter 37 Describe motion and improve a clip

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 37.2.1 Useful prompt or direction
Word body block 5161

```text
Review note: At ___ seconds I can see ___. This affects the intended message because ___. For the next attempt I will change only ___.
```

## 37.3.1 Useful prompt or direction
Word body block 5171

```text
Version A: The page corner lifts gently while the camera remains still. Version B: The page corner lifts gently while the camera slowly moves closer to the notebook.
```

## 37.4.1 Useful prompt or direction
Word body block 5181

```text
Medium close shot of a plain notebook and a yellow pencil on a light wooden table. One page corner rises slightly and settles. The pencil rests in place throughout. Soft daylight, calm classroom illustration style. The camera remains still.
```

## 37.5.1 Useful prompt or direction
Word body block 5191

```text
Comparison direction: Score both takes using the same three criteria. Report the observations separately from the totals. A critical factual or visual defect prevents acceptance even when the total is high.
```

## 37.6.1 Useful prompt or direction
Word body block 5201

```text
Decision note: I choose ___ because ___. The remaining defect is ___. It does or does not affect the message. Further generation is or is not justified within my limit.
```
