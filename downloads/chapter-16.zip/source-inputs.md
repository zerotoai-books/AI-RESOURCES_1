# Chapter 16 source inputs

These are fictional teaching sources from the current printed manuscript. Use the exact source ID and scope named in the exercise. Deliberate defects and old versions remain unchanged.

## Canva AI

## Official references for the Canva AI chapters

Product guidance was checked on 14 October 2026 IST. The 2027 Edition label is the book edition, not a claim that product features were verified in 2027. Features, plan eligibility and help pages can change. Use the current official source and your account notice when practising.

The worked answers are editorial teaching examples. They are not transcripts captured from Perplexity or Canva. Fictional source files, prices, event arrangements, trial records, illustrations and sample layouts were created for this book. Pending tests and approvals are not presented as completed results.

## CA1 Canva Get started with Canva AI

Plan eligibility and design creation.

https://www.canva.com/help/using-canva-ai/

## CA2 Canva Use Magic Design to generate design templates

Homepage and editor routes.

https://www.canva.com/help/use-magic-design/

## CA3 Canva Use Magic Media to create photos graphics and videos

Optional image generation.

https://www.canva.com/help/using-magic-media/

## CA4 Canva Understanding your AI usage

Usage varies by tool and plan.

https://www.canva.com/help/ai-access-variantb/

## CA5 Canva Choose the right download file type for your Canva design

PNG JPG PDF Print and editable exports.

https://www.canva.com/help/download-file-types/

## CA6 Canva Resize designs and size limits

Magic Resize and eligible plans.

https://www.canva.com/help/resize/

## CA7 Canva Use margins bleed rulers and crop marks

Print guides and export checks.

https://www.canva.com/help/margins-bleed-crop-marks/

## CA8 Canva Canva licensing explained

Asset permissions and limitations.

https://www.canva.com/licensing-explained/

## CA9 Canva Download or save designs to your device

Download workflow and page selection.

https://www.canva.com/help/download-or-purchase/

## Practice sources printed for offline use

These source documents are printed here for the controlled exercises. Type the source text into your tool or create your own saved copy. They are fictional teaching material. Additional datasets and creation instructions appear in the Printed practice materials appendix.

## C0 Workshop Promotion Brief v2

C0 Workshop promotion brief version 2

Fictional teaching update dated 14 October 2026 IST. This source supersedes the unresolved venue and access statements in the Gemini practice brief version 1.1 for chapters 16 to 20 only. This is a simulated confirmation for design practice, not a real event announcement.

C01 Event: Plan Your First Workshop.

C02 Date: Saturday 21 November 2026.

C03 Time: 10.30 am to 11.30 am IST.

C04 Venue: Learning Room, Adyar, Chennai. Confirmed in this fictional update.

C05 Audience: adult beginners. Maximum capacity: 12 attendees. This is a cap, not a registration count. No bookings or number of seats remaining is supplied.

C06 Format: English; paper activities. No attendee phone or laptop is needed.

C07 Learners practise writing a learning outcome, calculating a supplied budget and building a timed agenda. Printed practice materials are included.

C08 No participant fee is charged in this fictional update.

C09 Registration contact: learn@example.com. This is a placeholder address for practice; do not email it or publish these materials as a real event.

C10 Step-free access is confirmed in the fictional venue note. Attendees should contact the organiser about specific access needs. Do not claim universal accessibility or promise an interpreter, hearing loop or loan device.

C11 No certificates, refreshments, parking or transport are promised.

C12 Reviewer: Shardha. The design must be checked before release in the exercise.

C13 Practice design style: dark navy #162638, white #FFFFFF and amber #F2B544. Use a simple sans-serif typeface, with a heavier title weight. No logo is supplied.

C14 Required assets: A4 poster; square post 1080 by 1080 px; vertical story 1080 by 1920 px; registration graphic 1080 by 1080 px; A4 handout. The social sizes are specifications of this exercise, not universal platform requirements.

C15 One invented drawing of paper and pencils may be used. It is illustrative and does not depict the actual venue, attendees or a past workshop.

## C1 Design Copy v1

C1 Checked workshop copy version 1

Fictional practice event. Use with C0 version 2.

Plan Your First Workshop

A practical session for adult beginners

Saturday 21 November 2026

10.30 am to 11.30 am IST

Learning Room, Adyar, Chennai

Free to attend | Capacity 12

English | Printed practice materials included

No phone or laptop needed

To register, email learn@example.com

Keep the exact date, time, location and contact on every promotional asset.

For short formats the learning details may move to an accompanying caption,

but a standalone post must still tell a reader what, when, where and how to act.

## C2 Independent Design Challenge

C2 Independent design challenge

Fictional project: First Steps in Photography.

Date: Saturday 28 November 2026. Time: 3 pm to 4.30 pm IST.

Venue: Studio Room, Kochi, confirmed for the exercise.

Audience: adult beginners. Capacity: eight. Fee: INR 650 per person.

Bring your own camera or camera phone. Contact: photos@example.com (placeholder).

No food, certificate, parking or equipment loans are supplied.

Output: square post 1080 by 1080 px, vertical story 1080 by 1920 px and A4 handout. Use your own layout; preserve the supplied facts. Do not merge this brief with the Plan Your First Workshop event. Specific access arrangements are unknown.

## C3 Time Change v3

C3 Time change version 3

Fictional update for chapter 20 only, issued after the first kit has been saved. Plan Your First Workshop remains on Saturday 21 November 2026 at Learning Room, Adyar, Chennai. The time changes to 11 am to noon IST. All other C0 version 2 facts remain unchanged. Apply this change to every asset and caption in the second kit, label the new release v3, and keep the previous v2 kit as an archive.
