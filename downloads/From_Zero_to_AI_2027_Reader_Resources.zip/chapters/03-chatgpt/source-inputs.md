# Chapter 3 source inputs

These are fictional teaching sources from the current printed manuscript. Use the exact source ID and scope named in the exercise. Deliberate defects and old versions remain unchanged.

## 3.4 Source A One-page workshop brief

WORKSHOP BRIEF v3  |  ISSUED 3 NOVEMBER 2026  |  FICTIONAL PRACTICE MATERIAL

A1 Event and purpose. Everyday AI Workshop introduces adults who are new to AI to writing a clear prompt, asking a follow-up, and checking a short draft. This is an introductory workshop; no trainer qualifications or guaranteed learning results are stated.

A2 Schedule. The session is on Saturday 7 November 2026, from 11 am to 1 pm India Standard Time. This supersedes the earlier 10 am to noon time. The workshop date has not changed.

A3 Venue. Learning Room, Adyar, Chennai is confirmed for the session. The street address, accessible entrance details, and participant arrival time are not supplied in this brief.

A4 Price and capacity. The fee is INR 499 for each ticket. Capacity is 12 participants. Included materials are printed learning sheets. Participants should bring their own laptop. Loan devices have not been confirmed.

A5 Contact and responsibilities. Booking enquiries go to learn@example.com. Vishva coordinates communications, the equipment coordinator checks equipment, and Shardha reviews learning content. These roles do not establish their event-day attendance.

A6 Sales source. Ticket Sales Raw v1 contains orders dated 1 to 3 November 2026. Quantity means tickets in an order. UnitPriceINR is the price for one ticket. One order may contain more than one ticket.

A7 Status rules for this exercise. Paid orders are active and contribute Quantity multiplied by UnitPriceINR to recorded paid receipts. Pending orders are active but contribute nothing to paid receipts. Cancelled orders are inactive and contribute nothing. A blank status is unresolved and must not be treated as Paid, Pending, or Cancelled.

A8 Duplicate rule. If the same OrderID appears with identical values in every business field, count it once in the working analysis and record the excluded source row. Conflicting rows with the same OrderID require clarification; do not choose one silently.

A9 Reporting rule. Report known active tickets separately from tickets with an unresolved status. Do not publish an exact number of remaining places until the unresolved order is settled. Fee revenue at full capacity is a projection, not evidence that those fees have been collected.

A10 Open matters. Refund terms, refreshments, certificates, payment instructions, and a budget are not supplied. Do not add them to an invitation or describe them as confirmed benefits. Ask the organiser when a task needs those decisions.

## 3.5 Source B Small ticket sales dataset

The table contains 12 source rows. A blank cell in D11 is intentionally blank. The Row labels are evidence locators for this exercise, not additional sales records. Dates are order dates, not workshop dates.

| Row | Order | Date | Qty | Unit INR | Status |
| --- | --- | --- | --- | --- | --- |
| D01 | R001 | 1 Nov 2026 | 1 | 499 | Paid |
| D02 | R002 | 1 Nov 2026 | 2 | 499 | Paid |
| D03 | R003 | 1 Nov 2026 | 1 | 499 | Pending |
| D04 | R004 | 2 Nov 2026 | 1 | 499 | Paid |
| D05 | R005 | 2 Nov 2026 | 1 | 499 | Paid |
| D06 | R006 | 2 Nov 2026 | 1 | 499 | Cancelled |
| D07 | R004 | 2 Nov 2026 | 1 | 499 | Paid |
| D08 | R007 | 3 Nov 2026 | 1 | 499 | Paid |
| D09 | R008 | 3 Nov 2026 | 1 | 499 | Pending |
| D10 | R009 | 3 Nov 2026 | 1 | 499 | Paid |
| D11 | R010 | 3 Nov 2026 | 1 | 499 |  |
| D12 | R011 | 3 Nov 2026 | 1 | 499 | Paid |

## 3.5.1 CSV version to copy

```text
Row,OrderID,Date,Quantity,UnitPriceINR,Status
D01,R001,2026-11-01,1,499,Paid
D02,R002,2026-11-01,2,499,Paid
D03,R003,2026-11-01,1,499,Pending
D04,R004,2026-11-02,1,499,Paid
D05,R005,2026-11-02,1,499,Paid
D06,R006,2026-11-02,1,499,Cancelled
D07,R004,2026-11-02,1,499,Paid
D08,R007,2026-11-03,1,499,Paid
D09,R008,2026-11-03,1,499,Pending
D10,R009,2026-11-03,1,499,Paid
D11,R010,2026-11-03,1,499,
D12,R011,2026-11-03,1,499,Paid
```

CSV means comma-separated values. The header names the fields, and each following line is one record. The final comma on the R010 line is important: it preserves an empty Status field. Do not replace that blank with Paid just to make the file look complete.

## 3.13 Independent challenge Check a second source pack

Use this separate fictional case. Source C, Photography Brief v1, states: First Steps in Photography is on 14 November 2026, from 2 pm to 4 pm IST, at Studio Room, Kochi. Fee is INR 200 per ticket, capacity is eight, and a digital handout is included. Participants bring their own camera or camera phone. Refund terms and certificates are not supplied. Use the same status and exact-duplicate rules as A7 and A8.

| Row | Order | Qty | Unit INR | Status |
| --- | --- | --- | --- | --- |
| C01 | X01 | 2 | 200 | Paid |
| C02 | X02 | 1 | 200 | Pending |
| C03 | X03 | 1 | 200 | Paid |
| C04 | X01 | 2 | 200 | Paid |
| C05 | X04 | 1 | 200 |  |
| C06 | X05 | 1 | 200 | Cancelled |

Write your own prompt. Produce an evidence table with at least six checked claims and a summary under 130 words. Preserve the raw source. Document duplicate handling, separate orders from tickets, and state the effect of the blank status. Do not add contact details, fees collected from Pending orders, or an exact available-place claim.


## Official tool references

## ChatGPT

## Official references for the ChatGPT chapters

The references support the general product use and prompting guidance. The workshop scenarios, datasets, prompts, sample answers, plans, and assessments are teaching material. Product guidance was checked on 11 October 2026. Follow the current official instructions if your account or screen differs.

1 OpenAI  Use ChatGPT
https://learn.chatgpt.com/docs/use-chatgpt

2 OpenAI  Prompting
https://learn.chatgpt.com/docs/prompting

3 OpenAI  ChatGPT on the web
https://learn.chatgpt.com/docs/web
