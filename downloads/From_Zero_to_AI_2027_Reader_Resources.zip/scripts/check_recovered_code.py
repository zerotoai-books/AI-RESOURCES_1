from pathlib import Path
import subprocess, sys
root = Path(__file__).resolve().parents[1]
checks = [("code/02_calculator", ["test_calculator", "test_fixed"]),
          ("code/05_registration", ["test_registration"])]
for folder, modules in checks:
    result = subprocess.run([sys.executable, "-m", "unittest", "-v", *modules], cwd=root/folder)
    if result.returncode:
        raise SystemExit(result.returncode)
negative = subprocess.run([sys.executable, "-m", "unittest", "-v", "test_buggy"], cwd=root/"code/03_debug", capture_output=True, text=True)
if negative.returncode != 1 or "Decimal('290') != Decimal('270.00')" not in negative.stderr or "FAILED (failures=1)" not in negative.stderr or "ERROR" in negative.stderr:
    print(negative.stdout, negative.stderr)
    raise SystemExit("Intentional arithmetic failure did not reproduce exactly")
print("14 distinct core methods passed; 2 comparison methods passed; one intentional arithmetic failure reproduced.")
print("Workbook, signed-in account, media and human review tasks remain open.")
