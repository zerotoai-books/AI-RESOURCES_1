# Chapter 33 Debug problems using reproducible examples

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 33.1.1 Your task

Step 1  Open a separate learning copy of the 03_debug folder you created from Appendix A4.

Step 2  Run calculator_buggy.py with its supplied demonstration.

Step 3  Run the supplied test using the command below.

Step 4  Record the actual amount, expected amount and test exit status.

Step 5  Save the original file beside your bug report.



## 33.2.1 Your task

Step 1  Identify how the price and quantity become numeric values.

Step 2  Calculate the subtotal independently.

Step 3  Locate the use of discount_percent.

Step 4  Compare its units with the amount being subtracted.

Step 5  Describe the defect in one precise sentence.



## 33.3.1 Your task

Step 1  Put a breakpoint on the function's return line.

Step 2  Start a debug run of the saved broken file.

Step 3  Inspect subtotal and discount_percent at the pause.

Step 4  Step through the return and compare with K1.

Step 5  Record the values you actually saw and remove any temporary trace output.



## 33.4.1 Your task

Step 1  Calculate the discount from subtotal times percentage divided by one hundred.

Step 2  Round the discount according to K1.

Step 3  Subtract that discount from subtotal.

Step 4  Compare the original and revised function bodies.

Step 5  Rerun the original failing command before trying unrelated changes.



## 33.5.1 Your task

Step 1  Run the original test against your repaired learning copy.

Step 2  Run price forty, quantity five and discount fifteen percent.

Step 3  Confirm that the calculation uses the new inputs rather than a fixed answer.

Step 4  Run the two printed regression checks in Appendix A4 as an answer comparison.

Step 5  Save the patch, results and any remaining limitation in the bug report.

