# Chapter 45 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 45.2.2 Worked answer guide

The source map should explain where each factual claim can be checked. B0 establishes the event logistics. B3 defines which registrations consume places. B4 establishes the cost assumptions and agenda allocations. The CSV supplies counts, while the feedback file supplies limited themes. The calculator implements a rule but is not a source of live registration data.

Check your work. Confirm that all attached files are the intended versions. If the conversation includes an earlier B2 exercise, explicitly reset the capstone source set or start a fresh chat.

## 45.3.2 Worked answer guide

The segments are 11.00 to 11.05 welcome, 11.05 to 11.15 example, 11.15 to 11.30 guided practice, 11.30 to 11.45 independent practice, 11.45 to 11.55 review and 11.55 to noon close. Five plus ten plus fifteen plus fifteen plus ten plus five equals sixty minutes.

Check your work. A planning agenda is not evidence that a session ran to time. If an organiser adds a break, revise the allocations deliberately rather than extending beyond the advertised hour.

## 45.4.2 Worked answer guide

Materials are INR 300 and printing is INR 180. With room cost INR 600, the planned total is INR 1080. The remaining budget is INR 420. Free attendance means this brief provides no ticket revenue. The remainder is unallocated budget, not profit, cash collected or an amount already spent.

Check your work. State the quantity assumption beside each multiplication. If using confirmed attendance instead, label that as a separate scenario and do not replace the full capacity baseline.

## 45.5.2 Worked answer guide

A coherent pack keeps those five key figures distinct. It may propose larger print, protected practice time and a recap sheet from the feedback. Each remains a proposal until adopted. The title sheet and invitation should use the same event name, date and time as the agenda. Shardha remains a fictional reviewer with approval Pending.

Check your work. Use the complete worked operations example printed in Appendix A10 after your own attempt. You may type it into your own document named Worked_Operations_Pack.md. It is a reference draft, not proof that a real organiser approved the event.

## 45.6.2 Worked answer guide

The handover should let a reviewer reproduce the numbers and identify the exact candidate. It must not include a public link as a substitute for local source evidence. If you exported Word or PDF from Claude, inspect the saved export for missing sections and changed formatting. Keep the editable source available for corrections.

Check your work. A final response saying “all done” cannot replace a missing file, a failed calculation or an unperformed review. Record the status of each component separately.

## 45.7.1 Answer guide after your attempt

Available places are one. Full capacity materials cost ten times INR 25, or INR 250; printing is INR 150; with room INR 600 the total is INR 1000 and remaining budget INR 500. The agenda remains sixty minutes. This is a separate scenario, so it must not overwrite the baseline fixture or claim that nine actual people have booked.
