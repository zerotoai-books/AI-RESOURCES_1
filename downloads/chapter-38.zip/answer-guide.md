# Chapter 38 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 38.2.2 Worked answer guide

Your landscape drawing should contain a notebook and one yellow pencil on a table. It is designed for a simple motion exercise. The record should say that it is an illustration, so a later editor cannot caption it as a photograph of Learning Room. If you substitute your own photograph, record who made it and the permission relevant to your intended use.

Check your work. Permission and visual suitability are separate checks. An image can be permitted but too blurred, crowded or poorly framed for the planned motion.

## 38.3 Exercise 2 Check the crop before generating

Your task. A new aspect ratio can remove an important object. Inspect the actual preview rather than assuming that a landscape source will work equally well in a portrait output.

## 38.3.2 Worked answer guide

A landscape crop retaining both objects is a valid starting point. A portrait crop that cuts the pencil in half needs a revised composition before generation. The chapter does not require a portrait version. If your model offers only a different ratio, prepare a separate image version and record the change rather than silently comparing unlike inputs.

Check your work. Save the exact uploaded image version. Keep your editable drawing if your editor supports it; upload the PNG you exported and inspected.

## 38.4.2 Worked answer guide

The image already defines colour, composition and style. The prompt supplies the movement through time. A slow approach is more coherent with this flat illustration than asking a lifelike hand to enter and write a detailed sentence. Even this simple prompt may change object geometry; the next exercise checks that risk.

Check your work. Do not confuse an image appearing in a chat message with the file being attached to the generation input. Confirm the image preview in the selected video tool.

## 38.5.2 Worked answer guide

An acceptable teaching result keeps one recognisable pencil and a coherent notebook while the view moves gently closer. A hypothetical final frame with a second notebook is a continuity failure even if the opening looks excellent. Three frame checks are useful anchors, but they cannot replace watching the full clip.

Check your work. If the tool or editor allows frame export, name samples with the take and time. Otherwise save written observations; do not invent frame files or inspection results.

## 38.6.2 Worked answer guide

A smaller camera movement can be evaluated against the same source. A corrected crop is also legitimate, but it tests a different change. “Everything improved” is not a sufficient explanation when you replaced the image, prompt and model together. Keep a short decision record and stop when the shot is fit for the intended edit.

Check your work. Do not overwrite the original reference asset. Preserve a clean source so later chapters can reuse the same visual baseline.

## 38.7.1 Answer guide after your attempt

A complete submission identifies the actual image and permission, keeps the camera body in the crop, and asks for a small compatible movement. The review checks the first, middle and final frames plus the full clip. It does not claim that owning a camera grants permission to reuse someone else’s photograph or visible branding. If no suitable asset exists, submit the asset plan and mark generation Not run.
