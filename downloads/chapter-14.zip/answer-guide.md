# Chapter 14 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 14.2.2 Checked cost table

| Option | Working | Total INR | Remaining INR |
| --- | --- | --- | --- |
| A Plus | 400 × 3 | 1200 | 0 |
| B | 350 × 3, upfront | 1050 | 150 |
| C | 250 × 3 | 750 | 450 |

## 14.2.3 Answer guide

The figures are 1200, 1050 and 750. Remaining budget equals 1200 minus the full cost. C's lower cost does not make it eligible because its 20-record cap fails R0. A Free is not an alternative meeting R0 because F2 excludes CSV export. Preserve those feature failures beside the cost comparison.

## 14.3.2 Answer guide

“B includes CSV export” is a supplied fact from F4. “B meets the stated export requirement” is an interpretation comparing F4 with R0. “B is effortless to use” is unsupported because usability has not been tested. “Trial B before buying” is a recommendation. A valid revision is: “F4 states that B includes CSV export, which meets the stated export requirement in R0. Trial that workflow before selection because ease of use has not been established.”

## 14.4.2 Worked briefing

```text
Learning Circle registration workspace decision
Scope checked on 14 October 2026 IST
```

```text
The team needs one English desktop registration workspace for three months. It must hold at least 24 records, export CSV and allow participants to submit a public form without accounts. One organiser is sufficient, and the full purchase budget is INR 1200 including taxes. No payment collection is required. [R0]
```

```text
Option A Free does not meet the CSV requirement. Its old introductory offer ended on 31 August; the current guide excludes CSV from Free and includes it in Plus. A Plus supports 100 records and the required workflow. Its three-month cost is INR 400 × 3 = INR 1200, leaving no unused budget. [F1, F2, F3]
```

```text
Option B supplies the required workflow and 100 records. It costs INR 350 × 3 = INR 1050, leaving INR 150. The full three months must be purchased upfront. Its second organiser account exceeds our stated need but is not necessary to meet it. [F4]
```

```text
Option C costs INR 750 over three months, but its limit is 20 records. That is below the mandatory 24-record requirement, so its lower price does not make it eligible. [F5]
```

```text
I recommend a trial of B before selection because it meets the documented requirements at a lower full-period cost than A Plus. This is an interpretation of the supplied case, not a result from a usability test. No purchase is authorised by this briefing.
```

```text
Vishva should test form submission and CSV export with dummy data. Shardha should review the workflow and confirm the purchase term. Data deletion timing, practical accessibility and ease of use remain unresolved. If B fails a required test or its current purchase conditions change, reassess it and trial A Plus if appropriate. Keep the dated source log with the decision record. [R0, F2, F4]
```

## 14.4.3 Check your work

The worked briefing is within the stated word range. It has a definite recommendation and explains what could change it. It does not hide the upfront term or turn a hypothetical trial into a completed test. Your wording may differ if those relationships and references remain correct.

## 14.5.2 Answer guide

B's project cost is INR 1050, not INR 350. Its capacity supports the required record count, but it does not guarantee sign-ups. Accessibility is untested. R0 needs one organiser, so A Plus is not excluded because it has one account. A corrected paragraph could say: “B meets the documented capacity and workflow requirements at INR 1050 for three months paid upfront. Trial its workflow before selection. A Plus also meets the documented requirements at INR 1200.”

## 14.6.2 Worked handover

```text
Briefing version 1 includes the decision page, R0 and F1 to F5, the source log and the calculation sheet. B is proposed for a trial, with A Plus retained as an eligible alternative. Vishva's workflow test and Shardha's review are pending. Usability, accessibility and deletion timing remain unresolved. The next decision is whether the trial evidence supports selection; no approval or purchase is recorded.
```

## 14.7.1 Answer guide

X costs INR 600 for two months but fails the two-organiser requirement. Y costs INR 450 × 2 = INR 900 and meets the documented requirements. Z's minimum purchase is three months, so the payable total is INR 400 × 3 = INR 1200, exceeding the budget by INR 300. Y is the documented candidate for a trial. Practical usability, accessibility and deletion timing remain untested. A briefing that recommends Z using only its INR 800 two-month arithmetic is incorrect.
