# Chapter 5 source inputs

These are fictional teaching sources from the current printed manuscript. Use the exact source ID and scope named in the exercise. Deliberate defects and old versions remain unchanged.

## 5.3 The approved project inputs

Use the following inputs as the current exercise brief. The event is Everyday AI Workshop, for adults who are new to AI. The purpose is to practise writing a clear prompt, asking a follow-up, and checking a short draft. The session is Saturday 7 November 2026, from 11 am to 1 pm IST, at Learning Room, Adyar, Chennai. Participants arrive at 10.40 am. Room access is 10 am to 1.30 pm.

The fee is INR 499 per ticket, capacity is 12 participants, and printed learning sheets are included. Participants bring their own laptop. Loan devices are not available for this exercise. Booking enquiries go to learn@example.com. The venue and projector test have been confirmed. Vishva handles registration and communications, the equipment coordinator handles setup and equipment, and Shardha teaches and reviews the pack. Their Saturday roles are confirmed by the exercise decision record.

The exact street address and accessible entrance route have not been supplied. Vishva must confirm and add them to joining instructions before sending the attendance reminder. Refund terms, payment instructions, refreshments, and certificates are not supplied. Do not create policies or benefits to fill those gaps.

Use a ticket status snapshot based on Chapter 3’s Raw v1 plus the approved 6 November decision that R010 is Cancelled. Exclude D07 because it exactly repeats D04. The resulting working view has eight Paid tickets, two Pending tickets, two Cancelled tickets, and no unresolved status. Paid receipts are INR 3,992; known active tickets are 10. Pending tickets count toward allocated capacity in this exercise.

## 5.3.1 Budget inputs

| Budget item | Qty | Unit INR | Amount INR |
| --- | --- | --- | --- |
| Venue | 1 | 1800 | 1800 |
| Facilitation | 1 | 1500 | 1500 |
| Printed materials | 12 | 35 | 420 |
| Equipment | 1 | 300 | 300 |
| Administration | 1 | 200 | 200 |
| Reserve | 1 | 300 | 300 |

These are planned cost inputs for the exercise, not invoices already paid. All amounts are in INR. No additional tax, discount, sponsorship, or delivery charge is supplied. The INR 300 reserve is a planned allowance kept in the budget, not a claim that an expense has occurred. Printed materials are budgeted for the current capacity, not only for Paid tickets.

## 5.9.2 Inspect this deliberately faulty draft fragment

```text
Invitation: “Join us on 7 November from 10 am to noon. All 12 places are still available.”
FAQ: “The fee is INR 450, and laptops and certificates are provided.”
Budget note: “All 12 fees have been received.”
Outline: “The questions section runs from 1 pm to 1.15 pm.”
```

## 5.12 Independent challenge Build a second business pack

Use this separate approved case. Event: First Steps in Photography. Audience: adults new to photography. Date: Saturday 14 November 2026. Session: 2 pm to 4 pm IST. Arrival: 1.40 pm. Venue: Studio Room, Kochi. Fee: INR 650 per ticket. Capacity: 10. Participants bring their own camera or camera phone. A digital handout is included; loan equipment is not available. Enquiries: photos@example.com. Exact street address, access route, refund terms, and payment instructions are not supplied.

Budget inputs: venue INR 1,500, facilitation INR 1,800, administration INR 200, reserve INR 300, and printed sign-in sheets for 10 participants at INR 20 each. Four tickets are Paid, two are Pending, and no other active tickets are recorded. Pending tickets count toward allocation. Do not add refreshments or certificates.

Write your own staged prompts and build a master brief, invitation under 140 body words, reminder under 90 words, FAQ, checked budget, and a four-part teaching outline. Allocate 50 minutes to introductions and first practice, 10 to a break, 45 to second practice and checking, and 15 to questions. Prepare a folder contents list, consistency review, and handover checklist.

Then apply this approved update: capacity becomes eight and printed sign-in-sheet quantity becomes eight. Preserve all other inputs. Recalculate the budget and identify every output affected. Keep collected fees separate from projections and leave joining-detail gaps visible.


## Official tool references

## ChatGPT

## Official references for the ChatGPT chapters

The references support the general product use and prompting guidance. The workshop scenarios, datasets, prompts, sample answers, plans, and assessments are teaching material. Product guidance was checked on 11 October 2026. Follow the current official instructions if your account or screen differs.

1 OpenAI  Use ChatGPT
https://learn.chatgpt.com/docs/use-chatgpt

2 OpenAI  Prompting
https://learn.chatgpt.com/docs/prompting

3 OpenAI  ChatGPT on the web
https://learn.chatgpt.com/docs/web
