# Chapter 2 Write prompts that produce usable drafts

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 2.4.2 Start with a broad request
Word body block 452

```text
Write a professional email asking someone to review my workshop invitation.
```

## 2.4.3 A specific prompt to try
Word body block 459

```text
Facts: Vishva is writing to his colleague Shardha. The Everyday AI Workshop invitation draft will be pasted below the email, not attached. Shardha should check the date, time, venue, and booking email. Her reply is due by 4 pm IST on 3 November 2026. She should send corrections or confirm those details are accurate. Sending approval is still pending.
```

## 2.4.3 A specific prompt to try
Word body block 460

```text
Task: Write a polite, direct request email with a subject line. Keep the body under 100 words. Include the review items, deadline, and requested reply. Use only these facts. Do not claim that the draft is attached or approved for sending.
```

## 2.6.1 Make a focused revision
Word body block 488

```text
Revise the email below so it sounds warmer between colleagues. Use ordinary English and one brief expression of thanks. Keep the body under 100 words. Preserve the recipient, sender, four review items, deadline, pasted-draft status, and pending sending approval. Keep the deadline definite. Do not add praise, urgency, or new promises.
```

## 2.6.1 Make a focused revision
Word body block 489

```text
[Paste the checked email here.]
```

## 2.7.1 Ask for a shorter version
Word body block 498

```text
Shorten the original Shardha email to a body of no more than 65 words, including greeting and sign-off. Retain all review items, the deadline, reply request, pasted-draft status, and pending sending approval. Include a subject line outside the limit. If these requirements conflict, identify the problem rather than silently removing a fact.
```

## 2.7.3 Update one approved fact
Word body block 504

```text
The review deadline is now noon IST on 4 November 2026. Update the subject and body of the concise email wherever the old deadline appears. Preserve every other fact and the 65-word body limit. After the email, add a one-sentence change log; the log is outside the body limit.
```

## 2.9.1 The specific prompt
Word body block 533

```text
Using only the lesson facts and registration table above, explain a spreadsheet filter to an adult who uses a phone but has never used a spreadsheet. Write two short paragraphs under 130 words in total. Say what a filter does, identify the names visible when payment status is Paid, and explain what happens to the other rows. Include one simple comparison, then explain its limitation. Avoid software button names, formulas, and unexplained jargon.
```

## 2.9.4 Change the audience
Word body block 544

```text
Rewrite the explanation for a colleague who already uses spreadsheets. Keep it under 70 words. Retain the selected condition, three visible names, six-record total, and distinction between hiding and deleting. Remove the book analogy and do not add product-specific instructions.
```

## 2.11.1 The specific prompt
Word body block 572

```text
Create a workshop preparation plan using only the planning brief and task table above. Use Monday 2 November to Friday 6 November 2026, with no more than 45 minutes on any day. Keep the task durations unchanged and respect every dependency. Keep each task within one daily session. Show a table with Day and date, Tasks with minutes, and Total minutes. Label unused time as buffer, not as extra work. After the table, show total task time, available time, and buffer time. Do not add evenings, weekends, or new tasks.
```

## 2.12.1 Ask for a feasibility check before another schedule
Word body block 594

```text
Add a poster design task estimated at 45 minutes to the original task list. Keep every original duration and the five 45-minute weekday sessions. Do not use evenings or weekends. Before making another schedule, calculate whether the work fits. If it does not, state the time shortfall and ask me to choose which requirement to change. Do not silently shorten a task or remove one.
```

## 2.12.3 Try one workable change
Word body block 600

```text
Defer the poster to a later week. Keep the original five-day plan and all original task durations. State that the poster is outside this week’s scope; do not mark it complete. Preserve the 20 minutes of buffer.
```

## 2.13.2 Prompt to try
Word body block 615

```text
I need a message about moving the Everyday AI Workshop. Use the incomplete brief above. Before drafting, ask no more than three questions needed to settle the replacement schedule, venue, and intended recipients. Combine related details in one question where useful. Do not invent a new date, reason, venue, or refund arrangement. Do not draft until I answer.
```

## 2.14.2 Now request the message
Word body block 626

```text
Use my answers to write an email for people already booked. Include a subject line and a body under 100 words. State that the workshop has moved from 7 November to 14 November 2026. Give the confirmed time, unchanged venue, and reply action. Use a calm, courteous tone. Do not invent a reason, refund policy, or claim that every attendee has accepted the change.
```

## 2.15.3 Prompt to try
Word body block 648

```text
Write a short request email using the new task facts above. Match the plain wording and brevity of the style example. The example is a style reference only: do not copy its people, room-booking task, or deadline. Include a subject line and a body under 80 words. Use the supplied sender, recipient, projector checks, deadline, and reply action. Do not add an attachment or repair arrangement.
```

## 2.16.1 Email pattern
Word body block 657

```text
Write an email from [sender] to [recipient] to achieve [purpose].
Facts: [confirmed details, dates, contacts, and requested action].
Use [tone]. Include a subject line and a body of [length].
Preserve [facts that must stay unchanged]. If [essential detail] is missing, [ask a question or use the agreed placeholder policy]. Use only the supplied facts.
After the draft, list any unresolved details separately.
```

## 2.16.2 Lesson explanation pattern
Word body block 659

```text
Explain [topic] to [reader and what they already know].
Source material: [definitions, examples, and data to use].
Write [length and structure]. Include [the required example or comparison]. Explain any limitation of the comparison.
Preserve [facts or calculations]. Avoid [irrelevant detail]. Keep unanswered questions separate from the explanation.
```

## 2.16.3 Weekly plan pattern
Word body block 661

```text
Build a plan for [date range] using [available sessions and limits].
Tasks: [task names, durations, and dependencies].
First check whether the total task time fits. If it does, show [required columns] and daily totals. Follow [task splitting rule]. Label unused time as buffer.
If it cannot fit, show the shortfall and ask which requirement may change. Keep task durations unchanged unless I approve a specific revision.
```

## 2.17.1 Give priorities when instructions conflict
Word body block 677

```text
Accuracy and the complete reply action take priority over my earlier length request. Tell me whether all required details can fit clearly in 20 words. If not, propose a practical length before rewriting. Keep the facts unchanged.
```
