# Chapter 6 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 6.4 Exercise 1 Ask for an explanation you can check

Goal: get a clear explanation with a testable example. Materials: source note C1 and the practice case. Output: an explanation under 120 words and a list of the facts it uses.

## 6.4.2 A possible answer

```text
Capacity is the most people the session can accept: 12. Eight places are confirmed, so four places remain available because there are no other holds. The three people on the waiting list have asked for a place, but their requests have not been accepted. They do not count as confirmed attendees yet. If the organiser accepts any waiting-list requests, the confirmed count and available places must be updated.
```

## 6.4.3 Check your result

• Capacity stays at 12, and confirmed places stay at eight.

• Available places equal 12 − 8 = 4.

• The three waiting-list requests remain separate from confirmed bookings.

• The explanation uses the supplied rules and meets the word limit.

The answer is useful because you can trace it to the source. A sentence such as “Only one seat is left” would be wrong: it subtracts the three unaccepted waiting-list requests as though they were already confirmed.

## 6.5 Exercise 2 Make the explanation simpler

Goal: change the presentation while keeping the meaning. Materials: your checked explanation from Exercise 1. Output: a shorter version that preserves the key distinction.

## 6.5.2 A possible revision

```text
The session can take 12 people. Eight places are confirmed, so four places are still available. Three people are waiting for a place, but the organiser has not accepted their requests. They are not confirmed attendees.
```

## 6.5.3 Check your result

Shorter wording is acceptable if the meaning survives. “There are 12 people at the session” changes capacity into attendance and fails the exercise. “There are eight confirmed places” is supported by the practice case.

## 6.5.4 A useful correction

Specific feedback tells Gemini what to change and why. “Make it better” leaves it to guess whether the problem is length, tone, or accuracy. Keep both versions and write one sentence describing the improvement.

## 6.6.2 A possible feedback response

```text
The mistake is counting waiting-list requests as confirmed places. C1 says those requests become confirmed only when the organiser accepts them. There are still eight confirmed places, so four places are available: 12 − 8 = 4.
```

```text
If the organiser accepts two waiting-list requests and nothing else changes, how many confirmed and available places will there be?
```

## 6.6.3 Answer guide after your attempt

Accepting two requests changes the confirmed count to 10 and available places to two. The capacity remains 12. One request remains on the waiting list. You should be able to explain the change without copying the wording above.

## 6.6.4 An example of a learner written summary

```text
I understand capacity as the upper limit, rather than the number who have booked. To find remaining places in this example, I subtract accepted places from that limit. Waiting requests stay separate until the organiser confirms them.
```

Use this example only after you have written your own summary. A summary written by Gemini and saved under your name does not show what you can explain independently.

## 6.7.2 A possible first question

```text
A session has capacity for 15 attendees. The organiser has confirmed nine places, with no other holds. How many places remain available, and which number describes capacity?
```

## 6.7.3 Worked answer guide

| Practice question | Checked answer |
| --- | --- |
| Capacity 15, confirmed nine, no holds | Six places remain. Capacity is 15. |
| Capacity 10, four waiting requests, confirmed count not supplied | Available places cannot be calculated. The confirmed count is missing. |
| Capacity 12, confirmed 10; organiser confirms one more place | Confirmed places become 11. One place remains available. |

Feedback should explain the source rule. If Gemini praises an incorrect answer, ask it to compare your calculation with C1. Agreement from the assistant does not replace the check.

## 6.8 Exercise 5 Separate an answer from its evidence

Goal: identify a fluent answer that adds unsupported facts. Materials: the short response below and C1. Output: a claim check with a corrected answer.

Response to inspect: “The 12-person room has eight confirmed attendees and three people waiting. Because waiting customers have paid a deposit, just one place is free. The venue will supply extra chairs if needed.”

## 6.8.2 A checked claim table

| Claim | Status | Source basis |
| --- | --- | --- |
| Capacity is 12 | Supported | Practice case gives capacity 12. |
| Eight places are confirmed | Supported | Practice case gives eight. |
| Three requests are waiting | Supported | Requests are not accepted yet. |
| Waiting customers paid deposits | Not supplied | No payment information appears. |
| Only one place is free | Contradicted | 12 − 8 = 4 under C1. |
| Extra chairs will be supplied | Not supplied | No equipment promise appears. |

## 6.8.3 A possible corrected answer

```text
Capacity is 12 and eight places are confirmed, leaving four available under the supplied rules. Three requests are on a waiting list and are not confirmed. The source gives no deposit information and no promise of extra chairs.
```

“Not supplied” is different from “false.” You cannot establish whether a deposit was paid from these notes. You can establish that the response was not entitled to state it as a known fact. Preserve that difference in your evidence record.

## 6.9.2 A possible answer

```text
Before the change, capacity is 20 and 14 places are confirmed. Six places are available: 20 − 14 = 6. Six requests are waiting. Accepting four requests raises confirmed places to 18: 14 + 4 = 18. Two places remain available: 20 − 18 = 2. Two requests remain on the waiting list: 6 − 4 = 2. Capacity stays at 20.
```

## 6.9.3 Check your result

All four categories must remain separate. Available places and waiting requests happen to have the same counts in this case, but they mean different things. One is the unused capacity; the other is people who have asked for a place without receiving confirmation.

## 6.11.1 Answer guide after your attempt

Initially, 30 − 12 = 18 units are available. Accepting three requests raises reservations to 15. Receiving four notebooks raises stock to 34. The final available count is 34 − 15 = 19. Two requests remain waiting. No collection or sale is supplied, so you must not reduce stock for an invented collection.

```text
The shop begins with 30 notebooks and 12 reservations, leaving 18 available. Accepting three requests changes reservations to 15. Receiving four notebooks changes stock to 34. Since nothing has been collected or sold, 19 notebooks are available for new requests: 34 − 15 = 19. Two of the five waiting requests remain unaccepted.
```

## 6.12 Check your understanding

## 6.12.1 Answer guide
