from decimal import Decimal


def buggy_total(unit_price, quantity, discount_percent):
    subtotal = Decimal(unit_price) * int(quantity)
    return subtotal - Decimal(discount_percent)


if __name__ == "__main__":
    print(f"Total INR {buggy_total('25', '12', '10'):.2f}")
