# Chapter 9 source inputs

These are fictional teaching sources from the current printed manuscript. Use the exact source ID and scope named in the exercise. Deliberate defects and old versions remain unchanged.

## 9.1 The supplied syllabus

Course: Planning a small workshop. This is a short practice syllabus for the fictional community project. Use U1–U6 as the knowledge source and Source A version 1.1 as the project fact source. The course’s rules define how the exercises will be assessed.

U1 Define a useful outcome
An outcome describes something a learner can do and how it will be checked. Example: calculate a supplied budget and show the working. A topic such as budgeting names the subject but does not describe the task.

U2 Keep facts and unknowns separate
A fact is supported by the supplied brief. An unknown is not supplied or is explicitly unresolved. Capacity describes the maximum allowed attendance; it does not establish bookings. Keep the source version with your notes.

U3 Calculate the planned budget
Multiply quantity by unit price for each variable cost, then add fixed costs and the reserve. Remaining budget equals the limit minus the total. The reserve counts inside the limit in this course. Revenue is not given, so profit cannot be calculated.

U4 Build an agenda that fits
An agenda allocates the complete available time to activities. Include practice and checking. Each interval must end where the next begins, without an overlap or an unexplained gap. These are the scheduling rules for the exercises in this course.

U5 Record unfinished arrangements
Every unresolved arrangement needs a named owner and a specific question or action. Proposed details must remain proposed. A drawing of a room does not confirm a booking, access arrangements, or equipment availability.

U6 Check work before saving
Compare names, dates, times, costs, and claims with the current brief. Recalculate totals independently. Record the original error, the correction, and the source used. Save the checked version and the evidence that supports it.

## 9.2 Study time and conditions

Sample study period: Monday 2 November to Sunday 15 November 2026. On weekdays, the learner can study from 7 pm to 7.30 pm IST. On Saturdays, the learner can study from 10 am to 10.45 am IST. Sundays are unavailable. Each session must include practice and checking. Do not add homework outside these windows.

The plan has two purposes. Week 1 introduces every unit. Week 2 revisits the units and includes an independent assessment. The dates and available times are sample constraints; Gemini must not add an extra hour because the syllabus looks ambitious.

## 9.2.1 Calculate the available time before planning

Each week has five weekday sessions at 30 minutes and one Saturday at 45 minutes. That is (5 × 30) + 45 = 195 minutes. Two weeks provide 390 minutes. Sundays contribute zero. A useful plan must fit that capacity and leave time for reviewing mistakes.

## 9.10 Independent challenge

Build a one-week study plan for Book Swap Helpers, from Monday 16 November to Sunday 22 November 2026. Weekdays allow 20 minutes, Saturday allows 30, and Sunday is unavailable. Use four supplied units: S1 write an observable planning outcome; S2 calculate the budget including reserve; S3 distinguish proposed arrangements from confirmed ones; S4 check the latest source version and record corrections. Each unit must appear, and the plan must include practice, assessment, and checking.

The practice source says capacity eight, proposed Community Room, Kochi, and an unconfirmed booking. The budget cap is INR 1500. Costs are venue 500, facilitation 600, eight learner packs at INR 15, and reserve 150. No fee or registration count is given. An old poster says 2 pm–2.45 pm; the current brief sets 28 November 2026, 3 pm–3.45 pm IST.

Write your own planning prompt, create the dated plan, and add four assessment questions with a verified key. Then suppose Wednesday’s 20-minute session is missed: revise the remaining plan without using Sunday or expanding any window.


## Current project brief from Chapter 8

## 8.3 Source A Community workshop brief

CURRENT PRACTICE SOURCE  |  VERSION 1.1

A1 Project
Plan Your First Workshop is a proposed community learning session coordinated by Vishva. The equipment coordinator is the proposed facilitator and Shardha is the reviewer.

A2 Date and time
The date is 21 November 2026. Version 1.1 sets the session time to 10.30 am to 11.30 am IST. It replaces the 10 am to 11 am time in version 1.0.

A3 Audience and capacity
The session is for adult beginners. Capacity is 12 attendees. No registration count is supplied.

A4 Learning format
Use English, paper activities, and a 60-minute session. Attendees must not be required to bring a phone or laptop.

A5 Budget limit
The total planned budget must be at most INR 2400, including the reserve. No participant fee or revenue is agreed.

A6 Supplied costs
Venue: INR 800. Facilitation: INR 900. Printed learner packs: 12 at INR 20 each. The printing figure covers learner resources and facilitator copies. Planning reserve: INR 200. Optional refreshments: 12 at INR 30 each, additional to the core budget. These are fictional planning figures, not current market quotations.

A7 Venue status
Learning Room, Adyar, Chennai is proposed. The room booking is not confirmed.

A8 Open questions
Step-free access and available room equipment have not been confirmed. The brief does not promise refreshments, certificates, parking, or loan devices.

A9 Review condition
The materials must be checked by Shardha. Venue and access questions must be resolved before public invitations are released.

A10 Source status
This is practice brief version 1.1. A room sketch labelled version 1.0 is an illustration and has an outdated time. It does not establish room availability or actual attendance.


## Official tool references

## Gemini

## Official references for the Gemini chapters

Product guidance was checked on 12 October 2026. The references support the Gemini access, file, privacy, and optional learning-tool instructions. The scenarios, source notes, illustrations, budgets, schedules, prompts, worked answers, and marking guides are teaching material created for this book. Follow the current official help if your account or interface differs.

1 Google  Use Gemini Apps
https://support.google.com/gemini/answer/13275745?hl=en
Official web app: https://gemini.google.com

2 Google  Upload and analyse files in Gemini Apps
https://support.google.com/gemini/answer/14903178?hl=en

3 Google  Gemini Apps Privacy Hub
https://support.google.com/gemini/answer/13594961?hl=en

4 Google  Use learning tools in Gemini Apps
https://support.google.com/gemini/answer/16448384?hl=en
