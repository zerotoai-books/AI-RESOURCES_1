# Chapter 48 Prepare and revise a multiscene voiceover

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 48.2.1 Useful prompt or direction
Word body block 5940

```text
Structure note: Welcome introduces the event and audience. Activity explains the English paper based exercise and printed materials. Booking gives the date, time, venue and contact. Keep headings as production labels unless deliberately spoken.
```

## 48.3.1 Useful prompt or direction
Word body block 5950

```text
Project direction: Use the supplied three part script with one narrator. Keep the initial voice and model consistent. Generate and review each part before the full export. Record any setting that differs by part.
```

## 48.4.1 Useful prompt or direction
Word body block 5960

```text
Join review sheet: Welcome to Activity ___; Activity to Booking ___. Check complete words, comfortable spacing, consistent narrator and intelligible logistics. Record actual timestamps after assembly.
```

## 48.5.1 Useful prompt or direction
Word body block 5970

```text
Replacement Activity paragraph: You will use printed materials to plan a simple learning activity. Work through an example, try your own plan, and review it with the group. No phone or laptop is needed.
```

## 48.6.1 Useful prompt or direction
Word body block 5980

```text
Export record: project version ___; part order Welcome, Activity, Booking; format ___; source quality as shown ___; measured total ___; complete playback result ___; approval Pending.
```
