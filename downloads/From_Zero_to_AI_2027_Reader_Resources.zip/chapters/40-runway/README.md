# Chapter 40 Build a short workshop promotion video

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 40.2 Exercise 1 Assemble the picture edit

Step 1  Create a project with the intended landscape dimensions and frame rate.

Step 2  Place the three visual slots and the final card on a thirty second timeline.

Step 3  Trim or hold sources deliberately and save an editable project version.



## 40.3 Exercise 2 Add exact and readable event titles

Step 1  Type the controlled title text printed in Appendix A7.

Step 2  Check each fact against B0 before styling.

Step 3  Preview at the intended viewing size and simplify any crowded card.



## 40.4 Exercise 3 Choose permitted audio and create a silent route

Step 1  Choose silence, your own recording or audio whose permission covers the intended use.

Step 2  Record the source, permission and any required credit.

Step 3  Keep voice and important words audible if adding background sound.



## 40.5 Exercise 4 Export and inspect the actual file

Step 1  Export a supported video format suitable for your intended destination.

Step 2  Open the file in a separate player and inspect properties, duration and playback.

Step 3  Check the start, every title, all joins, the audio if present and the final frame.



## 40.6 Exercise 5 Prepare the promotion handover

Step 1  Collect the final export, editable project or edit instructions, titles and source records.

Step 2  Summarise factual, visual, audio and reading checks.

Step 3  Mark Shardha approval Pending and list the exact next review action.

