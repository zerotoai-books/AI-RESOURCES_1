# Chapter 49 Create and check a second language version

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 49.2.1 Useful prompt or direction
Word body block 6009

```text
Translation brief: Prepare a Spanish promotion for an English language workshop. Preserve the event name, date, time in Indian Standard Time, venue, free attendance, adult beginner audience and contact. Do not imply Spanish instruction. Keep proper names and email spelling traceable to B0.
```

## 49.3.1 Useful prompt or direction
Word body block 6019

```text
Review the supplied Spanish draft against B0. Show where each required fact appears. Preserve uncertainty. Flag language questions for a proficient Spanish reviewer rather than claiming native approval.
```

## 49.4.1 Useful prompt or direction
Word body block 6029

```text
Contact listening test: After hearing the sentence once, write the booking address you understood. Compare it with learn@example.com. Record uncertainty about the English words or place names rather than assuming success.
```

## 49.5.1 Useful prompt or direction
Word body block 6039

```text
Test text: La actividad se realiza en inglés. Será el veintiuno de noviembre de dos mil veintiséis, desde las once de la mañana hasta el mediodía, hora estándar de la India.
```

## 49.6.1 Useful prompt or direction
Word body block 6049

```text
Localization handover: event source B0; English script version ___; Spanish draft version ___; text reviewer ___; audio reviewer ___; measured durations ___; unresolved items ___; approval Pending.
```
