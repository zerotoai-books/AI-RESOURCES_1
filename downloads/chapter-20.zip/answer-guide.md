# Chapter 20 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 20.2.2 Answer guide

The registration graphic is a designed call to action; it is not a working form or proof that registrations are being collected. No registration URL is supplied. Use the given placeholder email rather than inventing a live link or QR code. If you later receive a real registration URL, add and test it as a separately supplied fact.

## 20.3 Exercise 2 Assemble the worked content pack

## 20.3.2 Poster copy

```text
Plan Your First Workshop
A practical session for adult beginners
Saturday 21 November 2026
10.30 am to 11.30 am IST
Learning Room, Adyar, Chennai
```

```text
Practise a learning outcome, a supplied budget and a timed agenda.
Free to attend | Capacity 12
English | Printed practice materials included
No phone or laptop needed
Register: learn@example.com
```

```text
Fictional practice event
```

## 20.3.3 Square announcement copy

```text
Plan Your First Workshop
For adult beginners
Saturday 21 November 2026
10.30 am to 11.30 am IST
Learning Room, Adyar, Chennai
Free to attend | Capacity 12
No phone or laptop needed
Register: learn@example.com
Fictional practice event
```

## 20.3.4 Vertical story copy

```text
Plan Your First Workshop
For adult beginners
```

```text
Saturday 21 November 2026
10.30 am to 11.30 am IST
Learning Room, Adyar, Chennai
```

```text
English | Paper activities
Printed practice materials included
Free to attend | Capacity 12
No phone or laptop needed
```

```text
Register: learn@example.com
Fictional practice event
```

## 20.3.5 Registration graphic copy

```text
Register for Plan Your First Workshop
Saturday 21 November 2026
10.30 am to 11.30 am IST
Learning Room, Adyar, Chennai
```

```text
Adult beginners | Free to attend
Capacity 12 | No phone or laptop needed
```

```text
Email learn@example.com to register
Fictional practice event
```

## 20.3.6 Handout copy

```text
Plan Your First Workshop
Saturday 21 November 2026 | 10.30 am to 11.30 am IST
Learning Room, Adyar, Chennai
```

```text
This session helps adult beginners practise writing a learning outcome, calculating a supplied budget and building a timed agenda. It uses English and paper activities. Printed practice materials are included, and attendees do not need a phone or laptop.
```

```text
Attendance is free. Capacity is 12. To register, email learn@example.com. Step-free access is confirmed within the fictional venue brief; contact the organiser about specific access needs.
```

```text
No certificate, refreshments, parking, transport or device loan is promised.
Fictional practice event. The email is a placeholder.
```

## 20.3.7 Accompanying caption

```text
Plan Your First Workshop is a practical session for adult beginners on Saturday 21 November 2026, from 10.30 am to 11.30 am IST at Learning Room, Adyar, Chennai. Practise a learning outcome, a supplied budget and a timed agenda using English and paper activities. Printed practice materials are included. Attendance is free, capacity is 12 and no phone or laptop is needed. To register, email learn@example.com. Contact the organiser about specific access needs. This is a fictional practice event, and the email address is a placeholder.
```

## 20.3.8 Check your work

Compare the copy with C0 before laying it out. Keep the date, time and contact visible on the registration graphic even if you expect it to appear beside another post. Avoid a “last few seats” phrase: no registration count is supplied. The kit does not need a certificate icon, refreshment photo or device-loan image because those would imply offers absent from the brief.

## 20.4.2 Worked export manifest

| Suggested filename | Review format | Check |
| --- | --- | --- |
| Workshop_Poster_v2.pdf | Print review | A4 content and complete copy |
| Workshop_Square_v2.png | Screen review | 1080 × 1080 and readable contact |
| Workshop_Story_v2.png | Screen review | 1080 × 1920 and no cropped facts |
| Workshop_Register_v2.png | Screen review | Correct standalone action |
| Workshop_Handout_v2.pdf | Print review | Full text and print questions |
| Workshop_Caption_v2.txt | Plain text | Same current event facts |

## 20.4.3 Answer guide

These are suggested learner filenames, not claims that your downloads already exist. Fill the actual manifest with the files you produced. If a printer requires crop marks or bleed, the exported PDF page can be larger than the A4 trim size. Check the intended trim area and provider's specification rather than treating every larger PDF page as an error.

Do not describe PNGs or PDFs as editable Canva source designs. They are exports. Your source-design record should identify the designs in the account you used, and your handover should explain what access a reviewer would need. The exercise does not require changing access settings or publishing anything.

## 20.5.2 Worked handover template

```text
Release v2 uses C0 version 2 and C1 checked copy. The kit contains an A4 poster, square announcement, vertical story, registration graphic, A4 handout and caption. Editable source design names and actual export filenames are listed in the manifest. The original teaching illustration is identified in the asset record.
```

```text
Factual checks, phone-size checks and export inspection should be recorded for each asset. Any physical print proof or provider specification not yet checked remains pending. Shardha's review and the exercise release decision remain pending until recorded. The materials describe a fictional practice event and must not be published as a real invitation.
```

## 20.5.3 Answer guide

Replace a template's future-tense checking line with your actual completed observations when they exist. A complete handover can still contain pending approval; it must make the pending state clear. Do not create an approval entry merely to remove the word pending.

## 20.6.2 Worked change record

```text
Release v3 changes the event time from 10.30 am to 11.30 am IST to 11 am to noon IST, following C3. The five designs and caption require updates and fresh inspection. Date, venue, audience, fee, capacity, contact, materials and device requirement are unchanged. Version 2 is retained as an archive. Reviewer approval remains a separate recorded step.
```

## 20.6.3 Answer guide

There are six content items to check: five designs and one caption. If the poster changes but the registration graphic keeps the old time, the revised kit is incomplete. Replacing text in a source document does not update an already downloaded image. Each affected export must be produced and checked again.

## 20.7.1 Answer guide

The revised kit must use capacity six in all four content items. Date remains 28 November 2026, time 3 pm to 4.30 pm IST, venue Studio Room, Kochi, fee INR 650 and contact photos@example.com. The camera requirement remains. Do not change the workshop kit or carry its free-attendance statement into the Photography set. Access arrangements remain unknown for C2.
