# Chapter 16 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 16.3.2 Answer guide

The prompt supplies the design purpose and accurate copy. It does not ask Canva to research the event or complete missing arrangements. If the generated result adds “certified course” or “refreshments included,” remove those claims. The supplied facts govern the design, even if the added phrase makes the poster look more polished.

## 16.4.2 Worked route record

```text
Route used: Canva AI if available, otherwise blank A4 design with manual text boxes.
Draft name: Workshop A4 draft v1.
Required checks: exact event name, date, time zone, venue, free attendance, capacity and registration contact.
Result status: Draft awaiting text and layout review.
```

This is a template for your record, not evidence that a Canva generation has already happened. Replace the route line with what you actually did. A manual design can meet the chapter outcome if the facts, readability and editability are checked.

## 16.5 Exercise 3 Insert checked copy as editable text

## 16.5.2 Worked poster copy

```text
Plan Your First Workshop
A practical session for adult beginners
```

```text
Saturday 21 November 2026
10.30 am to 11.30 am IST
Learning Room, Adyar, Chennai
```

```text
Free to attend | Capacity 12
English | Printed practice materials included
No phone or laptop needed
```

```text
To register, email learn@example.com
```

```text
Fictional practice event
```

## 16.5.3 Answer guide

The test edit establishes that the wording is editable in your actual design. A PNG of the whole poster does not preserve those text elements as separate editable objects. Keep the source design as well as the export. “Capacity 12” states a maximum; do not change it to “12 seats left,” because bookings are not supplied.

## 16.6.2 Answer guide

The time should be 10.30 am to 11.30 am IST. Include the year, and include the supplied venue when building the standalone poster. Refreshments and a certificate are unsupported. “12 seats remaining” wrongly turns capacity into availability. A laptop is not required. The contact is learn@example.com, not learning@example.com. The event name is correct and can remain.

Keep a correction record: original wording; reason; replacement; source ID. This makes the review teachable. If you simply regenerate until the design happens to look right, you may lose track of which factual error was corrected.

## 16.7.2 Worked review note

```text
Review copy: Workshop A4 v2 screen review.
Text compared with C1: event, full date, time and IST, venue, free attendance, capacity and contact.
Layout inspected in the exported file: no cropped title, no missing line and registration contact readable.
Source design retained: editable text and layout remain in Canva.
Reviewer status: pending until the exercise review is recorded.
```

## 16.7.3 Check your work

Do not mark an item passed until you inspect the actual file. The editor view may differ from what you downloaded, especially if you selected the wrong page or exported a draft. A download completing successfully does not mean the correct version was exported.

## 16.8.1 Answer guide

The poster must use Saturday 28 November 2026, 3 pm to 4.30 pm IST, Studio Room, Kochi, capacity eight and INR 650 per person. It must ask attendees to bring their own camera or camera phone and use photos@example.com as the placeholder contact. Free attendance, paper-only participation and the workshop's venue must not carry over. Specific access arrangements are unknown in C2.
