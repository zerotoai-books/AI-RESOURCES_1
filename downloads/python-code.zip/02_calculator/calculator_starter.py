from decimal import Decimal
unit_price = "25"
quantity = "12"
print("Subtotal INR", Decimal(unit_price) * int(quantity))
