# Chapter 7 Develop ideas into a workable outline

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 7.3.1 Prompt to try
Word body block 1753

```text
Read workshop brief version 1.0. Extract the hard requirements, supplied cost inputs, and open questions. Separate confirmed information from proposed arrangements. Do not choose a concept yet. Do not invent a participant fee, registration count, access provision, or equipment promise.
```

## 7.3.4 Compare with a vague prompt
Word body block 1770

```text
Give me exciting ideas for a community workshop.
```

## 7.4.1 Prompt to try
Word body block 1780

```text
Suggest six community workshop concepts for this brief. For each, give a title, something a beginner could do by the end, one paper activity, and any extra costs or resources required. Use the supplied cost figures rather than inventing prices. Include different subject options. Mark any concept that fails a hard requirement; do not silently alter the brief to make it fit.
```

## 7.4.3 A useful follow-up
Word body block 1792

```text
Replace any concept with no clear learner activity. Describe a task that could be checked from the supplied material. Keep the proposal within the adult-beginner audience and explain any resource it needs.
```

## 7.5.1 Prompt to try
Word body block 1802

```text
Screen the six proposals against every hard requirement in brief 1.0. First calculate the core planned budget with the reserve. Add each proposal’s required extra. Show pass or reject, the total when the costs are known, and the decisive reason. Do not treat a low cost as a reason to ignore the device rule. Do not calculate profit because revenue is not supplied.
```

## 7.6.1 Prompt to try
Word body block 1830

```text
Develop Plan Your First Workshop into a 60-minute outline for 12 adult beginners. Use paper activities and the core budget of INR 2140. Include three observable learning outcomes, a timed agenda with practice and checking, the materials, and open questions. Keep the venue proposed. Do not require devices or add optional extras. Use the proposed 10 am–11 am IST time from version 1.0.
```

## 7.7.1 Prompt to try
Word body block 1862

```text
Review three suggested changes against brief 1.0: add refreshments for 12 at INR 30 each; expand attendance to 20 and print 20 learner packs at INR 20 each; advertise the room as accessible. Evaluate each independently. Show relevant calculations, identify the requirement or evidence involved, and recommend whether to accept it under the current brief. Do not change the cap or invent access confirmation.
```

## 7.7.3 A useful revision prompt
Word body block 1871

```text
Keep the selected outline within the original requirements. Exclude refreshments, retain capacity 12, and describe access as pending confirmation. Preserve the 60-minute agenda and INR 2140 core total. Add a short change record explaining these decisions.
```

## 7.8.1 Prompt to try
Word body block 1882

```text
Write a decision note under 200 words for Vishva and Shardha. Identify Plan Your First Workshop as the selected proposal, why it was chosen, which alternatives remain useful, the INR 2140 planned total and INR 260 remaining budget, and the requirements it meets. State the proposed date, time, venue, and capacity from brief 1.0. Keep unresolved arrangements visible and do not call this a confirmed public event.
```

## 7.9.1 Generate comparable options
Word body block 1899

```text
Using [brief], propose [number] options. For each, give the learner result, activity, required resources, and known extra costs. Keep proposals distinct from supplied facts and identify any hard requirement they fail.
```

## 7.9.2 Screen before ranking
Word body block 1901

```text
Test each option against [hard requirements]. Show calculations from [cost inputs]. Remove failing options, then compare the survivors against [preferences]. Treat scores as judgements and explain ties.
```

## 7.9.3 Record the decision
Word body block 1903

```text
Write a decision note with the selected concept, reason, rejected alternatives, checked costs, open questions, and source version. State what still needs confirmation before the proposal can be released.
```
