# Chapter 39 Plan a sequence and maintain continuity

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 39.2 Exercise 1 Give each shot a job

Step 1  Write one purpose for each of the three visual slots.

Step 2  Specify what the viewer should see and what title belongs over it.

Step 3  Keep the final information card separate from the generated footage.



## 39.3 Exercise 2 Write a continuity record

Step 1  List the fixed objects, palette, illustration style and light direction.

Step 2  Identify which details may vary, such as framing.

Step 3  Add a note that the scene is illustrative and not the real venue.



## 39.4 Exercise 3 Choose a method for the next shot

Step 1  For a simple cut, plan the new composition in the storyboard.

Step 2  For a continuation, inspect the outgoing final frame before using it as a new input.

Step 3  Record the chosen source and any frame extraction in the log.



## 39.5 Exercise 4 Review the joins as well as the clips

Step 1  Place the candidate clips in storyboard order in an available editor.

Step 2  Watch each join repeatedly at normal speed.

Step 3  Record changes in object identity, light, framing and motion direction.



## 39.6 Exercise 5 Lock the edit plan before adding audio

Step 1  Choose the three accepted sources or documented fallbacks.

Step 2  Confirm eight usable seconds for each visual slot and six seconds for the final card.

Step 3  Save a versioned edit decision list and unresolved review items.

