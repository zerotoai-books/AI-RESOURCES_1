# Chapter 8 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 8.5.2 A possible inventory

| Source | Visible version | Content |
| --- | --- | --- |
| Source A | 1.1 | Text brief with project facts, costs, and open questions. |
| Source B | 1.0 | Room drawing with an older date-and-time label. |

A file name can help identify an attachment, but it is not evidence that the contents have been read. Ask a small content question as a check: “What venue status appears in A7?” The correct answer is that Learning Room is proposed and its booking is not confirmed.

## 8.6.2 A checked extraction

| Item | Extracted fact | Source |
| --- | --- | --- |
| Project | Plan Your First Workshop | A1 |
| Date | 21 November 2026 | A2 |
| Current time | 10.30 am–11.30 am IST | A2 |
| Audience | Adult beginners; English; paper activities | A3 and A4 |
| Capacity | 12 attendees; registration count not supplied | A3 |
| Venue | Learning Room, Adyar, Chennai; proposed and not booked | A7 |
| Budget cap | INR 2400 including reserve | A5 |
| Costs | 800; 900; 12 × 20; reserve 200 | A6 |
| Revenue | No participant fee or revenue agreed | A5 |
| Unresolved | Access and equipment; review before release | A8 and A9 |

A source location needs enough detail for a reader to find the evidence. “In the document” is less useful than “A7.” If you later work with an ordinary PDF, use a page number and the relevant heading or short passage. The location must refer to the original source, not a page in Gemini’s generated response.

## 8.6.3 Check the calculation separately

A6 supplies inputs. The computed total is your derived result: 800 + 900 + (12 × 20) + 200 = INR 2140. Mark it as calculated from A6. The remaining INR 260 is calculated from A5 and A6. A correct calculation does not establish that these sums have been paid.

## 8.7.2 Checked observations

• The heading identifies a room sketch labelled version 1.0.

• The visible date is 21 November 2026.

• The visible time is 10 am to 11 am IST.

• There are 12 chair symbols arranged in three rows of four.

• The drawing labels a door on the left, a screen at the front, and a table near the front.

• It states that the illustration is not to scale.

## 8.8.2 A checked comparison

| Topic | Source A | Source B | Conclusion |
| --- | --- | --- | --- |
| Date | 21 November 2026 | 21 November 2026 | The date agrees. |
| Time | 10.30 am–11.30 am IST | 10 am–11 am IST | Use A2; update the image label before reuse. |
| Capacity evidence | Capacity 12 | 12 chair symbols | Symbols agree with the proposed size but do not prove bookings. |
| Booking status | Venue not confirmed | No booking evidence | Keep A7 status unresolved. |
| Access | Not confirmed | No access evidence | Do not state that access is confirmed. |

## 8.8.3 A possible version note

```text
Source A version 1.1 sets the current time to 10.30 am–11.30 am IST on 21 November 2026. Source B version 1.0 still shows 10 am–11 am IST. The current summary must use A2, and the older drawing’s time label needs updating before reuse. The date, capacity 12, core cost inputs, and unresolved venue status are unchanged.
```

Do not resolve a conflict by choosing the value that appears more often. An old time repeated on several drawings can still be outdated. In this exercise, the version rule tells you which source governs the current fact. Without that rule, the correct next step would be to ask the owner to confirm the current time.

## 8.9.2 A checked error record

| Claim | Problem | Repair |
| --- | --- | --- |
| Confirmed venue | A7 says booking is unconfirmed. | Keep the venue proposed. |
| 10 am–11 am current time | A2 replaces that older time. | Use 10.30 am–11.30 am IST. |
| 12 registered people | A3 supplies capacity, not registrations. | State capacity 12; bookings unknown. |
| Accessible room | A8 says access is unconfirmed. | Retain the open question. |
| INR 2140 already spent | A6 supplies planning figures only. | Call it the planned core total. |
| Refreshments included | A6 makes refreshments optional and additional. | Do not promise them. |
| Profit INR 260 | A5 gives no revenue. | INR 260 is remaining budget, not profit. |

## 8.9.3 A possible corrected summary

```text
Plan Your First Workshop is planned for 21 November 2026, 10.30 am–11.30 am IST. Learning Room, Adyar, Chennai is proposed but its booking is unconfirmed. Capacity is 12; no registration count is supplied. The core planned total is INR 2140 including reserve, leaving INR 260 under the cap. Refreshments are not included. Access and equipment remain unresolved, and revenue is not supplied. The older drawing has an outdated time label.
```

An error record helps you see recurring problems. In this example, several mistakes come from converting planning information into completed arrangements. Record that pattern so you can look for it in future source-based work.

## 8.10 Exercise 6 Assemble a checked evidence sheet

Goal: bring the observations, source locations, calculations, and corrections together. Materials: the two original sources and your checked records. Output: a final evidence sheet and summary under 140 words.

## 8.10.3 A possible final summary

```text
Plan Your First Workshop is planned for 12 adult beginners on 21 November 2026, from 10.30 am to 11.30 am IST. Source A version 1.1 governs the current time; the version 1.0 drawing still shows 10 am to 11 am. Learning Room, Adyar, Chennai remains a proposed venue with booking unconfirmed. The drawing contains 12 chair symbols, not evidence of 12 registrations. Using A6, the core planned budget is INR 2140 including reserve, leaving INR 260 under the cap. Refreshments are optional extra costs and are excluded from the selected plan. Access and equipment need confirmation, and Shardha must review the materials before release.
```

## 8.12.1 Answer guide after your attempt

Use 3 pm–3.45 pm IST from D. E’s 2 pm–2.45 pm time is outdated. Capacity is eight; registrations remain unknown. The venue is proposed and unbooked. The core total is 500 + 600 + (8 × 15) + 150 = INR 1370, leaving 1500 − 1370 = INR 130. Revenue is unknown, so profit cannot be calculated.

```text
Book Swap Helpers is planned for 28 November 2026, from 3 pm to 3.45 pm IST, with capacity for eight adult volunteers. Source D version 1.0 governs the time; Source E version 0.9 shows an outdated 2 pm start. Community Room, Kochi is proposed and unbooked. The core planned total is INR 1370 including reserve, leaving INR 130 under the cap. No registration count, fee, or revenue is supplied.
```

## 8.13 Check your understanding

## 8.13.1 Answer guide
