# Chapter 8 Review supplied files and images

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 8.2 Prepare the source files

Step 1  Open the files locally and confirm that they match the printed sources.

Step 2  Start a fresh Gemini chat.

Step 3  Use Add files and the local upload option shown in your account, select the sources, and add your prompt. File analysis requires signing in. [2]

Step 4  Check the attachment names before submitting.

Step 5  Ask Gemini to identify the attached sources before relying on an answer.

Step 6  Keep the originals beside the response for manual checking.



## 8.5 Exercise 1 Confirm what Gemini received

Step 1  Attach your typed Source A and captured Source B, or paste A and attach B.

Step 2  Enter the source-inventory prompt below.

Step 3  Compare the returned names and version labels with your own files.

Step 4  Look for any message that the file or image could not be read.

Step 5  Do not accept an analysis of an attachment Gemini says it cannot access.



## 8.6 Exercise 2 Extract the document facts with locations

Step 1  Ask for extraction using A only.

Step 2  Require the A1–A10 labels beside claims.

Step 3  Check the source text yourself for every row.

Step 4  Keep planned costs distinct from actual payments.

Step 5  Mark unconfirmed arrangements without completing them by guesswork.



## 8.7 Exercise 3 Describe what the image actually shows

Step 1  Inspect the image yourself before reading an AI answer.

Step 2  Write down the labels and count the chair symbols.

Step 3  Ask Gemini to produce observations with the prompt below.

Step 4  Check the response against the image at a readable size.

Step 5  Remove claims about actual bookings, access, or dimensions.



## 8.8 Exercise 4 Resolve the version conflict

Step 1  Place the two source versions side by side.

Step 2  Compare the date, time, capacity-related evidence, and venue status.

Step 3  Use the stated authority rule: A version 1.1 governs current project facts.

Step 4  Ask Gemini to record the conflict explicitly.

Step 5  Check that the final project summary uses the revised time.



## 8.9 Exercise 5 Repair a summary that overstates the evidence

Step 1  Underline every claim that needs evidence.

Step 2  Compare each with A and B.

Step 3  Separate a wrong current time from facts that are merely not supplied.

Step 4  Recalculate costs and remaining budget.

Step 5  Ask Gemini for repairs, then check the revised text yourself.



## 8.10 Exercise 6 Assemble a checked evidence sheet

Step 1  Write a source inventory with versions and a current-authority rule.

Step 2  Choose the claims that a project reviewer needs.

Step 3  Add evidence locations, limitations, and calculation working.

Step 4  Draft a concise summary from the sheet.

Step 5  Read the original sources one final time before saving.



## 8.13 Check your understanding

Step 1  What does the room sketch establish about attendance?

Step 2  Which source sets the current community session time?

Step 3  Why should calculated totals be labelled as calculations?

Step 4  Why is INR 260 not profit?

Step 5  What should happen if two real sources conflict without a stated current version?



## 8.13.1 Answer guide

Step 1  It shows 12 chair symbols, not registrations.

Step 2  A2 version 1.1 sets 10.30 am–11.30 am IST.

Step 3  They are derived from source inputs; show the working.

Step 4  It is unallocated budget; revenue is unknown.

Step 5  Record the conflict and ask the source owner to confirm the current fact.

