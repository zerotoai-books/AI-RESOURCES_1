# Chapter 27 Create formulas and inspect the results

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 27.1.1 Your task

Step 1  Check the Item, Quantity, UnitCost and LineTotal headers.

Step 2  Confirm room quantity one, materials quantity twelve and printing quantity twelve.

Step 3  Confirm unit prices 600, 25 and 15 as numbers.

Step 4  Keep the currency meaning in the labels or source record.

Step 5  Ask for an explanation before permitting an edit if you are uncertain.



## 27.2.1 Your task

Step 1  Name CostTable and the exact target column.

Step 2  Request formulas rather than hardcoded results.

Step 3  Inspect the first, middle and last data row in the formula bar.

Step 4  Check the resulting amounts with multiplication.

Step 5  Confirm that the input columns have not been overwritten.



## 27.3.1 Your task

Step 1  Put Budget limit INR in A12 and 1500 in B12.

Step 2  Put Planned cost INR in A13 and its formula in B13.

Step 3  Put Budget remaining INR in A14 and its formula in B14.

Step 4  Check total cost and remaining budget independently.

Step 5  Keep totals outside the detail so they are not counted twice.



## 27.4.1 Your task

Step 1  Use Status as the criterion for the record count.

Step 2  Keep the confirmed-seats sum as a separate measure.

Step 3  Put capacity in one input cell and refer to it.

Step 4  Divide confirmed seats by capacity once.

Step 5  Apply a percentage number format rather than multiplying by 100 again.



## 27.5.1 Your task

Step 1  Change the materials UnitCost from 25 to 30.

Step 2  Check its line total and the summary.

Step 3  Restore 25 before the next test.

Step 4  Clear the materials price and inspect the simple multiplication result.

Step 5  Add a guard that distinguishes a missing price from a genuine zero.

