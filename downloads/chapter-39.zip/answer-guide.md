# Chapter 39 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 39.2.2 Worked answer guide

The sequence moves from context to detail and back to an invitation. Its titles can read “Plan your first workshop,” “Try a paper based activity,” and “For adult beginners.” The information card then carries the date, time, venue and booking contact. These exact messages are original editorial choices based on B0.

Check your work. A storyboard row should have a purpose, source, intended duration and title. “Nice classroom video” does not tell the editor what belongs in the slot.

## 39.3.2 Worked answer guide

The record turns “make it consistent” into observable checks. A close shot may hide part of the pencil without violating the object list, but an extra notebook or a switch to a photorealistic room would need review. Avoid promising that repeated wording will lock identity across independently generated clips.

Check your work. Use the same reference version where the chosen mode permits it. Different references should be deliberate and documented, rather than accidental downloads with similar names.

## 39.4.2 Worked answer guide

Runway describes using a completed clip’s current frame as the starting image for another generation, then joining clips in an editor. [R4] That method can help a continuation, but it also carries any defect in the chosen frame forward. A simple cut to a prepared detail image may be easier for this exercise. Neither method guarantees seamless continuity.

Check your work. Do not reuse a distorted final frame merely because it is the last frame. Select a sound transition point and note any trimming needed.

## 39.5.2 Worked answer guide

A hypothetical jump from a flat illustration to a realistic photograph would break this sequence’s visual identity. A cut from a wider illustration to a closer illustration may be appropriate even though the framing changes abruptly. Judge the join against the planned purpose rather than treating every change as an error.

Check your work. A dissolve does not repair a misshapen object. Fix or replace the source before using a transition to make the edit feel smoother.

## 39.6.2 Worked answer guide

Eight plus eight plus eight plus six equals thirty seconds. The source clips may be longer; the selected ranges define the final use. If a clip has only six usable seconds, do not pretend it fills eight. Replace it, revise the timeline or use an explicitly planned still image hold.

Check your work. The handover should distinguish planned times from measured final edit times. Audio production in Chapters 46 to 50 can reuse the thirty second brief, but must be checked against the actual edit.

## 39.7.1 Answer guide after your attempt

The total is twenty seconds. A coherent sequence could show the camera, a closer view of a control and the camera beside a notebook, followed by the information card. Keep the same camera design and illustrative style. The risk might be a lens changing size at a cut. The card uses B1, including the fee and bring your own device requirement, not the free workshop facts.
