# Chapter 17 Improve hierarchy and readability

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 17.2.1 Your task

Step 1  Name the versions Workshop hierarchy A and Workshop hierarchy B.

Step 2  Check that both contain the same copy from C1.

Step 3  In B, make the title more prominent than the supporting description.

Step 4  Group date, time and venue.

Step 5  Give the registration contact a clear location.



## 17.3.1 Your task

Step 1  Adjust the values to the actual font and text length.

Step 2  Avoid fitting long lines by shrinking only the contact.

Step 3  Increase a text box's width or allow a sensible line break.

Step 4  Check that the title does not collide with the next group.

Step 5  Inspect a physical print or a realistic preview before accepting the sizes.



## 17.4.1 Your task

Step 1  Put the date, time and venue on a consistent alignment.

Step 2  Keep the email on a solid, uncluttered background.

Step 3  Compare navy text on white with white text on navy.

Step 4  Use amber as an accent, then test its actual readability.

Step 5  Preview in grayscale if you can; essential facts should remain clear.



## 17.5.1 Your task

Step 1  Identify the event name.

Step 2  Find the full date and time.

Step 3  Find the venue.

Step 4  Find the registration instruction.

Step 5  Record anything that required zooming or guessing.



## 17.6.1 Your task

Step 1  Open the candidate layouts or the labelled teaching comparison.

Step 2  Compare hierarchy, spacing and the next action using the same facts.

Step 3  Choose a version and write 80 to 120 words using observed differences.

Step 4  Keep remaining defects and any unperformed audience test visible.

