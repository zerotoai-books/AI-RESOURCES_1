# Chapter 29 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 29.1.2 Answer guide

Community and Workplace each have four confirmed seats. The total is eight. The formula in B7 must use A7 for its category, while keeping the same table columns and Confirmed criterion. If an unrecognised category is introduced later, investigate it and expand the category summary deliberately rather than allowing the record to disappear from the comparison.

## 29.2.2 Answer guide

Two equal values of four should produce equal bars or columns on the same scale. A chart titled All registrations would describe a different measure. Including the total of eight as a third category would compare the whole with its own parts and misrepresent the intended category comparison.

If creating the chart manually, select the summary's header and two data rows, then use Insert and an appropriate bar or column chart. Inspect the source references after creation. Colours and labels should help identify the values; they do not prove the underlying formula is correct.

## 29.3.2 Answer guide

The PivotTable should show Community four, Workplace four and Grand Total eight. Selecting it should expose Excel's PivotTable fields and controls. Inspect the aggregation: a Count of Seats may coincide with Sum of Seats in this one-seat case, but it expresses a different measure. Set Sum deliberately. [EREF8]

Use the native table as the source so the table's records define the population. A coloured range or ordinary formula summary does not complete this PivotTable exercise. Keep the PivotSummary sheet separate from the source data.

## 29.4.2 Worked change results

| Measure | Baseline | R07 Confirmed |
| --- | --- | --- |
| Community confirmed seats | 4 | 5 |
| Workplace confirmed seats | 4 | 4 |
| Total confirmed seats | 8 | 9 |
| Available seats at capacity 12 | 4 | 3 |

## 29.4.3 Answer guide

The source change adds one Community seat. The formulas and chart should follow their source cells. A PivotTable uses its own summary of the source, so explicitly refresh and inspect it; refresh behaviour varies by Excel version and settings. [EREF8] Returning the status to Waitlisted should restore four, four and eight after refresh.

If a new record is added, check both the Excel Table's boundaries and the PivotTable's source before refreshing. A row typed beneath a table is not safely included until you verify the table actually expanded. Recheck calculated columns and validation on the new row as well.

## 29.5.2 Worked dashboard explanation

```text
The cleaned teaching table contains eleven records. The dashboard compares only Confirmed seats: Community four and Workplace four, for a total of eight. The refreshed PivotTable uses Sum of Seats with Status filtered to Confirmed and matches the formula summary. R11 remains Needs review and is excluded from confirmed seats. Record the actual chart inspection and refresh test before marking this review complete.
```

## 29.5.3 Answer guide

This is an expected explanation for the teaching case. Replace claims about completed inspection and refresh with your actual observations. A PivotTable total of eleven indicates that the population or filter differs from the intended confirmed-seat measure. Check the filter and source rather than changing the visible total by hand.

## 29.6.1 Answer guide

Community has one confirmed seat from I01 and Workplace has one from I02, giving total two. I03 remains Needs review and I04 Cancelled. A summary of all four records would answer a different question. Inspect the Status filter and Sum of Seats aggregation in the actual PivotTable.
