# Chapter 43 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 43.2.2 Worked answer guide

The file has eleven data rows and eleven distinct IDs, R01 through R11. Statuses are Confirmed, Cancelled, Waitlisted and Needs review. Categories are Community and Workplace. The controlled file has no duplicate IDs or missing fields. These observations establish what the later counts mean.

Check your work. A header is not a data row. If your uploaded copy differs from the supplied fixture, stop and explain the difference rather than forcing the expected answer.

## 43.3.2 Worked answer guide

Confirmed is eight: R01, R02, R03, R05, R06, R08, R09 and R10. Cancelled is one, R04. Waitlisted is one, R07. Needs review is one, R11. Eight plus one plus one plus one equals eleven. This is an exact count of the supplied fixture, not a live registration report.

Check your work. A result saying “ten active attendees” may combine statuses without a defined rule. Use the exact labels until B3 defines a grouping.

## 43.4.2 Worked answer guide

Available places are four. Confirmed Community records are R01, R03, R05 and R09, giving four. Confirmed Workplace records are R02, R06, R08 and R10, also four. The two category counts reconcile to eight confirmed. Four available places does not establish that any new request has been accepted.

Check your work. Check the subtraction independently. If you accidentally used B2 capacity ten, you would get two; that is the wrong source version for this chapter.

## 43.5.2 Worked answer guide

F01 and F04 ask for larger or clearer printed text. F02 and F05 request more practice time. F03 and F06 value or request a clear recap. Suitable actions are to test print readability, protect practice time and prepare a concise recap sheet. The comments do not establish overall satisfaction or the needs of every participant.

Check your work. An action is a proposal until adopted. “All attendees need larger print” goes beyond these records; “two supplied comments mention print readability” is traceable.

## 43.6 Exercise 5 Write a checked organiser briefing

Your task. Combine the numerical and qualitative results without losing their different sources. The briefing should help the organiser decide what to review next.

## 43.6.2 Worked answer guide

A valid briefing reports eleven records, eight confirmed and four available under capacity twelve. It identifies the four plus four category split and the three feedback themes. It recommends checking print readability, protecting practice time and preparing a recap. It does not say those changes have been implemented or that the waiting list has been cleared.

Check your work. Count the IDs printed in Appendix A8 by hand or enter them in a spreadsheet and use the displayed filters. Verify eleven distinct records, eight Confirmed and four places available against capacity twelve. Compare category IDs as well as totals. No external checker file is needed, and these checks do not establish that a Claude conversation was run.

## 43.7.1 Answer guide after your attempt

Confirmed rises to nine, Waitlisted becomes zero, Cancelled remains one and Needs review remains one. Available places become three. R07 is Community, so confirmed Community becomes five and Workplace stays four. Nine plus zero plus one plus one still equals eleven. Save the changed fixture separately; do not overwrite the baseline used in Chapter 44.
