# Chapter 40 Build a short workshop promotion video

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 40.2.1 Useful prompt or direction
Word body block 5368

```text
Editor direction: Build the reviewed thirty second sequence. Keep visual slots at eight seconds each and the final card at six seconds. Use the listed sources only and record every still image fallback.
```

## 40.3.1 Useful prompt or direction
Word body block 5378

```text
Title direction: Use Plan Your First Workshop; 21 November 2026; 11 am to noon IST; Learning Room, Adyar, Chennai; Free for adult beginners; Book via learn@example.com. Keep exact facts editable.
```

## 40.4.1 Useful prompt or direction
Word body block 5388

```text
Audio plan: Default to a silent promotion with readable titles. If a reviewed voiceover is added later, use the approved script and record its source and actual duration. Do not use unverified music.
```

## 40.5.1 Useful prompt or direction
Word body block 5398

```text
Export review: Filename ___; format ___; measured duration ___; dimensions ___; playback checked ___; title facts checked ___; audio checked or absent ___; defects and actions ___.
```

## 40.6.1 Useful prompt or direction
Word body block 5408

```text
Handover summary: Version ___; workshop brief B0; final export ___; review results ___; source permissions ___; reviewer approval Pending; release not performed.
```
