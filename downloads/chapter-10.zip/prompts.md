# Chapter 10 Build a training resource pack

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 10.2.1 Prompt to try
Word body block 2416

```text
Design three observable learning outcomes for Plan Your First Workshop using A version 1.1 and U1–U6. For each, give a practice task, an assessment task, and what a reviewer should check. Keep the course paper-based and within 60 minutes. Do not add unrelated topics, devices, or outcomes that require an approved real venue.
```

## 10.3.1 Prompt to try
Word body block 2434

```text
Write a short lesson for the three outcomes in the checked map. Use adult-beginner language and the Plan Your First Workshop example from A version 1.1. Keep the script under 600 words. Explain facts and unknowns, budget working with reserve, and a 60-minute agenda with checking. Include brief learner pauses. Do not turn proposed arrangements into confirmed facts.
```

## 10.4.1 Prompt to try
Word body block 2461

```text
Create a paper worksheet for this mini-course with six numbered tasks. Use A version 1.1. Practise facts and unknowns, cost lines, an optional extra, a 60-minute agenda, unsupported claims, and an error record. Give the learner version first without answers. Then provide a separate answer guide with source labels. Do not introduce missing project facts.
```

## 10.5.1 Prompt to try
Word body block 2491

```text
Write facilitator notes for the completed lesson and worksheet. The session runs 10.30 am–11.30 am IST on 21 November 2026. Allocate the full 60 minutes without gaps or overlaps. Include preparation, when learners use each worksheet task, how to check the budget, when the independent assessment occurs, and how to handle an unresolved fact. Do not assume room equipment is confirmed.
```

## 10.6.1 Prompt to try
Word body block 2522

```text
Create a four-question, 10-minute assessment for L1–L3 using A version 1.1. Give marks totalling 10 and a separate key with source labels. Test facts and unknowns, total and remaining budget, a 60-minute agenda with checking, and a claim that confuses an older time or registrations. Allow equivalent correct wording. Do not reward invented project facts.
```

## 10.7.1 Prompt to try
Word body block 2547

```text
Audit the faulty pack fragments against A version 1.1 and the completed lesson, worksheet, schedule, and key. Identify every mismatch, give the source basis, and name the resources that must be checked after repair. Draft a handover note under 180 words. Keep venue, access, equipment, registrations, fee decisions, and Shardha’s approval unresolved where the source does not settle them.
```

## 10.8.1 Design from outcomes
Word body block 2585

```text
Using [current brief and syllabus], define observable outcomes and map each to practice and assessment. Keep within [audience, time, budget, and resource rules]. Identify any outcome the sources cannot support.
```

## 10.8.2 Draft consistent resources
Word body block 2587

```text
Write [lesson, worksheet, facilitator notes, or assessment] using the checked outcome map and [source version]. Preserve the project facts. Keep learner questions separate from keys and include a checking method.
```

## 10.8.3 Audit the whole pack
Word body block 2589

```text
Compare every resource against [current source]. Find mismatched names, dates, times, numbers, unsupported promises, and untested outcomes. Give a correction record and a handover note that retains unresolved conditions.
```
