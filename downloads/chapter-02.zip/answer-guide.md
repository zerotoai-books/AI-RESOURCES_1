# Chapter 2 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 2.5.1 An illustrative weak draft

```text
Subject: Urgent approval needed
```

```text
Dear Team,
Please review the attached invitation and approve it by tomorrow morning. Once approved, we will send it to all registered attendees.
Thank you.
```

This is a teaching example of a draft that would fail the brief. “Team” replaces the named recipient. The attachment does not exist, the deadline is wrong, and the review has become permission to send. Your actual Version A may have different problems or may simply leave gaps.

## 2.5.2 A possible checked draft

```text
Subject: Please review the Everyday AI Workshop invitation
```

```text
Hi Shardha,
Please review the Everyday AI Workshop invitation draft pasted below. Check the date, time, venue, and booking email, and reply by 4 pm IST on 3 November 2026 with any corrections or confirmation that these details are accurate. Approval to send the invitation is still pending.
Thanks,
Vishva
```

## 2.5.3 Check your result

• Shardha is the recipient and Vishva is the sender.

• The draft is described as pasted below, with no attachment claim.

• All four review items are named.

• The deadline includes the time zone and the full date.

• The requested reply is corrections or confirmation of accuracy.

• The email does not treat this factual review as sending approval.

Count the body separately from the subject line, including the greeting and sign-off. Check the count in your editor or manually; do not rely only on the assistant’s reported count.

## 2.6.2 A possible warmer version

```text
Subject: A quick review of the Everyday AI Workshop invitation
```

```text
Hi Shardha,
Thanks for helping with the invitation. Could you check the date, time, venue, and booking email in the draft pasted below? Please reply by 4 pm IST on 3 November 2026 with corrections or confirmation that these details are accurate. Approval to send the invitation is still pending.
Best,
Vishva
```

## 2.7.2 A possible concise version

```text
Subject: Workshop invitation review by 3 November
```

```text
Hi Shardha,
Please check the date, time, venue, and booking email in the Everyday AI Workshop draft pasted below. Reply by 4 pm IST on 3 November 2026 with corrections or confirmation that these details are accurate. Approval to send is still pending.
Thanks,
Vishva
```

The concise version retains the request and full deadline while reducing repeated wording. The subject uses a shorter date.

## 2.7.3 Update one approved fact

```text
Subject: Workshop invitation review by 4 November
```

```text
Hi Shardha,
Please check the date, time, venue, and booking email in the Everyday AI Workshop draft pasted below. Reply by noon IST on 4 November 2026 with corrections or confirmation that these details are accurate. Approval to send is still pending.
Thanks,
Vishva
```

Change log: The review deadline changed from 4 pm IST on 3 November 2026 to noon IST on 4 November 2026.

## 2.7.4 Check the revision

Search the draft for “3 November” and “4 pm”; neither should remain. Check noon, IST, and the subject date. Then read the complete email to find any old deadline elsewhere.

## 2.9 Write and check the lesson explanation

## 2.9.2 A possible explanation

```text
A spreadsheet filter helps you look at entries that match a condition. If you choose payment status Paid, you see Vishva, Shardha, and Participant 03. The other three rows are hidden from view, but their records are still there. Removing the filter shows all six rows again.
```

```text
Think of looking only at red books on a shelf while leaving the other books in place. The comparison helps explain selecting what to look at, but a spreadsheet filter works on information rather than physical books. It does not delete the hidden entries.
```

## 2.9.3 Check the explanation

• The visible names are Vishva, Shardha, and Participant 03: three Paid records.

• the equipment coordinator, Participant 05, and Participant 06 are hidden by this condition, not deleted.

• Removing the filter restores the view of all six rows.

• The analogy does not suggest that hidden records are removed.

• No specific software commands or unsupplied facts have been added.

## 2.9.4 Change the audience

```text
Filter the six registrations by payment status Paid. The visible rows are Vishva, Shardha, and Participant 03. The equipment coordinator, Participant 05, and Participant 06 remain in the table but are hidden from this view. Removing the filter shows all six records again. Filtering changes visibility; it does not delete records.
```

Try it yourself: change the condition to City is Chennai. Vishva, the equipment coordinator, and Participant 05 should be visible. There are still six records in total. Check that the assistant does not carry the earlier Paid condition into the new explanation.

## 2.11 Check the schedule and its dependencies

## 2.11.2 One possible checked plan

| Day and date | Tasks with minutes | Total |
| --- | --- | --- |
| Mon 2 Nov | Draft invitation 25; review invitation 10; draft reminder 10 | 45 |
| Tue 3 Nov | Draft FAQ 20; check FAQ 15; buffer 10 | 45 |
| Wed 4 Nov | Draft handout 35; buffer 10 | 45 |
| Thu 5 Nov | Review handout 15; outline presentation 30 | 45 |
| Fri 6 Nov | Check complete pack 15; revise issues 20; save and reopen 10 | 45 |

Task time is 205 minutes. Available time is 5 × 45 = 225 minutes. Buffer is 225 − 205 = 20 minutes. The daily totals include buffer. The plan fills five sessions without inventing 20 minutes of additional work.

## 2.12.2 A useful response would say

```text
The original tasks take 205 minutes. Adding the poster brings the required task time to 250 minutes. The five sessions provide 225 minutes, so the work exceeds capacity by 25 minutes.
```

```text
Would you like to add time to the weekday sessions, defer the poster, or reduce the scope of a specified task?
```

The arithmetic establishes a capacity shortfall. It does not tell you which task may be dropped. That decision belongs in the brief. The assistant should expose the conflict so you can change a requirement deliberately.

## 2.14 Complete the brief and check the change notice

## 2.14.1 The exercise answers

New date: 14 November 2026. Time: 11 am to 1 pm IST. The venue remains Learning Room, Adyar, Chennai. The recipients are people already booked. They should reply to learn@example.com if they cannot attend the new date. No reason for the change and no refund policy have been supplied.

## 2.14.3 A possible notice

```text
Subject: Everyday AI Workshop moved to 14 November
```

```text
Hello,
The Everyday AI Workshop has moved from 7 November to 14 November 2026. It will run from 11 am to 1 pm IST at Learning Room, Adyar, Chennai. The time and venue are unchanged.
If you cannot attend on the new date, please reply to learn@example.com.
Thank you,
Vishva
```

## 2.14.4 Check the source of each detail

The old date comes from the original brief. The replacement date and recipient group come from the answers. The time and venue appear in both and remain unchanged. The reply action comes from the answers. There is no supplied basis for mentioning a trainer emergency, promising refunds, or saying every booking has been reconfirmed.

The contact address is fictional. Save the draft in your log rather than sending it. In real work, distinguish a request to prepare wording from permission to communicate with other people.

## 2.15.1 Style example only

```text
Hi Shardha,
Please check the room booking by 2 pm on 30 October. Reply with confirmation or list anything still pending.
Thanks,
Vishva
```

## 2.15.4 A possible checked draft

```text
Subject: Projector check by noon on 5 November
```

```text
Hello,
Please check the workshop projector by noon IST on 5 November 2026. Test the power and image display, then reply to confirm both work or describe any problem.
Thanks,
Vishva
```

## 2.16.2 Lesson explanation pattern

## 2.19.1 Check before reading the answer guide

## 2.19.2 One valid preparation schedule

Read this only after you have checked your own plan. Monday: invitation draft 20, invitation review 10, reminder draft 10. Tuesday: lesson draft 25, lesson check 15. Wednesday: reminder review 10, consistency check 20, revisions 10. Thursday: remaining revisions 10, final read 20, save and reopen 10.

Every day totals 40 minutes. Required work is 160 minutes, matching the available 4 × 40 = 160. There is no buffer. Revisions are the only split task, shown as two 10-minute parts. The final read follows the completed revisions, and saving follows the final read.

A different plan can pass if it keeps these durations and dependencies. If you need contingency time in real work, agree a change to available time or task scope rather than claiming buffer that the arithmetic does not provide.

## 2.20.1 Questions to answer in your own words

## 2.20.2 Answer guide
