## Printed practice materials

Appendix A contains the additional inputs used by the chapters. Everything here can be recreated from the printed pages. Use the chapter’s source ID and version as the authority; do not substitute one tool’s dataset for another. The programs below are local teaching examples. Using GitHub Copilot as an assistant requires an eligible account, but a GitHub repository is not required.

A1  Build the Excel starter workbook

A2  Build the Excel tracker

A3  First Python programs

A4  Debugging and calculator tests

A5  Complete registration application

A6  Registration inputs and tests

A7  Drawings and presentation and video records

A8  Claude analysis inputs

A9  Browser seat calculator

A10  Worked operations example

A11  Complete voice scripts

A12  Reusable practice records

Start with your own practice folder. Enter only the listing or table content when creating a file. Section labels, captions, page numbers and running headers are book navigation and must not be typed into program files. Long code listings continue across pages in reading order. Save and run small pieces as instructed so a typing mistake is easy to locate.

## A1 Build the Excel starter workbook

For Chapters 26 to 29, start a blank workbook and save it as Excel_Copilot_Starter.xlsx. Create sheets named Registrations, Costs, RawRegistrations and Independent. Do not start with the eleven cleaned records: the first two chapters use the ten-record starting table.

On Registrations, enter the following header at A6:E6 and the ten rows at A7:E16. Enter Seats as the number 1. For RegistrationDate, type each value as a real date; for example use =DATE(2026,11,1), then Copy and Paste Special Values if needed. Format dates as yyyy-mm-dd. After entry, select A6:E16, choose Insert then Table, confirm My table has headers, and name it RegistrationTable in the table controls. On a Mac or in the web version, use the equivalent Insert Table control.

| RegistrationID | RegistrationDate | Category | Status | Seats |
| --- | --- | --- | --- | --- |
| R01 | 2026-11-01 | Community | Confirmed | 1 |
| R02 | 2026-11-02 | Workplace | Confirmed | 1 |
| R03 | 2026-11-03 | Community | Confirmed | 1 |
| R04 | 2026-11-04 | Workplace | Cancelled | 1 |
| R05 | 2026-11-05 | Community | Confirmed | 1 |
| R06 | 2026-11-06 | Workplace | Confirmed | 1 |
| R07 | 2026-11-07 | Community | Waitlisted | 1 |
| R08 | 2026-11-08 | Workplace | Confirmed | 1 |
| R09 | 2026-11-09 | Community | Confirmed | 1 |
| R10 | 2026-11-10 | Workplace | Confirmed | 1 |

On Costs, enter this table at A6:D9 and name it CostTable. The empty LineTotal cells are intentional; Chapter 27 adds formulas. Put Budget limit INR in A12 and numeric 1500 in B12. Keep commentary outside the table.

| Item | Quantity | UnitCost | LineTotal |
| --- | --- | --- | --- |
| Room | 1 | 600 |  |
| Materials | 12 | 25 |  |
| Printing | 12 | 15 |  |

## The twelve raw records

On RawRegistrations, enter the header at A6:E6 and the following twelve rows below it. Name A6:E18 RawRegistrationTable. Preserve the defects. In R02 Category, type one leading and one trailing space around workplace; the printed quotation marks below are delimiters showing those spaces and are not part of the cell value. For R06’s date, first format only that cell as Text, then type 2026/11/06. Keep R11 Status empty: the word blank below is an instruction, not a value to type. Enter the other dates as real dates. The two R03 rows must be identical in all five fields.

| RegistrationID | RegistrationDate | Category | Status | Seats |
| --- | --- | --- | --- | --- |
| R01 | 2026-11-01 | Community | Confirmed | 1 |
| R02 | 2026-11-02 | " workplace " | Confirmed | 1 |
| R03 | 2026-11-03 | Community | Confirmed | 1 |
| R03 | 2026-11-03 | Community | Confirmed | 1 |
| R04 | 2026-11-04 | Workplace | Cancelled | 1 |
| R05 | 2026-11-05 | Community | confirmed | 1 |
| R06 | 2026/11/06 | Workplace | Confirmed | 1 |
| R07 | 2026-11-07 | Community | Waitlisted | 1 |
| R08 | 2026-11-08 | Workplace | Confirmed | 1 |
| R09 | 2026-11-09 | Community | Confirmed | 1 |
| R10 | 2026-11-10 | Workplace | Confirmed | 1 |
| R11 | 2026-11-11 | Community | [leave blank] | 1 |

## The independent Excel dataset

On Independent, use the same five-column header and enter these five rows. Leave I03 Status empty. This is the dataset called Independent_Registrations.csv in the Excel exercises. It contains an exact duplicate and differs from the coding CSV in A6; keep those two exercises separate.

| RegistrationID | RegistrationDate | Category | Status | Seats |
| --- | --- | --- | --- | --- |
| I01 | 2026-11-01 | Community | Confirmed | 1 |
| I02 | 2026-11-02 | Workplace | Confirmed | 1 |
| I02 | 2026-11-02 | Workplace | Confirmed | 1 |
| I03 | 2026-11-03 | Community | [leave blank] | 1 |
| I04 | 2026-11-04 | Workplace | Cancelled | 1 |

## Expected cleaned records for Chapter 28

Compare only after your own cleaning attempt. The expected result is the ten clean records printed at the start of A1 plus R11 below. Retain all eleven once, in that order. Place the result on CleanedRegistrations and name its native table CleanRegistrationTable. R11 is retained with Needs review; do not promote or remove it.

| RegistrationID | RegistrationDate | Category | Status | Seats |
| --- | --- | --- | --- | --- |
| R11 | 2026-11-11 | Community | Needs review | 1 |

If a CSV is useful, you may save a copy of the sheet as CSV UTF-8 where your Excel version supports it. Saving CSV does not preserve tables, multiple sheets, formatting or all workbook features; keep the XLSX as your working master. Manual cell entry works in desktop and web Excel. Desktop Excel also offers Text to Columns for delimited text; web users can enter the cells directly. You may create these copies yourself or use the optional pack. Keep your own attempt separate from the supplied reference answers.

## A2 Build the Excel tracker

For Chapter 30, use your cleaned eleven-record table. If starting here, recreate A1 first. Keep RawRegistrations unchanged and add a Tracker sheet. Save a new workbook named Excel_Copilot_Worked_Tracker.xlsx only after completing and checking your own work.

| Cell | Label or input |
| --- | --- |
| A5 | Capacity |
| B5 | 12 |
| A6 | Budget limit INR |
| B6 | 1500 |
| A7 | Materials INR per seat |
| B7 | 25 |
| A8 | Printing INR per seat |
| B8 | 15 |
| A9 | Room estimate INR |
| B9 | 600 |

On CleanedRegistrations, add a sixth column headed IDCopies to CleanRegistrationTable. In its first data row type the formula below and confirm it fills the calculated column. Do not add this column to the untouched raw source.

## IDCopies formula

```text
=COUNTIFS(CleanRegistrationTable[RegistrationID],
  [@RegistrationID])
```

Enter labels in D5:D12 for Confirmed seats, Available seats, Seats over capacity, Capacity used, Needs review, Unclassified status, Blank IDs and Rows with repeated IDs. Enter the following formulas in the matching E cells. A displayed line break in a formula can be omitted when typing. In regions where Excel uses semicolons, use the local argument separator consistently.

## E5

```text
=SUMIFS(CleanRegistrationTable[Seats],
 CleanRegistrationTable[Status],"Confirmed")
```

## E6

```text
=IF(NOT(ISNUMBER(B5)),"Invalid capacity",
 IF(OR(B5<1,B5>40,B5<>INT(B5)),"Invalid capacity",
 MAX(0,B5-E5)))
```

## E7

```text
=IF(ISNUMBER(E6),MAX(0,E5-B5),"Invalid capacity")
```

## E8

```text
=IF(ISNUMBER(E6),E5/B5,"Invalid capacity")
```

## E9

```text
=COUNTIF(CleanRegistrationTable[Status],"Needs review")
```

## E10

```text
=ROWS(CleanRegistrationTable[Status])
 -COUNTIF(CleanRegistrationTable[Status],"Confirmed")
 -COUNTIF(CleanRegistrationTable[Status],"Waitlisted")
 -COUNTIF(CleanRegistrationTable[Status],"Cancelled")
 -COUNTIF(CleanRegistrationTable[Status],"Needs review")
```

## E11

```text
=COUNTBLANK(CleanRegistrationTable[RegistrationID])
```

## E12

```text
=COUNTIF(CleanRegistrationTable[IDCopies],">1")
```

Format E8 as a percentage with one decimal. At baseline E5:E12 shows 8, 4, 0, 66.7%, 1, 0, 0 and 0. The count of repeated-ID rows counts both rows of a duplicated pair. These formulas flag problems; they do not correct the source or authorise a booking decision.

| Cell or range | Entry |
| --- | --- |
| A14:D14 | Item | Quantity | UnitCost | LineTotal |
| A15:C15 | Room | 1 | =B9 |
| A16:C16 | Materials | =B5 | =B7 |
| A17:C17 | Printing | =B5 | =B8 |
| C19 | Planned cost INR |
| C20 | Budget remaining INR |
| C21 | Budget status |

Enter each vertical-bar-separated entry in its own cell; the bars are not cell contents. In D15 enter the formula below for the room cost. It checks the source price B9 directly. Use the separate capacity and source-price guard below for the materials and printing rows.

## D15 room cost with source price guard

```text
=IF(NOT(ISNUMBER($B$9)),"Missing input",
 IF($B$9<0,"Invalid input",B15*C15))
```

## D19

```text
=IF(COUNT(D15:D17)=ROWS(D15:D17),
 SUM(D15:D17),"Check costs")
```

## D20

```text
=IF(NOT(ISNUMBER(B6)),"Missing budget",
 IF(B6<0,"Invalid budget",
 IF(ISNUMBER(D19),B6-D19,"Check costs")))
```

## D21

```text
=IF(ISNUMBER(D20),
 IF(D20<0,"Over budget","Within budget"),"Check budget")
```

In D16 use the formula below. In D17 change $B$7 to $B$8 and B16*C16 to B17*C17. Check the source price cell directly: a linked cell such as C16 = B7 can display zero when B7 is blank, so testing C16 alone can mistake a missing input for a valid zero. These guards also reject invalid capacity and preserve genuine zero prices.

## D16 with capacity guard

```text
=IF(NOT(ISNUMBER(E6)),"Invalid capacity",
 IF(NOT(ISNUMBER($B$7)),"Missing input",
 IF($B$7<0,"Invalid input",B16*C16)))
```

For the category chart, put Category in G5 and Confirmed seats in H5; enter Community in G6 and Workplace in G7. Enter the following formula in H6 and copy down to H7. Select G5:H7 and insert a column chart. Use a zero baseline and a title identifying Confirmed seats by category. Create a separate native PivotTable as instructed in Chapter 29; this formula table does not replace it.

## H6 and copy down

```text
=SUMIFS(CleanRegistrationTable[Seats],
 CleanRegistrationTable[Category],G6,
 CleanRegistrationTable[Status],"Confirmed")
```

Use Data Validation to allow whole-number B5 from 1 to 40, nonnegative decimal B6:B9, the two permitted Category labels, four permitted Status labels, and exactly 1 for Seats. Test the error alert. Use conditional formatting to highlight E7 above zero, E9:E12 above zero, D20 below zero and any text error messages; keep readable labels beside the colours. A pasted value can bypass an entry rule, so retain the formula checks.

Put Reviewer status in D30 and Pending in E30. Put Reviewer initials in D31 and leave E31 empty. Enter the formula below in E32. Change E30 to Reviewed and enter initials only after a real review. R11 remains unresolved regardless of the review field.

## E32

```text
=IF(E30<>"Reviewed","Awaiting reviewer",
 IF(E31="","Add reviewer initials","Review recorded"))
```

Check baseline cost 1080 and budget remaining 420. Materials price 30 changes these to 1140 and 360. Capacity 10 changes them to 1000 and 500, with two available places. A blank materials price must produce a warning and no numeric complete total; a genuine zero price gives 780 and 720. Capacity six and budget 900 gives planned cost 840, remaining 60, zero available and two over capacity. Restore the baseline between tests. Chapter 30 and E2 print the remaining expected checks.

## A3 First Python programs

For Chapter 31, create folder 01_workspace, type the first listing and save it as hello_workshop.py. Open a terminal in that folder and run python hello_workshop.py. If your selected interpreter is invoked as py -3 or python3, use that command consistently. Check its version with python --version. Expected baseline output is Available seats: 4. Change only the main call to available_seats(12, 9) for the controlled revision, then restore it.

## hello_workshop.py

```text
def available_seats(capacity, confirmed):
    if type(capacity) is not int or type(confirmed) is not int:
        raise ValueError("Use whole-number counts")
    if capacity <= 0 or confirmed < 0 or confirmed > capacity:
        raise ValueError("Counts outside the allowed range")
    return capacity - confirmed


def main():
    print("Available seats:", available_seats(12, 8))


if __name__ == "__main__":
    main()
```

## The complete materials calculator

For Chapter 32, create a separate folder 02_calculator. For the initial planning and implementation exercises, begin calculator.py with the small fixed-input starter below. It prints only a subtotal and does not yet implement the quote rules. Keep this starter separately before revising it in the chapter.

## Initial calculator starter

```text
from decimal import Decimal
unit_price = "25"
quantity = "12"
print("Subtotal INR", Decimal(unit_price) * int(quantity))
```

After your implementation attempt, compare it with the complete calculator.py below. Replace the starter with the entire answer listing, including imports and main guard, before running the reference tests. Indentation is four spaces per level. Run python calculator.py 25 12 --discount 10: expect Subtotal INR 300.00, Discount INR 30.00 and Total INR 270.00 on three lines. Quantity 12.5 must fail with an input error and no normal total.

## calculator.py

```text
import argparse
import re
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP


@dataclass(frozen=True)
class Quote:
    subtotal: Decimal
    discount: Decimal
    total: Decimal


def text(value):
    if not isinstance(value, str):
        raise ValueError("Inputs must be text")
    return value.strip()


def whole(value, low, high):
    value = text(value)
    if not re.fullmatch(r"[0-9]+", value):
```

```text
        raise ValueError("Use whole-number text")
    # Length guard avoids converting an unbounded integer.
    value = value.lstrip("0") or "0"
    if len(value) > len(str(high)):
        raise ValueError("Whole number outside allowed range")
    number = int(value)
    if not low <= number <= high:
        raise ValueError("Whole number outside allowed range")
    return number


def quote(unit_price, quantity, discount_percent="0"):
    raw = text(unit_price)
    if not re.fullmatch(r"[0-9]+(?:\.[0-9]{1,2})?", raw):
        raise ValueError("Use a price with up to two decimals")
    raw = raw.lstrip("0") or "0"
    if raw.startswith("."):
        raw = "0" + raw
    if len(raw.split(".")[0]) > 6:
        raise ValueError("Price outside 0 to 100000")
    price = Decimal(raw)
    if not 0 <= price <= 100000:
```

```text
        raise ValueError("Price outside 0 to 100000")
    count = whole(quantity, 1, 40)
    percent = whole(discount_percent, 0, 100)
    subtotal = price * count
    discount = (subtotal * percent / 100).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP
    )
    return Quote(subtotal, discount, subtotal - discount)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("price")
    parser.add_argument("quantity")
    parser.add_argument("--discount", default="0")
    args = parser.parse_args()
    try:
        result = quote(args.price, args.quantity, args.discount)
    except ValueError as error:
        parser.error(str(error))
    for name in ("subtotal", "discount", "total"):
        value = getattr(result, name)
```

```text
        print(f"{name.title()} INR {value:.2f}")


if __name__ == "__main__":
    main()
```

Typing check. Straight quotation marks and the backslash in the regular expression are code punctuation. Preserve the line continuation supplied by parentheses. Do not type the book’s caption as code. Unit tests in A4 check invalid values and the rounding order as well as the baseline.

## A4 Debugging and calculator tests

For Chapter 33, create folder 03_debug and type the two listings below. Run python calculator_buggy.py: it intentionally prints Total INR 290.00. Run python -m unittest -v test_buggy: one assertion should fail because K1 requires 270.00. Record the actual failure before changing anything. This negative example must not be mixed into a suite expected to pass.

## calculator_buggy.py

```text
from decimal import Decimal


def buggy_total(unit_price, quantity, discount_percent):
    subtotal = Decimal(unit_price) * int(quantity)
    return subtotal - Decimal(discount_percent)


if __name__ == "__main__":
    print(f"Total INR {buggy_total('25', '12', '10'):.2f}")
```

## test_buggy.py

```text
import unittest
from decimal import Decimal
from calculator_buggy import buggy_total


class BugTest(unittest.TestCase):
    def test_original_failure(self):
        self.assertEqual(
            buggy_total("25", "12", "10"), Decimal("270.00")
        )


if __name__ == "__main__":
    unittest.main()
```

## The minimal repair

Make a separate working copy. Keep the name buggy_total in your repaired calculator_buggy.py so the unchanged test_buggy.py still calls the function. Add ROUND_HALF_UP to its decimal import and replace the calculation with the body of fixed_total below. The separate filename calculator_fixed.py and function name fixed_total identify the printed answer only. This repair assumes controlled valid inputs; the full validation belongs to calculator.py in A3.

## calculator_fixed.py

```text
from decimal import Decimal, ROUND_HALF_UP


def fixed_total(unit_price, quantity, discount_percent):
    subtotal = Decimal(unit_price) * int(quantity)
    discount = (
        subtotal * Decimal(discount_percent) / Decimal("100")
    ).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return subtotal - discount
```

## test_fixed.py

```text
import unittest
from decimal import Decimal
from calculator import quote

class RegressionTests(unittest.TestCase):
    def test_baseline(self):
        self.assertEqual(quote("25", "12", "10").total,
                         Decimal("270.00"))

    def test_independent(self):
        self.assertEqual(quote("40", "5", "15").total,
                         Decimal("170.00"))

if __name__ == "__main__":
    unittest.main()
```

Save test_fixed.py in a separate folder beside a copy of the full calculator.py from A3. Run python -m unittest -v test_fixed. Two methods should pass. The name here refers to regression checking of the correct implementation, not a claim that the intentionally buggy baseline has changed.

## The complete Chapter 34 suite

In a fresh folder 04_tests, save calculator.py from A3 and the following complete test_calculator.py. Run python -m unittest -v test_calculator. Six methods should pass; the subtests include multiple input combinations. Run this suite after each change. The CLI check launches the selected interpreter through sys.executable and also checks that importing calculator prints nothing.

## test_calculator.py

```text
import subprocess
import sys
import unittest
from decimal import Decimal
from pathlib import Path
from calculator import quote

HERE = Path(__file__).resolve().parent


class QuoteTests(unittest.TestCase):
    def test_baseline_components(self):
        q = quote("25", "12", "10")
        self.assertEqual(q.subtotal, Decimal("300.00"))
        self.assertEqual(q.discount, Decimal("30.00"))
        self.assertEqual(q.total, Decimal("270.00"))

    def test_independent(self):
        self.assertEqual(quote("40", "5", "15").total,
                         Decimal("170.00"))

    def test_rounding_order(self):
```

```text
        self.assertEqual(quote("0.05", "3", "10").total,
                         Decimal("0.13"))
        self.assertEqual(quote("0.05", "1", "50").total,
                         Decimal("0.02"))

    def test_other_valid_inputs(self):
        cases = [("0", "1", "0", "0"),
                 ("25", "12", "100", "0"),
                 ("19.99", "3", "10", "53.97"),
                 (" 25 ", "12", "0", "300"),
                 ("100000", "40", "0", "4000000")]
        for price, count, percent, expected in cases:
            with self.subTest(price=price, percent=percent):
                self.assertEqual(quote(price, count, percent).total,
                                 Decimal(expected))

    def test_invalid_inputs(self):
        cases = [("NaN", "1", "0"), ("Infinity", "1", "0"),
                 ("25.001", "1", "0"), ("-1", "1", "0"),
                 ("INR25", "1", "0"), ("1e2", "1", "0"),
                 ("1,000", "1", "0"), ("100000.01", "1", "0"),
                 ("", "1", "0"), ("25", "0", "0"),
```

```text
                 ("25", "41", "0"), ("25", "12.5", "0"),
                 ("25", "1", "101"), ("25", "1", "-1"),
                 (True, "1", "0"), ("25", 1, "0")]
        for args in cases:
            with self.subTest(args=args):
                with self.assertRaises(ValueError):
                    quote(*args)

    def test_command_and_import(self):
        def run(*args):
            return subprocess.run(
                [sys.executable, *args], cwd=HERE,
                capture_output=True, text=True
            )
        result = run("calculator.py", "25", "12", "--discount",
                     "10")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Total INR 270.00", result.stdout)
        self.assertNotEqual(
            run("calculator.py", "25", "12.5").returncode, 0
        )
        self.assertEqual(run("-c", "import calculator").stdout, "")
```

```text


if __name__ == "__main__":
    unittest.main()
```

The six-method suite checks baseline components, independent arithmetic, two rounding cases, valid boundaries, invalid formats and types, and the command-line route. It does not prove correctness for every possible input or check Copilot’s interface. Record your own observed results. The separate two-method test_fixed example is optional teaching practice and is not included in the fourteen-method combined-suite total.

## A5 Complete registration application

For Chapter 35, create folder 05_registration. Type registration.py and app.py below, preserving indentation. Then create the CSVs and test file in A6 in the same folder. The application is for one operator using fictional data, not a hosted booking service. It stores an unencrypted local SQLite file; keep personal data out of the exercise. All imports are in Python’s standard library. No repository, package installation or API key is required.

The Store context closes its connection. Each write opens an explicit transaction and rolls back on error. CSV imports use one transaction for the whole file. Opening an existing database uses mode=rw so a missing file is not silently created. These choices support the persistence and rollback checks printed in K2 and K3.

## registration.py

```text
import csv
import re
import sqlite3
from contextlib import contextmanager
from datetime import date
from pathlib import Path

FIELDS = ["RegistrationID", "Alias", "RegistrationDate",
          "Category", "Status"]
CATEGORIES = ("Community", "Workplace")
STATUSES = ("Confirmed", "Waitlisted", "Cancelled", "Needs review")


def label(value, choices):
    if not isinstance(value, str):
        raise ValueError("Missing label")
    for choice in choices:
        if value.strip().casefold() == choice.casefold():
            return choice
    raise ValueError("Unknown label: " + value)


```

```text
def record_id(value):
    if not isinstance(value, str):
        raise ValueError("Missing ID")
    value = value.strip()
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{1,11}", value):
        raise ValueError("Invalid ID")
    return value.upper()


def clean(row):
    if set(row) != set(FIELDS):
        raise ValueError("Wrong record fields")
    ident = record_id(row["RegistrationID"])
    alias = row["Alias"]
    if not isinstance(alias, str):
        raise ValueError("Missing alias")
    alias = alias.strip()
    if not 1 <= len(alias) <= 40 or any(
        ord(c) < 32 or ord(c) == 127 for c in alias
    ):
        raise ValueError("Invalid alias")
    day = row["RegistrationDate"]
```

```text
    if not isinstance(day, str) or not re.fullmatch(
        r"[0-9]{4}-[0-9]{2}-[0-9]{2}", day
    ):
        raise ValueError("Use YYYY-MM-DD")
    date.fromisoformat(day)
    category = label(row["Category"], CATEGORIES)
    status = label(row["Status"], STATUSES)
    return (ident, alias, day, category, status)


class Store:
    @classmethod
    def create(cls, path, capacity=12):
        if type(capacity) is not int or not 1 <= capacity <= 40:
            raise ValueError("Capacity must be 1 to 40")
        path = Path(path)
        with path.open("x"):
            pass
        db = sqlite3.connect(path, isolation_level=None)
        try:
            db.execute("BEGIN IMMEDIATE")
            db.execute("CREATE TABLE settings "
```

```text
                       "(capacity INTEGER, version INTEGER)")
            db.execute("INSERT INTO settings VALUES (?, 1)",
                       (capacity,))
            db.execute("CREATE TABLE registrations "
                       "(RegistrationID TEXT PRIMARY KEY, "
                       "Alias TEXT, RegistrationDate TEXT, "
                       "Category TEXT, Status TEXT)")
            db.commit()
        except Exception:
            db.rollback()
            db.close()
            path.unlink()
            raise
        else:
            db.close()

    def __init__(self, path):
        path = Path(path).resolve()
        # mode=rw refuses to create a missing database.
        self.db = sqlite3.connect(
            path.as_uri() + "?mode=rw", uri=True,
            isolation_level=None
```

```text
        )
        try:
            row = self.db.execute(
                "SELECT capacity, version FROM settings"
            ).fetchone()
            if row is None or row[1] != 1:
                raise ValueError("Unsupported database")
            self.capacity = row[0]
            if type(self.capacity) is not int or not (
                1 <= self.capacity <= 40
            ):
                raise ValueError("Invalid saved capacity")
        except Exception:
            self.db.close()
            raise

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.db.close()

```

```text
    @contextmanager
    def write(self):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            yield
            self.db.commit()
        except Exception:
            self.db.rollback()
            raise

    def confirmed(self):
        return self.db.execute(
            "SELECT COUNT(*) FROM registrations "
            "WHERE Status = ?", ("Confirmed",)
        ).fetchone()[0]

    def _insert(self, row):
        values = clean(row)
        if values[4] == "Confirmed" and (
            self.confirmed() >= self.capacity
        ):
            raise ValueError("Capacity is full")
```

```text
        self.db.execute(
            "INSERT INTO registrations VALUES (?, ?, ?, ?, ?)",
            values
        )

    def add(self, ident, alias, day, category, status):
        values = (ident, alias, day, category, status)
        with self.write():
            self._insert(dict(zip(FIELDS, values)))

    def import_csv(self, filename):
        with open(filename, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f, strict=True)
            if reader.fieldnames != FIELDS:
                raise ValueError("Wrong CSV header or order")
            with self.write():
                for row in reader:
                    self._insert(row)

    def set_status(self, ident, status):
        ident = record_id(ident)
        status = label(status, STATUSES)
```

```text
        with self.write():
            row = self.db.execute(
                "SELECT Status FROM registrations "
                "WHERE RegistrationID = ?", (ident,)
            ).fetchone()
            if row is None:
                raise ValueError("Unknown ID")
            if status == "Confirmed" and row[0] != status:
                if self.confirmed() >= self.capacity:
                    raise ValueError("Capacity is full")
            self.db.execute(
                "UPDATE registrations SET Status = ? "
                "WHERE RegistrationID = ?", (status, ident)
            )

    def rows(self):
        rows = self.db.execute(
            "SELECT * FROM registrations ORDER BY RegistrationID"
        ).fetchall()
        return [dict(zip(FIELDS, row)) for row in rows]

    def summary(self):
```

```text
        rows = self.rows()
        counts = {s: sum(r["Status"] == s for r in rows)
                  for s in STATUSES}
        confirmed = counts["Confirmed"]
        return {"capacity": self.capacity, "confirmed": confirmed,
                "available": self.capacity - confirmed,
                "total_records": len(rows), "statuses": counts}
```

## app.py

```text
import argparse
import csv
import json
import sqlite3
from registration import Store


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", required=True)
    commands = parser.add_subparsers(dest="command", required=True)
    init = commands.add_parser("init")
    init.add_argument("--capacity", type=int, default=12)
    load = commands.add_parser("import-csv")
    load.add_argument("filename")
    change = commands.add_parser("set-status")
    change.add_argument("--id", required=True)
    change.add_argument("--status", required=True)
    commands.add_parser("summary")
    commands.add_parser("list")
    args = parser.parse_args()
    try:
```

```text
        if args.command == "init":
            Store.create(args.db, args.capacity)
            print("Initialised")
            return 0
        with Store(args.db) as store:
            if args.command == "import-csv":
                store.import_csv(args.filename)
                print("Imported")
            elif args.command == "set-status":
                store.set_status(args.id, args.status)
                print("Updated")
            elif args.command == "summary":
                print(json.dumps(store.summary(), indent=2))
            else:
                print(json.dumps(store.rows(), indent=2))
    except (ValueError, csv.Error) as error:
        print("Input error:", error)
        return 2
    except (OSError, sqlite3.Error) as error:
        print("Storage error:", error)
        return 3
    return 0
```

```text


if __name__ == "__main__":
    raise SystemExit(main())
```

Run commands from this folder and put --db before the subcommand. Quote a path containing spaces. Use a new database filename for each fresh scenario: init deliberately refuses to replace an existing file. Input errors return status 2; storage errors return status 3. A duplicate-ID error is raised by SQLite and follows the storage-error route; it must still leave the old records unchanged.

## A6 Registration inputs and tests

Create each CSV below as plain UTF-8 text. Include the same exact header in every file. A comma separates fields; Guest aliases contain spaces but no commas. This schema contains Alias and no Seats column. Do not use the five-column Excel CSV in A1: that file has a different meaning and column order.

## demo_registrations.csv

```text
RegistrationID,Alias,RegistrationDate,Category,Status
R01,Guest 01,2026-11-01,Community,Confirmed
R02,Guest 02,2026-11-02,Workplace,Confirmed
R03,Guest 03,2026-11-03,Community,Confirmed
R04,Guest 04,2026-11-04,Workplace,Cancelled
R05,Guest 05,2026-11-05,Community,Confirmed
R06,Guest 06,2026-11-06,Workplace,Confirmed
R07,Guest 07,2026-11-07,Community,Waitlisted
R08,Guest 08,2026-11-08,Workplace,Confirmed
R09,Guest 09,2026-11-09,Community,Confirmed
R10,Guest 10,2026-11-10,Workplace,Confirmed
R11,Guest 11,2026-11-11,Community,Needs review
```

## extra_confirmed.csv

```text
RegistrationID,Alias,RegistrationDate,Category,Status
R12,Guest 12,2026-11-12,Community,Confirmed
R13,Guest 13,2026-11-12,Community,Confirmed
R14,Guest 14,2026-11-12,Community,Confirmed
R15,Guest 15,2026-11-12,Community,Confirmed
```

## overflow_confirmed.csv

```text
RegistrationID,Alias,RegistrationDate,Category,Status
R16,Guest 16,2026-11-12,Community,Confirmed
```

## bad_import.csv

```text
RegistrationID,Alias,RegistrationDate,Category,Status
R20,Guest 20,2026-11-12,Community,Waitlisted
R01,Changed,2026-11-01,Community,Confirmed
```

## invalid_status.csv

```text
RegistrationID,Alias,RegistrationDate,Category,Status
R21,Guest 21,2026-11-12,Community,Pending
```

## Independent_Registrations.csv

```text
RegistrationID,Alias,RegistrationDate,Category,Status
I01,Guest 01,2026-11-01,Community,Confirmed
I02,Guest 02,2026-11-02,Workplace,Confirmed
I03,Guest 03,2026-11-03,Community,Waitlisted
I04,Guest 04,2026-11-04,Workplace,Needs review
```

Independent_Registrations.csv above is the coding challenge only: I03 is Waitlisted and I04 Needs review. In the Excel independent case, I03 has a blank status and I04 is Cancelled. The similar filename is local to each exercise folder and does not make the records interchangeable.

## Baseline commands

```text
python app.py --db demo.sqlite3 init --capacity 12
python app.py --db demo.sqlite3 import-csv demo_registrations.csv
python app.py --db demo.sqlite3 summary
python app.py --db demo.sqlite3 list
```

Expected baseline: capacity 12; confirmed 8; available 4; total_records 11; statuses Confirmed 8, Waitlisted 1, Cancelled 1 and Needs review 1. Running summary as a new command reopens the saved file. Check the same absolute database location in both runs.

## Create a separate full-capacity scenario

```text
python app.py --db full.sqlite3 init --capacity 12
python app.py --db full.sqlite3 import-csv demo_registrations.csv
python app.py --db full.sqlite3 import-csv extra_confirmed.csv
python app.py --db full.sqlite3 summary
python app.py --db full.sqlite3 import-csv overflow_confirmed.csv
python app.py --db full.sqlite3 set-status --id R07 --status Confirmed
```

The last two commands must fail while full. Cancel R01 and then explicitly confirm R07 using the commands in Chapter 35. Expected final full-case statuses are Confirmed 12, Cancelled 2, Waitlisted 0 and Needs review 1; there are 15 records. The failed R16 import must not add a sixteenth record.

## Create a separate rollback scenario

```text
python app.py --db rollback.sqlite3 init --capacity 12
python app.py --db rollback.sqlite3 import-csv demo_registrations.csv
python app.py --db rollback.sqlite3 import-csv bad_import.csv
python app.py --db rollback.sqlite3 import-csv invalid_status.csv
python app.py --db rollback.sqlite3 summary
```

Both attempted imports must fail. The baseline must still have eleven records, with R01 named Guest 01 and no R20 or R21. The first new row in a failed multirow import must not survive. Record actual exit status and output rather than filling a log from these expected answers.

## Independent challenge setup

```text
python app.py --db i.db init --capacity 3
python app.py --db i.db import-csv Independent_Registrations.csv
```

To add I05 without adding an extra CLI feature, open the Python interactive interpreter from this same folder by typing python. Type the following lines. Press Enter on a blank line after the indented statement to finish the with block; then type exit() to return to the terminal.

## Add the independent record

```text
from registration import Store
with Store("i.db") as store:
    store.add("I05", "Guest 05", "2026-11-05",
              "Community", "Confirmed")
```

## Independent status checks

```text
python app.py --db i.db set-status --id I03 --status Confirmed
python app.py --db i.db set-status --id I02 --status Cancelled
python app.py --db i.db set-status --id I03 --status Confirmed
python app.py --db i.db summary
```

The first command must fail while full. The next two commands leave five records, three Confirmed, one Cancelled, one Needs review, no Waitlisted and zero available. Open summary again to check persistence.

## Complete registration test suite

Type the following test_registration.py beside registration.py. Run python -m unittest -v test_registration. Eight methods should pass. These tests create temporary databases and clean them up automatically. Separately run the CLI scenarios above: programmatic tests do not substitute for observing command handling.

## test_registration.py

```text
import csv
import sqlite3
import tempfile
import unittest
from pathlib import Path
from registration import FIELDS, Store


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.path = self.root / "case.sqlite3"
        Store.create(self.path, 2)

    def add(self, store, ident, status="Confirmed"):
        store.add(ident, "Guest", "2026-11-01", "Community",
                  status)

    def csv_file(self, rows):
        path = self.root / "input.csv"
```

```text
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(FIELDS)
            writer.writerows(rows)
        return path

    def test_persistence(self):
        with Store(self.path) as store:
            self.add(store, "R01")
        with Store(self.path) as store:
            self.assertEqual(store.summary()["confirmed"], 1)
            self.assertEqual(store.capacity, 2)

    def test_capacity_and_explicit_promotion(self):
        with Store(self.path) as store:
            self.add(store, "R01")
            self.add(store, "R02")
            self.add(store, "R03", "Waitlisted")
            with self.assertRaises(ValueError):
                store.set_status("R03", "Confirmed")
            self.assertEqual(store.summary()["total_records"], 3)
            store.set_status("R01", "Cancelled")
```

```text
            self.assertEqual(store.summary()["confirmed"], 1)
            self.assertEqual(store.rows()[2]["Status"], "Waitlisted")
            store.set_status("R03", "Confirmed")
            store.set_status("R03", "Confirmed")
            self.assertEqual(store.summary()["available"], 0)
            with self.assertRaises(ValueError):
                self.add(store, "R04")

    def test_duplicate_does_not_overwrite(self):
        with Store(self.path) as store:
            self.add(store, "R01")
            with self.assertRaises(sqlite3.IntegrityError):
                self.add(store, " r01 ")
            self.assertEqual(len(store.rows()), 1)

    def test_invalid_fields_and_unknown_labels(self):
        with Store(self.path) as store:
            cases = [("1A", "Guest", "2026-11-01", "Community",
                      "Confirmed"),
                     ("R01", "", "2026-11-01", "Community",
                      "Confirmed"),
                     ("R01", "Guest", "2026-02-30", "Community",
```

```text
                      "Confirmed"),
                     ("R01", "Guest", "2026-11-01", "Other",
                      "Confirmed"),
                     ("R01", "Guest", "2026-11-01", "Community",
                      "Pending")]
            for args in cases:
                with self.subTest(args=args):
                    with self.assertRaises(ValueError):
                        store.add(*args)
            self.assertEqual(store.rows(), [])

    def test_import_rolls_back_duplicate(self):
        with Store(self.path) as store:
            self.add(store, "R01")
            file = self.csv_file([
                ["R20", "New", "2026-11-01", "Community",
                 "Waitlisted"],
                ["R01", "Changed", "2026-11-01", "Community",
                 "Waitlisted"]])
            with self.assertRaises(sqlite3.IntegrityError):
                store.import_csv(file)
            self.assertEqual([r["RegistrationID"]
```

```text
                              for r in store.rows()], ["R01"])
            self.assertEqual(store.rows()[0]["Alias"], "Guest")

    def test_import_rolls_back_overflow(self):
        file = self.csv_file([
            [f"R{i:02}", "Guest", "2026-11-01", "Community",
             "Confirmed"] for i in range(1, 4)])
        with Store(self.path) as store:
            with self.assertRaises(ValueError):
                store.import_csv(file)
            self.assertEqual(store.rows(), [])

    def test_missing_and_existing_database(self):
        with self.assertRaises(FileExistsError):
            Store.create(self.path)
        missing = self.root / "missing.sqlite3"
        with self.assertRaises(sqlite3.OperationalError):
            Store(missing)
        self.assertFalse(missing.exists())

    def test_csv_schema_and_short_row(self):
        file = self.root / "bad.csv"
```

```text
        file.write_text("ID,Name\nR01,Guest\n", encoding="utf-8")
        with Store(self.path) as store:
            with self.assertRaises(ValueError):
                store.import_csv(file)
            file = self.csv_file([["R01", "Guest"]])
            with self.assertRaises(ValueError):
                store.import_csv(file)
            self.assertEqual(store.rows(), [])


if __name__ == "__main__":
    unittest.main()
```

The printed calculator and registration suites passed fourteen methods on Python 3.12.14 in the editorial check. The intentional test_buggy failure was reproduced separately, and baseline, full-capacity, rollback and independent CLI cases were run. Those observations apply to the printed reference listings. Your typed copy, operating system, editor and signed-in Copilot session still need your own checks.

## A7 Drawings and presentation and video records

## Make your own illustration

For Canva Chapter 18, create a blank 1200 by 800 pixel canvas in a basic drawing editor you can use, or draw on plain paper and photograph it. Use a pale background. Draw one large sheet as a slightly rotated rectangle and a smaller notebook beside it. Add a few short horizontal lines as decorative strokes, without letters. Draw two slim pencil shapes beside the paper, each with a triangular tip. Use dark outlines and optional navy and amber accents. Leave generous empty space. Save or export as Paper_and_Pencils.png. If drawing directly inside Canva, group the shapes; no SVG source is required.

For Runway Chapter 38, make a separate 1600 by 900 pixel landscape drawing or a landscape photograph of your own drawing. Use a light tabletop, one open notebook near the centre and exactly one yellow pencil to its right. Leave the top third uncluttered for later title layers. Keep every object inside the canvas. Save a PNG named Tabletop_Reference.png and inspect it before upload. Do not include people, logos, private writing, a real venue claim or event lettering. This image is an input you create; the book does not assume an unavailable PNG exists.

An editor with rectangles, lines and a polygon tool is enough. A hand drawing photographed evenly also works. Record your own authorship, date, method and any third-party material used. Use the chapter’s image-generation prompt only if you choose that available route. For Gemini Chapter 8, capture its actual printed labelled source drawings rather than substituting this tabletop image; the old version and time are part of that exercise’s evidence.

## Workshop_Costs.csv for Gamma

```text
Item,Quantity,UnitCost,LineTotal
Room,1,600,600
Materials,12,25,300
Printing,12,15,180
```

Create that CSV only if you choose an available upload route. Otherwise type the three rows into the presentation as a table. The total is 1080 and the budget remainder against 1500 is 420; the remainder is not an additional expense row.

## Video generation log

Create a paper or spreadsheet log with these fields: take name; objective; source image or Text to Video; full prompt; model; mode; ratio; requested duration; displayed charge; actual generated filename; observed duration; timestamped defect; next action; generation status. Use one row per attempt and keep prompt text in a separate wide cell or note. If you save CSV, name it Generation_Log.csv. Leave actual results blank or Not run until observed.

## Thirty second storyboard

| Edit slot | Visual and motion | Editable title |
| --- | --- | --- |
| 0 to 8 s | Paper planning tabletop; gentle page movement | Plan your first workshop |
| 8 to 16 s | Closer view of a blank planning page | Try a paper based activity |
| 16 to 24 s | Return to the same tabletop arrangement | For adult beginners |
| 24 to 30 s | Plain information card with no generated lettering | Full facts printed below |

The slots total thirty seconds. They are measured edit durations, not promised model output lengths. Keep the notebook, single pencil, background and lighting consistent. Use a source clip with sufficient usable duration or an explicitly labelled still-image hold. You may type this table into Storyboard_Worked.csv yourself; the printed table is the complete working example.

## Continuity checklist

Before joining shots, compare notebook shape, pencil count and colour, tabletop, direction of light and illustration style. Watch each cut, not just still frames. Reject a duplicated pencil, changing notebook, unwanted lettering or a distracting jump. Record the actual timestamp and decision. Keep original inputs and selected takes together; save the checklist as Continuity_Checklist.md only if useful.

## Exact promotion title text

Create editable title layers with the following content. Distribute it across earlier shots if the final card is crowded, while keeping all necessary facts visible. Test reading time on the actual export.

Plan Your First Workshop
21 November 2026
11 am to noon IST
Learning Room, Adyar, Chennai
For adult beginners
Free attendance
English paper based activity
Book via learn@example.com

The address is a practice placeholder. Do not publish it as a real event contact. Save this text as Promotion_Titles.txt yourself if your editor needs a text record. B0 remains the authority and there is no pre-generated video to retrieve.

## A8 Claude analysis inputs

## Deliberately flawed invitation for Chapter 41

Join Plan Your First Workshop on 21 November 2026 at 10 am, at Learning Room, Adyar, Chennai. The fee is INR 499. Certificates and lunch are included. Ten places are available. Bring your laptop. Book at learn@example.com.

This is the text called Invitation_With_Errors.txt. Type it exactly for the audit. The deliberate errors are 10 am, INR 499, certificates, lunch, ten places available and laptop requirement. B0 gives 11 am to noon, free attendance, no confirmed certificates or refreshments, no live availability and no phone or laptop needed. Keep this flawed draft separate from corrected copy.

## Complete registration records for Chapter 43

Use these eleven records only, with one person per row. You may type the table directly into Claude. To practise CSV upload, create Registrations.csv using the three-column header and rows below. Unlike A6, this is a small analysis table with no Alias, RegistrationDate or Seats field. Keep its column names exactly as shown.

| RegistrationID | Category | Status |
| --- | --- | --- |
| R01 | Community | Confirmed |
| R02 | Workplace | Confirmed |
| R03 | Community | Confirmed |
| R04 | Workplace | Cancelled |
| R05 | Community | Confirmed |
| R06 | Workplace | Confirmed |
| R07 | Community | Waitlisted |
| R08 | Workplace | Confirmed |
| R09 | Community | Confirmed |
| R10 | Workplace | Confirmed |
| R11 | Community | Needs review |

## Registrations.csv

```text
RegistrationID,Category,Status
R01,Community,Confirmed
R02,Workplace,Confirmed
R03,Community,Confirmed
R04,Workplace,Cancelled
R05,Community,Confirmed
R06,Workplace,Confirmed
R07,Community,Waitlisted
R08,Workplace,Confirmed
R09,Community,Confirmed
R10,Workplace,Confirmed
R11,Community,Needs review
```

## Complete feedback text

Type or save the following six lines as Feedback.txt. Keep comment IDs so a proposed theme can be traced to the original statement. These are fictional practice comments.

F01  Please make the printed text larger.

F02  I would like more time to practise the task.

F03  A one page recap would help me afterwards.

F04  Some of the printed instructions need clearer text.

F05  Please allow more hands on practice time.

F06  I would use a short recap sheet at home.

Check independently: eight Confirmed IDs are R01, R02, R03, R05, R06, R08, R09 and R10. R04 is Cancelled, R07 Waitlisted and R11 Needs review. Confirmed Community is R01, R03, R05 and R09; confirmed Workplace is R02, R06, R08 and R10. The four status counts reconcile to eleven. Against capacity twelve, four places remain available. F01 and F04 concern printed readability, F02 and F05 practice time, and F03 and F06 a recap. These comments do not represent a population survey.

## A9 Browser seat calculator

For Chapter 44, type the complete listing into a plain-text file named Seat_Calculator.html. Save as UTF-8 with All files selected if using Notepad. Double-click the saved file to open it in a browser. It has no network requests or storage. Use it as an answer reference after attempting your own Claude artifact. It does not reserve places.

## Seat_Calculator.html

```text
<!doctype html>
<html lang="en">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<title>Practice seat calculator</title>
<style>
body {font: 18px sans-serif; max-width: 32rem;
      margin: 2rem auto; padding: 1rem;}
label, input, button {display: block; margin: .7rem 0;}
input, button {font: inherit; padding: .4rem;}
</style>
<h1>Practice seat calculator</h1>
<p>This calculator does not reserve places.</p>
<form id="form" novalidate>
<label for="capacity">Capacity</label>
<input id="capacity" inputmode="numeric" value="12">
<label for="confirmed">Confirmed places</label>
<input id="confirmed" inputmode="numeric" value="8">
<button type="submit">Calculate</button>
<button type="reset">Reset</button>
</form>
<p id="result" role="status" aria-live="polite"></p>
```

```text
<script>
const form = document.getElementById('form');
const result = document.getElementById('result');
function whole(text) {
  if (!/^[0-9]+$/.test(text.trim())) {
    throw Error('Whole numbers only');
  }
  const value = Number(text.trim());
  if (!Number.isSafeInteger(value)) throw Error('Count too large');
  return value;
}
form.addEventListener('submit', event => {
  event.preventDefault();
  try {
    const capacity = whole(document.getElementById('capacity').value);
    const count = whole(document.getElementById('confirmed').value);
    if (capacity <= 0 || count > capacity) {
      throw Error('Use positive capacity covering confirmed places');
    }
    result.textContent = 'Available places: ' + (capacity - count);
  } catch (error) {
    result.textContent = 'Check inputs: ' + error.message;
```

```text
  }
});
form.addEventListener('reset', () => {result.textContent = '';});
</script>
</html>
```

Type 12 and 8 and choose Calculate: expect Available places: 4. Test 12 and 12 for zero, and 1 and 0 for one. Reject blank, 0 capacity, 13 confirmed against 12, negatives, decimals, letters, exponent notation and values beyond JavaScript’s safe-integer range. Use Reset: inputs return to 12 and 8 and the old result clears. Keyboard-test focus, labels, both buttons and result announcements in your own browser. Program logic checks do not establish that every browser or assistive technology behaves identically.

## A10 Worked operations example

This complete reference for Chapter 45 uses B0, B3 and B4 at capacity twelve. It is an answer guide after your attempt, not an approved event pack. Create your own document with these headings and preserve source versions. You can use Word; the filename Worked_Operations_Pack.md is optional and does not require Markdown software.

## Source map and summary

B0 governs event facts; B3 governs registration counting; B4 governs planning quantities and agenda. Appendix A8 supplies the eleven fictional registrations and six comments. The Chapter 44 calculator checks counts only. B2’s capacity-ten update is excluded. Review candidate version 1; approval Pending. The proposal is for a free, English, paper based workshop for adult beginners, with planned cost INR 1080 and unallocated budget INR 420. No actual booking, payment or release has been confirmed.

## Event fact sheet

Event: Plan Your First Workshop. Date: Saturday 21 November 2026. Time: 11 am to noon Indian Standard Time. Venue: Learning Room, Adyar, Chennai. Audience: adult beginners. Capacity: twelve. Fee: free. Printed materials are provided; no phone or laptop is needed. Contact: learn@example.com, a fictional practice address. Step-free access is confirmed only within the fictional brief; specific needs still require discussion. Certificates, refreshments, parking, transport and equipment loans are not confirmed.

## Invitation

Join Plan Your First Workshop on 21 November 2026, from 11 am to noon IST, at Learning Room, Adyar, Chennai. This free session is for adult beginners. Practise an English paper based activity with printed materials provided. No phone or laptop is needed. To book, email learn@example.com.

## Frequently asked questions

Who is it for? Adult beginners. What should I bring? The brief provides printed materials and does not require a phone or laptop. How do I book? Use the placeholder learn@example.com for this practice case. Does capacity twelve mean twelve places remain? No; capacity is the maximum and the fixture has eight confirmed records. Are certificates and lunch included? Neither is confirmed.

## Timed agenda

| Time IST | Activity | Minutes |
| --- | --- | --- |
| 11.00 to 11.05 | Welcome | 5 |
| 11.05 to 11.15 | Example | 10 |
| 11.15 to 11.30 | Guided practice | 15 |
| 11.30 to 11.45 | Independent practice | 15 |
| 11.45 to 11.55 | Review | 10 |
| 11.55 to noon | Close | 5 |

## Planning budget

| Item | Quantity | Unit INR | Line INR |
| --- | --- | --- | --- |
| Room | 1 | 600 | 600 |
| Materials | 12 | 25 | 300 |
| Printing | 12 | 15 | 180 |
| Total |  |  | 1080 |
| Limit |  |  | 1500 |
| Unallocated budget |  |  | 420 |

Budget quantities follow full capacity twelve, not the eight confirmed records. The remainder is neither profit nor actual cash collected. No ticket revenue is assumed because attendance is free. These are planning inputs, not supplier quotes or invoices.

## Registration and feedback briefing

The eleven practice records contain eight Confirmed, one Waitlisted, one Cancelled and one Needs review. Eight confirmed places against twelve leaves four available. Confirmed Community and Workplace each contain four records. R11 remains Needs review and cannot be silently promoted or deleted. Proposed improvements from the six comments are clearer printed text, protected practice time and a concise recap. These are proposals until adopted, not completed actions or findings about all participants.

## Calculator note and audit record

The local calculator takes whole-number capacity and confirmed counts. With twelve and eight it should show four; with twelve and twelve it should show zero; over-capacity input should produce an error. It neither reads the registration CSV nor makes bookings. Record the actual browser tests separately from the arithmetic checks.

Candidate version: 1. Source versions: B0, B3 and B4. Expected audit anchors: capacity 12; confirmed 8; available 4; agenda 60 minutes; planned cost INR 1080; remaining budget INR 420. Actual checks performed: enter your observations. Open real-world confirmations: organiser, usable contact, venue arrangements and permissions. Owner: record the actual person assigned; do not invent one. Reviewer status: Pending. Release: not performed.

## A11 Complete voice scripts

For Chapters 46 to 50, type only the spoken text into the generation tool. Section headings and production notes stay outside the speech input. Save the corresponding .txt file yourself only if helpful. These are scripts, not supplied recordings. B0 and B5 in the source bank govern the main example; a target duration must be checked against the actual audio.

## Main English script for Chapter 46

Join Plan Your First Workshop on the twenty first of November, twenty twenty six, from eleven a.m. to noon, Indian Standard Time, at Learning Room, Adyar, Chennai. This free session is for adult beginners. Practise planning an English language paper based activity. Printed materials are provided. No phone or laptop is needed. To book, email learn at example dot com.

Optional filename: Voiceover_Main_EN.txt. Compare every event fact with B0. Keep learn@example.com as the literal written address; learn at example dot com is a spoken test candidate. Check local place names by listening with someone who knows them.

## Three part English script for Chapter 48

Use the following three script parts in their printed order: Welcome, Activity and Booking. Keep each part separate when creating the practice audio so you can inspect pronunciation, pacing and transitions before assembling a complete version. The text is a teaching input; check the actual generated audio rather than treating the script alone as proof of a successful recording.

## Welcome

Welcome to Plan Your First Workshop, a free session for adult beginners.

## Activity

The activity is in English. Use printed materials to plan a simple learning activity. Work through an example, try your own plan, and review it with the group. No phone or laptop is needed.

## Booking

Join us on the twenty first of November, twenty twenty six, from eleven a.m. to noon, Indian Standard Time, at Learning Room, Adyar, Chennai. To book, email learn at example dot com.

Optional filename: Studio_Three_Parts_EN.txt. Welcome, Activity and Booking are production headings; do not speak them unless you deliberately choose to. For the revision exercise, replace only Activity with the following paragraph and preserve the other two parts.

You will use printed materials to plan a simple learning activity. Work through an example, try your own plan, and review it with the group. No phone or laptop is needed.

## Spanish practice draft for Chapter 49

Participa en Plan Your First Workshop, una sesión gratuita para adultos principiantes. Será el veintiuno de noviembre de dos mil veintiséis, de las once de la mañana hasta el mediodía, hora estándar de la India, en Learning Room, Adyar, Chennai. La actividad se realiza en inglés y utiliza materiales impresos. No necesitas teléfono ni ordenador portátil. Para reservar, escribe a learn@example.com.

Optional filename: Voiceover_ES_Draft.txt. This is a practice draft with proficient Spanish review Pending. The sentence La actividad se realiza en inglés preserves the English teaching language. Keep learn@example.com literal in written copy; the chapter’s learn arroba example punto com is only a spoken test candidate. Ask a listener to reconstruct the actual email from the audio and compare the spelling. Do not infer that language support equals natural translation or pronunciation approval.

## Short English promotion for Chapter 50

Join Plan Your First Workshop on the twenty first of November, twenty twenty six, from eleven a.m. to noon, Indian Standard Time. At Learning Room, Adyar, Chennai. Free for adult beginners. Practise an English language paper based activity. To book, email learn at example dot com.

Optional filename: Promotion_30s_EN.txt. This exact script has 46 whitespace-separated words. At an assumed 140 words per minute the planning estimate is 19.7 seconds before delivery variation and pauses. Measure the actual recording and compare it with the thirty-second edit. The script does not promise a fixed generated length.

## A12 Reusable practice records

These record layouts replace the previously named blank templates. Use a notebook, spreadsheet or plain-text document. Write the field labels before the first attempt. A blank or Not run result is more accurate than an invented pass. Local filenames are optional organisational choices.

## General practice log

Chapter and section; date; source ID and version; task; full prompt; tool and mode; output name; independent check; actual observation; correction; next action; status.

## Source and change log

Item; old version; new version; source authority; exact changed fact; old value; new value; affected documents; checked unchanged facts; actual check; reviewer; unresolved action. For Chapter 42, begin with capacity twelve and apply B2 to ten only in that exercise.

## Image asset record

Asset name; own drawing, library content or generated origin; author or tool; creation date; source and permission evidence; intended use; no venue or attendance claim; changes; actual content check; reviewer. Appendix A7 supplies the original-drawing route.

## Presentation rehearsal record

Deck version; card number; planned seconds; actual seconds; transition time; total; issue; revision; second actual timing. Use Chapter 25’s 35, 45, 50, 65 and 45 seconds as initial allowances only; they total 240 seconds.

## Video review record

Take; source; prompt; model; duration setting; displayed charge; actual filename; actual measured duration; timestamp; observed visual defect; edit range; selected or rejected; next action. Appendix A7 prints the full storyboard and continuity checks.

## Pronunciation review

Item or phrase; intended spoken form; script version; voice and model; test filename; actual timestamp; what the listener heard; revision; second observation; status; knowledgeable reviewer. Begin with Adyar, Chennai, the event date, IST and the email. Optional filename: Pronunciation_Review.csv.

## Localisation review

Source fact; English wording; target-language wording; literal names or email; reviewer question; text review status; audio review status; actual observation; required correction; current script and take versions. Optional filename: Localization_Review.csv. Keep translation approval separate from speech approval.

## Audio take and export record

Script version; language; voice or ID; model; actual settings; displayed charge; take filename; actual format and properties; measured duration; full playback; factual listening check; pronunciation review; edit joins; open defects; reviewer status.

## Final handover manifest

Current candidate; purpose; exact filename or document section; source ID and version; inputs created; actual checks; unresolved item; next owner; approval status; release status. Keep superseded candidates in a separate folder you create yourself. Create your own handover folder and README for your output; do not mistake a supplied resource README for evidence that you completed the exercise.

## When a chapter asks for a file

For briefs and text sources, type the printed passage and save only if the upload exercise needs a file. For a table, enter the printed cells. For Python or HTML, type the complete listing and run the printed checks. For an image, make or capture the specified drawing. For a generated clip or voice, create it in your own eligible account, then inspect the actual output. If access is unavailable, complete the printed planning and manual route, label generation Not run and keep the remaining practical task open.

No external teaching archive is required to understand the printed lessons. The optional 2027 Book 1 pack supplies matching digital files, while provider documentation links remain references for changing product features. See the reader resource instructions near the beginning.
