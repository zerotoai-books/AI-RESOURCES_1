# Chapter 15 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 15.3.2 Answer guide

A Plus and B meet the documented mandatory criteria in the supplied case. A Free fails CSV. C fails the record count. The unresolved practical checks apply to the eligible options and must be carried into the trial plan. Eligibility based on documents is not the same as final selection after testing.

## 15.4.2 Worked matrix

| Criterion | A Plus | B | C |
| --- | --- | --- | --- |
| Records | 100 [F2] | 100 [F4] | 20 [F5] |
| English and desktop | Yes [F2] | Yes [F4] | Yes [F5] |
| CSV export | Yes [F2] | Yes [F4] | Yes [F5] |
| No participant account | Yes [F2] | Yes [F4] | Yes [F5] |
| Organiser accounts | 1 [F2] | 2 [F4] | 1 [F5] |
| Three-month cost INR | 1200 [F3] | 1050 [F4] | 750 [F5] |
| Purchase term | Monthly [F3] | Three months upfront [F4] | Monthly [F5] |
| Document eligibility | Meets R0 | Meets R0 | Fails record count |
| Practical tests | Pending | Pending | Not selected for trial |

## 15.4.3 Answer guide

C fails despite leaving more budget unused. B has a lower documented three-month cost than A Plus but requires upfront purchase. That term is a real condition within the exercise, not a hidden detail to omit. Do not call B more reliable, easier or more accessible; the supplied evidence does not establish those qualities.

## 15.5 Exercise 3 Assemble the complete worked dossier

## 15.5.2 Worked dossier

Decision brief. Learning Circle needs one English desktop registration workspace for three consecutive months, with at least 24 records, CSV export and public form submission without participant accounts. One organiser is sufficient. The total purchase budget is INR 1200 including taxes. Payment collection is outside scope. [R0]

Evidence scope. The dossier was checked on 14 October 2026 IST. F1 is historical evidence of an introductory offer ending 31 August. F2 and F3 govern the current A features and price from 1 September. F4 and F5 describe B and C for the specified purchase period. The printed source IDs are recorded in the source log; these are fictional teaching documents.

Eligibility. A Plus and B meet the documented mandatory criteria. A Free does not export CSV under F2. C allows only 20 records, below R0's 24-record requirement. Neither the lower price of C nor the historical Free offer changes those failures. [F1, F2, F4, F5]

Cost. A Plus costs 400 × 3 = INR 1200. B costs 350 × 3 = INR 1050 paid upfront, leaving INR 150 within the cap. C costs 250 × 3 = INR 750 but is ineligible. The exercise prices include taxes and contain no other purchase costs. [R0, F3, F4, F5]

Recommendation. Trial B first because it meets the documented criteria at the lowest full-period cost among eligible options. Retain A Plus as an eligible alternative if B's workflow is unsuitable or its required conditions cannot be accepted. This is a proposed next step, not purchase authorisation.

Unresolved questions. Practical ease of use, accessibility and deletion timing are not established. The live purchase conditions must be rechecked before any real selection. A help button does not establish a support response time. [R0, F2, F4]

Trial plan. Vishva will use three clearly fictional registrations to test form submission without a participant account, inspect the stored records and export them to CSV. Shardha will compare the exported fields with the submitted records and review the workflow for the team's access needs. The team will obtain current written guidance about deletion and check the procedure. No real attendee data is required for these teaching tasks.

Decision record. Version 1 proposes B for a trial. Trial results, reviewer approval and purchase approval are pending. Save the date, tester, task, observed result and any error for each test. Record a later decision only after those results exist.

## 15.5.3 Check your work

The dossier preserves an alternative and the conditions that could change the recommendation. It keeps the source log and matrix as supporting sections rather than repeating every source paragraph inside the opening brief. Your version should have a comparable evidence trail even if you use different wording.

## 15.6.2 Worked trial record template

| Task | Expected result | Observed | Status |
| --- | --- | --- | --- |
| Form access | Submission without participant account | Not tested | Pending |
| Dummy entry | Three entries stored correctly | Not tested | Pending |
| CSV export | Values match submitted records | Not tested | Pending |
| Access review | Required tasks suit the team's needs | Not reviewed | Pending |
| Deletion check | Documented process and timing | Not established | Pending |

## 15.6.3 Answer guide

Three entries can help you test the workflow and export fidelity. They do not demonstrate storage of 24 or 100 records, performance under load or suitability for every accessibility need. Capacity remains a documented claim unless you test the relevant boundary. If the export changes a value, record the actual mismatch rather than simply marking export available.

## 15.7.2 Answer guide

At INR 400 per month, B costs INR 1200 for three months and ties A Plus on cost. Its upfront term still differs, so cost alone no longer favours B. At INR 450, B costs INR 1350 and exceeds the cap by INR 150; A Plus remains documented as eligible at INR 1200. With a requirement of 110 records, both A Plus and B fail their supplied 100-record caps, while C also fails. The evidence then supports no eligible option. Research another plan or revise the brief through an explicit decision; do not invent a higher capacity.

## 15.8.1 Answer guide

Y is the proposed trial candidate: two organisers, the required workflow and INR 900 for two months. X supplies only one organiser. Z requires INR 1200 for its three-month minimum. The choice could change if Y fails a required workflow test or R1's purchase terms change. Test record capacity and the two-organiser workflow. Usability, accessibility and deletion timing remain unestablished for all candidates.
