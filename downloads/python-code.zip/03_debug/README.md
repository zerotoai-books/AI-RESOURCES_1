# 03_debug

Printed reference recovered without code changes. Python 3.12 or later and the standard library. The review reran it on 3.12.14.

Run `python -m unittest -v test_buggy`. It must fail for the untouched negative example: 290 differs from expected 270. Make a separate learning copy and retest your repaired function. calculator_fixed.py is the printed minimal repair reference, not imported by test_fixed.py.

Keep the baseline unchanged and use a working copy. This is a local teaching example.
