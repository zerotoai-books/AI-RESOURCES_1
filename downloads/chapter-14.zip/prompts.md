# Chapter 14 Write an evidence based briefing

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 14.2.1 Your task
Word body block 2975

```text
Calculate the three-month cost of A Plus, B and C from the supplied price notes. Show multiplication, the total and the remaining amount within the INR 1200 R0 budget. Preserve B's upfront minimum term. Do not invent discounts or fees.
```

## 14.3.1 Your task
Word body block 2991

```text
Classify this briefing language as documented fact, interpretation, recommendation or unsupported claim. Use R0 and F4. Rewrite it so that no untested claim about usability appears as a fact.
```

## 14.4.1 Your task
Word body block 3001

```text
Using R0 and F1 to F5 only, draft a 250 to 350 word briefing for the fictional Learning Circle decision. Explain eligibility, calculate the complete three-month costs and recommend a trial rather than a purchase. Cite source IDs next to the relevant claims. Separate untested questions from established features.
```

## 14.5.1 Your task
Word body block 3020

```text
Audit the paragraph against R0, F2 and F4. Name each unsupported or misleading statement, identify the source and suggest a corrected sentence. Do not add a new benefit to compensate for removed claims.
```

## 14.6.1 Your task
Word body block 3031

```text
Draft a short handover note for the fictional briefing. List the files included, the unresolved checks and the next decision. Do not say the reviewer approved it unless the exercise provides an approval.
```
