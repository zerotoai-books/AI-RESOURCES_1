import csv
import sqlite3
import tempfile
import unittest
from pathlib import Path
from registration import FIELDS, Store


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.path = self.root / "case.sqlite3"
        Store.create(self.path, 2)

    def add(self, store, ident, status="Confirmed"):
        store.add(ident, "Guest", "2026-11-01", "Community",
                  status)

    def csv_file(self, rows):
        path = self.root / "input.csv"
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(FIELDS)
            writer.writerows(rows)
        return path

    def test_persistence(self):
        with Store(self.path) as store:
            self.add(store, "R01")
        with Store(self.path) as store:
            self.assertEqual(store.summary()["confirmed"], 1)
            self.assertEqual(store.capacity, 2)

    def test_capacity_and_explicit_promotion(self):
        with Store(self.path) as store:
            self.add(store, "R01")
            self.add(store, "R02")
            self.add(store, "R03", "Waitlisted")
            with self.assertRaises(ValueError):
                store.set_status("R03", "Confirmed")
            self.assertEqual(store.summary()["total_records"], 3)
            store.set_status("R01", "Cancelled")
            self.assertEqual(store.summary()["confirmed"], 1)
            self.assertEqual(store.rows()[2]["Status"], "Waitlisted")
            store.set_status("R03", "Confirmed")
            store.set_status("R03", "Confirmed")
            self.assertEqual(store.summary()["available"], 0)
            with self.assertRaises(ValueError):
                self.add(store, "R04")

    def test_duplicate_does_not_overwrite(self):
        with Store(self.path) as store:
            self.add(store, "R01")
            with self.assertRaises(sqlite3.IntegrityError):
                self.add(store, " r01 ")
            self.assertEqual(len(store.rows()), 1)

    def test_invalid_fields_and_unknown_labels(self):
        with Store(self.path) as store:
            cases = [("1A", "Guest", "2026-11-01", "Community",
                      "Confirmed"),
                     ("R01", "", "2026-11-01", "Community",
                      "Confirmed"),
                     ("R01", "Guest", "2026-02-30", "Community",
                      "Confirmed"),
                     ("R01", "Guest", "2026-11-01", "Other",
                      "Confirmed"),
                     ("R01", "Guest", "2026-11-01", "Community",
                      "Pending")]
            for args in cases:
                with self.subTest(args=args):
                    with self.assertRaises(ValueError):
                        store.add(*args)
            self.assertEqual(store.rows(), [])

    def test_import_rolls_back_duplicate(self):
        with Store(self.path) as store:
            self.add(store, "R01")
            file = self.csv_file([
                ["R20", "New", "2026-11-01", "Community",
                 "Waitlisted"],
                ["R01", "Changed", "2026-11-01", "Community",
                 "Waitlisted"]])
            with self.assertRaises(sqlite3.IntegrityError):
                store.import_csv(file)
            self.assertEqual([r["RegistrationID"]
                              for r in store.rows()], ["R01"])
            self.assertEqual(store.rows()[0]["Alias"], "Guest")

    def test_import_rolls_back_overflow(self):
        file = self.csv_file([
            [f"R{i:02}", "Guest", "2026-11-01", "Community",
             "Confirmed"] for i in range(1, 4)])
        with Store(self.path) as store:
            with self.assertRaises(ValueError):
                store.import_csv(file)
            self.assertEqual(store.rows(), [])

    def test_missing_and_existing_database(self):
        with self.assertRaises(FileExistsError):
            Store.create(self.path)
        missing = self.root / "missing.sqlite3"
        with self.assertRaises(sqlite3.OperationalError):
            Store(missing)
        self.assertFalse(missing.exists())

    def test_csv_schema_and_short_row(self):
        file = self.root / "bad.csv"
        file.write_text("ID,Name\nR01,Guest\n", encoding="utf-8")
        with Store(self.path) as store:
            with self.assertRaises(ValueError):
                store.import_csv(file)
            file = self.csv_file([["R01", "Guest"]])
            with self.assertRaises(ValueError):
                store.import_csv(file)
            self.assertEqual(store.rows(), [])


if __name__ == "__main__":
    unittest.main()
