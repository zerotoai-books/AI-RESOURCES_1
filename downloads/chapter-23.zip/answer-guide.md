# Chapter 23 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 23.1.2 Worked extraction

The proposal concerns a free workshop for adult beginners on Saturday 21 November 2026, from 11 am to noon IST, at Learning Room in Adyar, Chennai. Capacity is 12. The agenda contains six blocks totalling 60 minutes. Full-capacity estimates are INR 600 for the room, INR 300 for materials and INR 180 for printing. The proposed total is INR 1080 against a budget limit of INR 1500. Approval, actual expenditure and real supplier quotes remain unestablished.

## 23.1.3 Check your work

Keep the quantity and unit price even when the source already gives a total. They let you verify the arithmetic and update it later. Recording “materials 300” without the currency and quantity would make the revision in Chapter 25 harder to check.

## 23.2.2 Answer guide

The instruction authorises a new arrangement of the source, while keeping its meaning. It does not require preserving the source document's paragraph layout. If the import route loses a line or substitutes a font, correct the resulting deck and record the issue. Do not claim that a source was successfully imported merely because a file appeared in the upload list.

## 23.3 Exercise 3 Check the budget independently

## 23.3.2 Worked budget

| Item | Qty | Unit cost INR | Line total INR |
| --- | --- | --- | --- |
| Room | 1 | 600 | 600 |
| Materials | 12 | 25 | 300 |
| Printing | 12 | 15 | 180 |
| Planned total |  |  | 1080 |

The remaining budget is INR 1500 minus INR 1080, or INR 420. The workshop is free to attend, so the brief supplies no participant revenue. INR 420 is an unallocated part of the spending limit. It is not a profit calculation or a saving measured against actual costs.

## 23.3.3 Answer guide

A simple table is sufficient when the organiser needs exact amounts. A bar chart can compare the three cost components, but it should start at zero and keep the numbers linked to the supplied values. Do not add a fourth cost bar for the remaining budget. Use the three rows printed in Appendix A7 as Workshop_Costs.csv if an available upload route accepts it, or type the checked table directly. No Excel-file import is needed. [GREF3]

## 23.4.2 Worked agenda card

```text
One hour of practice
11.00 Welcome and choose an idea
11.05 Write a learning outcome
11.15 Calculate the supplied budget
11.30 Build a timed agenda
11.45 Review with a partner
11.55 Recap and next action
Finish at noon IST
```

## 23.4.3 Answer guide

The six blocks total 60 minutes. The time labels are start times, so the notes or source record should retain the corresponding durations. A draft ending at 12.15 pm extends the event and is wrong for this source. A shorter card may group the activities, but the checking sheet must still account for every block.

## 23.5.2 Worked checking sheet

| Claim to check | Source | Card | Expected content |
| --- | --- | --- | --- |
| Event date and time | G0 | 1 or 5 | 21 Nov 2026, 11 am to noon IST |
| Audience and activities | G0 | 2 | Adult beginners and three tasks |
| Agenda duration | G1 | 3 | Six blocks, 60 minutes |
| Planned cost | G1 | 4 | INR 1080 |
| Remaining budget | G1 | 4 | INR 420 |
| Decision status | G1 | 5 | Approval requested, pending |

## 23.5.3 Answer guide

These entries describe expected content, not a completed audit of your deck. Add your actual observation, status and correction in your own record. If Gamma places the event details on a different card, record that location rather than pretending it used this exact example. A source checking sheet should help someone find the evidence quickly.

## 23.6.1 Answer guide

The event runs from 3 pm to 4.30 pm IST. Eight paying attendees at INR 650 each would produce INR 5200 in potential fee revenue. The sources do not establish eight bookings or collected payments. They also supply no expenses, so profit is unknown. Keep those qualifications beside the financial claim.
