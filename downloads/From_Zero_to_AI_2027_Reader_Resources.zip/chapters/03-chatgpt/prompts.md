# Chapter 3 Work with documents and small datasets

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 3.6.1 Prompt to try
Word body block 821

```text
I am supplying Source A Workshop Brief v3 and Source B Ticket Sales Raw v1. Before analysis, identify which source contents you can read, list the dataset fields, and count the data rows excluding the header. State the reporting period. Do not summarize sales yet. If either source is unavailable or incomplete, say exactly what you need me to supply.
```

## 3.7.1 Prompt to try
Word body block 836

```text
Using Source A only, extract the event name, purpose, date, start and end times, time zone, venue, audience, fee, capacity, included materials, laptop requirement, booking contact, and team roles. Put each fact in a table with Fact, Value, and Source section. Add a separate list of missing information. Do not turn missing policies or event-day attendance into confirmed facts.
```

## 3.7.4 Make a targeted correction
Word body block 858

```text
Your evidence table says certificates are included, but Source A does not establish that. Remove the claim and record certificates as not supplied in A10. Recheck the rest of the table for benefits or policies that were not stated. Preserve the confirmed event facts.
```

## 3.8.1 Prompt to try
Word body block 869

```text
Review Source B before calculating sales. Report the raw row count, distinct OrderID count, exact duplicates, conflicting duplicate IDs, blank statuses, and any quantities or prices that cannot be read as numbers. Apply A8 only to exact duplicates. Propose a working-view treatment while preserving the raw source. Do not fill blank statuses or discard conflicting records.
```

## 3.9.1 Prompt to try
Word body block 883

```text
Using the documented working view and A7–A9, calculate distinct orders, tickets, and fee amounts by status. Show Paid, Pending, Cancelled, and Unresolved separately. Count D04 once and exclude D07 from totals. Report paid receipts, known active tickets, and unresolved tickets. Show the arithmetic and evidence rows. Do not describe pending amounts as collected income or publish an exact remaining-place count.
```

## 3.10.1 Prompt to try
Word body block 913

```text
Combine Source A, Source B, and the checked working-view rules into an evidence table. Use Claim, Evidence or calculation, and Type. Include the workshop schedule, fee, capacity, paid receipts, active tickets, duplicate handling, and unresolved status. Types should be Stated, Calculated, or Unresolved. Use A section and D row locators. Do not add outside information.
```

## 3.11.1 Prompt to try
Word body block 927

```text
Write a summary for Vishva using only the checked evidence table and the two sources. Keep it under 160 words. Cover the event schedule and venue, fee and capacity, reporting period, paid receipts, known active tickets, the excluded duplicate, and unresolved R010. Mention one practical next action. Distinguish collected fees from pending amounts. Do not claim that the workshop is full or add missing benefits.
```

## 3.11.4 Repair a defective summary
Word body block 941

```text
Review this draft sentence by sentence against the evidence table: “The workshop is full, 12 people have paid INR 5,988, and all attendees receive certificates.” For every claim, state whether it is supported, contradicted, or not supplied. Then write a corrected paragraph. Do not use the defective paragraph as a new source.
```

## 3.12 Make a source change without rewriting history
Word body block 945

```text
Approved update for this exercise: on 6 November 2026 Vishva confirms R010 is Cancelled. Create a revised evidence table and summary based on this decision. Preserve Raw v1, exclude D07 as before, and identify the update as Working View v2. Recalculate the affected status counts. Do not change the unit fee, paid receipts, or other orders.
```
