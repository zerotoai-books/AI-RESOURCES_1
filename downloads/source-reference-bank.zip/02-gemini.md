## Gemini

## Official references for the Gemini chapters

Product guidance was checked on 12 October 2026. The references support the Gemini access, file, privacy, and optional learning-tool instructions. The scenarios, source notes, illustrations, budgets, schedules, prompts, worked answers, and marking guides are teaching material created for this book. Follow the current official help if your account or interface differs.

1 Google  Use Gemini Apps
https://support.google.com/gemini/answer/13275745?hl=en
Official web app: https://gemini.google.com

2 Google  Upload and analyse files in Gemini Apps
https://support.google.com/gemini/answer/14903178?hl=en

3 Google  Gemini Apps Privacy Hub
https://support.google.com/gemini/answer/13594961?hl=en

4 Google  Use learning tools in Gemini Apps
https://support.google.com/gemini/answer/16448384?hl=en
