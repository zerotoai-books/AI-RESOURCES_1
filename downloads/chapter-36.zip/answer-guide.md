# Chapter 36 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 36.2.2 Worked answer guide

A suitable objective is to show an approachable paper based planning activity. A notebook and pencil can communicate preparation without implying that a real participant or venue has been filmed. Date, time, place and contact belong in the title list. A person using a laptop would contradict the intended no device message if presented as a requirement.

Check your work. Your objective should describe something observable. “Make it inspiring” is too vague to decide whether a result succeeds. Save the objective before testing any prompt.

## 36.3 Exercise 2 Check the generation route

Your task. Choose the mode deliberately. Text to Video creates the scene from a description. Image to Video starts from an image that already defines much of the visible scene.

## 36.3.2 Worked answer guide

The completed record might say Gen 4.5, Text to Video, five seconds, 16 by 9, with the charge copied from the actual account. Leave the cost blank until observed. Two attempts form a learning limit, not a promise of a particular credit price. If only an image input mode is offered, use the Chapter 38 route rather than pretending a text only prompt will run.

Check your work. A saved settings record prevents a later comparison from mixing models or durations. Do not subscribe or buy credits merely to complete the planning portion of this book.

## 36.4.2 Worked answer guide

The notebook is the subject, the table establishes the setting, and the page corner supplies the action. A still camera makes it easier to evaluate whether the page motion is usable. The scene does not claim to show the real Learning Room. No on screen words are requested, so the generation cannot silently become the authority for workshop facts.

Check your work. Check for conflicts such as “still camera” followed by “rapid orbit.” The prompt is an original teaching example; results will vary and may need revision.

## 36.5.2 Worked answer guide

A hypothetical review might read: “At about three seconds the pencil duplicates, so take A needs revision.” That is more useful than “Looks strange.” A successful clip would retain a recognisable notebook and one pencil while showing a small page movement. These are acceptance criteria, not a claim that the supplied prompt produced such a clip.

Check your work. Use Not observed for a check you have not performed. Keep a flawed take separately rather than overwriting the evidence that explains your next revision.

## 36.6.2 Worked answer guide

The folder should contain the prompt, settings, original take and review record. If generation was unavailable, it should instead contain a clearly labelled shot plan and a Not run log. A file extension alone does not establish resolution, frame rate or playback quality; inspect the downloaded file properties and the actual image.

Check your work. Do not label a planning document “finished video.” Preserve the editable notes so Chapter 37 can make a controlled comparison.

## 36.7.1 Answer guide after your attempt

One valid prompt is “Close shot of a camera on a plain table. Its loose fabric strap sways gently in a light breeze. Soft afternoon light. The camera view is still.” Criteria include one stable camera body, plausible strap motion and no invented branding or event lettering. Keep the Photography date, fee and device requirement in its own title brief. A good plan can be assessed without claiming a generated result.
