# Chapter 44 Build and test an interactive artifact

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 44.2.1 Useful prompt or direction
Word body block 5654

```text
Build a local seat calculator with labelled capacity and confirmed inputs and a Calculate button. Accept whole decimal counts only, capacity greater than zero and confirmed between zero and capacity. Reject blanks, fractions, negatives and over capacity values. Show available places only for valid input.
```

## 44.3.1 Useful prompt or direction
Word body block 5664

```text
Create the calculator as a single HTML artifact with CSS and JavaScript. Use no external libraries, network calls, storage or tracking. Include a reset button and an accessible result area. Label it as a practice calculator that does not reserve places. Keep the code readable.
```

## 44.4.1 Useful prompt or direction
Word body block 5674

```text
Test cases: 12 and 8 gives 4; 12 and 12 gives 0; 1 and 0 gives 1. For each, report the actual output and pass or fail. Do not mark a case passed solely because the code looks correct.
```

## 44.5.1 Useful prompt or direction
Word body block 5684

```text
Try capacity 0 with confirmed 0; 12 with 13; 12 with -1; 12 with 1.5; a blank field; and letters. Each must be rejected. Then enter 12 and 8 and confirm recovery to 4. Reset should restore the reference defaults and clear the result.
```

## 44.6.1 Useful prompt or direction
Word body block 5694

```text
Handover note: This local calculator subtracts confirmed places from capacity after input validation. It does not book, store or synchronise places. Version ___; tested cases ___; browser ___; outstanding checks ___; approval Pending.
```
