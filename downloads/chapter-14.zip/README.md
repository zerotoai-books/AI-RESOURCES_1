# Chapter 14 Write an evidence based briefing

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 14.2.1 Your task

Step 1  Read the current price and purchase-term statements in F3 to F5.

Step 2  Calculate the full three-month amount payable for each option.

Step 3  Subtract each amount from INR 1200 while preserving upfront commitments.

Step 4  Keep feature eligibility beside cost so that a cheaper ineligible option is not selected.



## 14.3.1 Your task

Step 1  Read F4 and R0 again.

Step 2  Identify factual statements and comparisons.

Step 3  Mark untested quality claims.

Step 4  Rewrite the paragraph without the unsupported sentence.



## 14.4.1 Your task

Step 1  Gather the checked eligibility result, costs, source log and open questions.

Step 2  Draft 250 to 350 words with a dated scope and source IDs beside claims.

Step 3  Recommend a trial with conditions rather than implying a completed test or purchase.

Step 4  Check the facts and word count, then inspect the one-page layout at readable type size.



## 14.5.1 Your task

Step 1  Recalculate the full purchase cost.

Step 2  Separate capacity from actual registrations.

Step 3  Check whether accessibility has been tested.

Step 4  Check how many organiser accounts R0 needs.

Step 5  Save the original and the correction.



## 14.6.1 Your task

Step 1  Name the briefing version and date.

Step 2  Include the source files or full live URLs, as appropriate.

Step 3  List outstanding questions and owners.

Step 4  State that selection depends on the planned tests.

Step 5  Save the reviewed version separately from the draft.

