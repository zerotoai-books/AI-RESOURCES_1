# Chapter 31 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 31.1.2 Answer guide

A correct explanation keeps the editor, language runtime and assistant distinct. An AI response saying that a program will print four is a prediction. Output from your interpreter is execution evidence. Save both when comparing the explanation with the result.

If your VS Code version offers several session targets, choose Copilot for these exercises. Current VS Code documentation distinguishes the target running the session from its available roles. In the Copilot target, Ask uses read-only tools; Agent can implement changes and validate them. [GH3] Select Ask for the first explanation when it is available. A sentence asking for an explanation does not itself change an editing session's permissions.

Open the Chat view using its editor control, start a new chat, and inspect the session target before sending the prompt. Choose the question or editing role deliberately. Controls can differ by version; use the linked current setup guide if your screen differs.

If Copilot is unavailable, you can complete the code-reading and manual checks. Record that route rather than claiming to have used an unavailable feature. Nothing in the Python example requires you to create a remote GitHub repository.

## 31.2.2 Worked output

```text
Available seats: 4
```

## 31.2.3 Answer guide

Twelve minus eight equals four. If Python reports that it cannot find the file, inspect the current folder and filename. If the shell cannot find Python, check the interpreter installation and command. Neither message is evidence of an arithmetic problem in the function.

When diagnosing a setup error, provide the command and relevant error text. Do not paste passwords, tokens or private project files into a debugging conversation. These exercises need only the fictional practice files.

## 31.3.2 Worked explanation

The program calls available_seats with twelve and eight. Both values must be whole-number counts; capacity must be positive and confirmed places nonnegative. The function also rejects confirmed places above capacity. With valid inputs, it returns twelve minus eight. main stores four and prints it. The __name__ guard calls main when the file is run directly, while allowing another file to import the function without printing the demonstration automatically.

## 31.3.3 Check your work

The reference uses an exact integer type check, so True is rejected even though Python treats bool as a subclass of int. You do not need to memorise that language detail yet. You do need to notice that a friendly-looking value can have the wrong type. Ask for an explanation of any condition you cannot relate to the input rule.

## 31.4.2 Worked change results

Nine confirmed places leave three available. Thirteen confirmed places cause the reference function to raise ValueError, because the first example defines over-capacity bookings as an error. It should not print negative one as a normal available-seat result. Returning to eight restores four.

An unhandled exception in this small teaching program may print a traceback. It shows where the program stopped. Chapter 32 will give command-line users a clearer input error, while Chapter 33 will use a failing example to practise diagnosis. Do not remove a validation check merely because its message interrupts a run.

## 31.5.2 Worked review note

The intended revision changes the demonstration's confirmed input from eight to nine. The calculation and validation stay the same. Expected output changes from four available seats to three. The saved terminal results should establish whether the two versions actually produced those values. The final baseline should again use twelve and eight.

## 31.6.1 Answer guide

Available places are three. The waiting list does not reduce that figure under K0. A negative confirmed count must be rejected. Your log should distinguish the valid output from the invalid-input exception and show that you restored the intended version.
