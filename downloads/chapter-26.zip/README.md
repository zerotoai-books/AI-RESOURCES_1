# Chapter 26 Prepare a workbook and ask a data question

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 26.2.1 Your task

Step 1  Build the workbook using Appendix A1, then save a separate working copy.

Step 2  Open Registrations and read the five column headers.

Step 3  Check that dates and Seats are typed values, rather than decorative text.

Step 4  Confirm that every row has a unique RegistrationID.

Step 5  Read E0's definition of Confirmed, Waitlisted and Cancelled.



## 26.3.1 Your task

Step 1  Select a cell in the data and inspect the table controls.

Step 2  Confirm the table name RegistrationTable.

Step 3  Check that the header row is recognised correctly.

Step 4  Confirm that the table contains all ten records and no total row counted as data.

Step 5  Keep merged headings and commentary outside the table.



## 26.4.1 Your task

Step 1  Choose chat mode when available.

Step 2  Name RegistrationTable and the relevant columns.

Step 3  State that Waitlisted and Cancelled are excluded.

Step 4  Ask for the records supporting the answer.

Step 5  Compare the response with the table before accepting it.



## 26.5.1 Your task

Step 1  Enter a label such as Confirmed seats.

Step 2  Enter the SUMIFS formula below in the neighbouring cell.

Step 3  Confirm that it returns eight.

Step 4  Filter the table to Confirmed and inspect the matching IDs.

Step 5  Clear the filter when finished so later exercises begin from the full table.



## 26.6.1 Your task

Step 1  State the source and current sample size.

Step 2  State eight confirmed seats against capacity 12.

Step 3  Calculate the four seats not yet allocated to confirmed records.

Step 4  Keep the cancelled and waitlisted records distinct.

Step 5  Record any check you did not perform.

