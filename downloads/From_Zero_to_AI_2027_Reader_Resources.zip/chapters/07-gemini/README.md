# Chapter 7 Develop ideas into a workable outline

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 7.3 Exercise 1 Turn the brief into clear requirements

Step 1  Paste the complete brief and core cost table into a new chat.

Step 2  Ask Gemini to extract requirements using the prompt below.

Step 3  Compare every item with the brief.

Step 4  Move guessed details into a separate suggestions list or remove them.

Step 5  Save the checked requirements before asking for ideas.



## 7.4 Exercise 2 Generate a useful range of ideas

Step 1  Continue in the chat containing the full brief.

Step 2  Ask for six ideas with the same fields for each.

Step 3  Check that the ideas contain an action learners could complete.

Step 4  Keep proposals labelled as suggestions.

Step 5  Mark a concept for rejection if it depends on a prohibited device or unaffordable extra.



## 7.5 Exercise 3 Remove ideas that fail the brief

Step 1  Calculate the core budget yourself.

Step 2  Add only the extras a concept actually requires.

Step 3  Test duration, audience, capacity, and device rules as well as cost.

Step 4  Ask Gemini for the same comparison.

Step 5  Resolve any disagreement by returning to the source, not by averaging the answers.



## 7.6 Exercise 4 Develop the selected concept into an outline

Step 1  State the selected concept explicitly in the chat.

Step 2  Ask for an outline rather than a finished invitation.

Step 3  Check that learners have enough time to practise.

Step 4  Add the minutes independently.

Step 5  Keep unresolved arrangements labelled as unresolved.



## 7.7 Exercise 5 Test proposed changes before accepting them

Step 1  Inspect each proposed change independently.

Step 2  Recalculate the budget for refreshments and for the larger print quantity.

Step 3  Check capacity and evidence separately from price.

Step 4  Ask Gemini for a review using the prompt below.

Step 5  Save an accepted or rejected decision with its reason.



## 7.8 Exercise 6 Write a decision record someone else can review

Step 1  Gather the checked outputs from Exercises 1–5.

Step 2  Ask Gemini to draft a decision note using the prompt below.

Step 3  Read it as though you were Shardha reviewing the proposal.

Step 4  Remove claims of confirmed bookings or venue approval.

Step 5  Save the note with the brief version and alternatives considered.



## 7.11 Check your understanding

Step 1  Why should you apply hard requirements before preference scores?

Step 2  What is the community project’s core planned total?

Step 3  Why does the 20-attendee suggestion fail even though its print calculation fits the cap?

Step 4  What does a tie in the preference scores tell you?

Step 5  Which arrangements must remain open in the decision note?



## 7.11.1 Answer guide

Step 1  An idea must meet the brief before you compare its relative appeal.

Step 2  INR 2140, including printed learner packs and reserve.

Step 3  It exceeds the supplied capacity of 12.

Step 4  More than one option can be suitable; the audience’s actual need should guide the choice.

Step 5  Room booking, access, equipment, any fee decision, and the actual registration count are not confirmed.

