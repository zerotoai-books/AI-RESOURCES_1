# Chapter 12 Narrow a research question

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 12.3.1 Your task
Word body block 2779

```text
Rewrite this broad question into a decision question using R0 only: What is the best registration tool? Do not recommend an option yet. Include the mandatory requirements, the total purchase period and the budget. Mark anything R0 does not establish as unknown.
```

## 12.4.1 Your task
Word body block 2787

```text
What can Canva do?
```

## 12.4.1 Your task
Word body block 2788

```text
As of the date I am researching, does Canva's current official help list Canva Free as eligible for Magic Resize? Focus on changing an existing design's dimensions. Link the official resize help page, distinguish eligibility from a manual alternative and do not recommend a subscription.
```

## 12.5.1 Your task
Word body block 2805

```text
Using R0, separate mandatory requirements from proposed preferences. Do not treat an untested preference as an established feature. For each proposed preference, state how I could test it.
```

## 12.6.1 Your task
Word body block 2825

```text
Research Options A, B and C against the same R0 requirements. Show which claims each supplied source supports. Do not assume B will win. State any missing evidence and give a condition that could change the recommendation.
```

## 12.7.1 Your task
Word body block 2838

```text
Draft a stopping rule for the R0 comparison. Research may stop when each mandatory criterion has supporting evidence or is explicitly unresolved, current costs are calculated for the full period and every unresolved issue has a next action. Do not confuse research completion with purchase approval.
```
