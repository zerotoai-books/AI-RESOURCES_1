# Chapter 30 Build a budget and registration tracker

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 30.1.1 Your task

Step 1  Create a Tracker sheet as the main view.

Step 2  Put each input in the cells specified below.

Step 3  Keep the cleaned table named CleanRegistrationTable.

Step 4  Preserve the original raw records on RawRegistrations.

Step 5  Write down which results must change when an input changes.



## 30.2.1 Your task

Step 1  Calculate the room, materials and printing lines.

Step 2  Confirm that every line total is numeric before displaying a total.

Step 3  Calculate remaining budget from the limit and complete total.

Step 4  Separate available seats from seats over capacity.

Step 5  Guard the capacity percentage against missing or invalid capacity.



## 30.3.1 Your task

Step 1  Allow whole-number capacity from one to forty for this exercise.

Step 2  Allow nonnegative numeric budget and prices, including genuine zero.

Step 3  Use the approved Category and Status dropdown values.

Step 4  Keep one seat per registration under E0's record rule.

Step 5  Highlight unresolved records, repeated IDs, over-capacity seats and negative budget remainder.



## 30.4.1 Your task

Step 1  Test a materials price of INR 30.

Step 2  Test capacity ten and then restore twelve.

Step 3  Change R07 to Confirmed and check the category chart.

Step 4  Test a lower budget, a missing price and a genuine zero price.

Step 5  Test an invalid capacity and a duplicate registration.



## 30.5.1 Your task

Step 1  Restore capacity 12 and all baseline prices and statuses.

Step 2  Open the saved workbook and check formulas, chart and validation.

Step 3  Record the tests performed and any remaining limitation.

Step 4  Keep R11's unresolved status visible.

Step 5  Add the reviewer status and initials only when a review is actually recorded.

