# Chapter 13 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 13.3.2 Worked comparison

| ID | Published | Scope | Appropriate use |
| --- | --- | --- | --- |
| F1 | 1 Jun 2026 | Introductory Free offer ending 31 Aug | Explain the old CSV claim |
| F2 | 20 Sep 2026 | Free and Plus from 1 Sep | Current A features |
| F3 | 21 Sep 2026 | Plus from 1 Sep | Current A price |
| F4 | 25 Sep 2026 | B for this three-month case | B features and purchase term |
| F5 | 26 Sep 2026 | C for this three-month case | C features and record cap |

## 13.3.3 Answer guide

F2 cannot establish Option A's price because it explicitly does not supply a price. F3 cannot establish usability. F1 can explain what was offered during the introduction, but it cannot establish the Free plan after the offer expired. Keep these limits attached to the source log.

## 13.4.2 Worked resolution

```text
F1 described an introductory Free-plan offer that ended on 31 August 2026. F2 governs the exercise from 1 September and says CSV export requires Plus. For the 14 October decision, Free does not meet R0's CSV requirement. F1 remains useful as historical evidence, but it does not describe the current Free plan. A real decision would also require a test of the selected plan's actual export workflow.
```

## 13.4.3 Answer guide

The disagreement is resolved by effective period and plan scope. It is not resolved merely by preferring the newest publication. A newer document about an unrelated plan would not override the relevant source. The dates matter because the documents directly cover consecutive periods of the same feature.

## 13.5.2 Answer guide

| Claim | Result | Evidence |
| --- | --- | --- |
| A Free exports CSV | Contradicted | F2 explicitly excludes CSV from Free |
| B deletes data within seven days | Unresolved | F4 does not give deletion timing |
| C supports 24 records | Contradicted | F5 supplies a limit of 20 |
| A Plus includes one organiser | Supported | F2 states one organiser account |

For B, the next question is: “What deletion process and timing apply to this workspace?” A source that says nothing about deletion cannot prove either a seven-day promise or a lack of deletion capability. This distinction prevents your table from looking more certain than the evidence allows.

## 13.6.2 Worked result

On the official page checked on 14 October 2026 IST, Canva Free is not in the Magic Resize eligible-plan list. [P6] For this book's design exercises, a learner without the feature can start another design at the required dimensions, copy usable elements and rebuild the layout. That teaching alternative does not change the plan eligibility finding.

## 13.6.3 Check your work

If your account offers a feature that appears inconsistent with the page, record both observations and ask the service to clarify the scope. Do not generalise from a trial, promotion or workspace to every Free account. Use the result you can document.

## 13.7.2 Worked action record

| Question | Owner | Next action |
| --- | --- | --- |
| Can the organiser complete the workflow? | Vishva | Trial entry and CSV export with dummy records |
| Does it suit the team's access needs? | Shardha | Check the actual tasks and relevant accessibility guidance |
| What is the deletion process and timing? | Vishva | Obtain current written guidance and test the procedure |
| Is the required price and term still offered? | Shardha | Recheck the current purchase information before selection |

## 13.7.3 Answer guide

A question is unfinished if it says only “check later.” State what someone will check and what evidence they will save. Do not claim that these actions have already happened. A future trial belongs in the action record until there is an actual result.

## 13.8.1 Answer guide

The current supplied limit is six files per day because G2 governs the period after 1 October. G1 remains a record of the earlier trial. A team-wide limit is unresolved; a per-user limit cannot establish it. Do not multiply by the number of team members without evidence that the limits operate independently.
