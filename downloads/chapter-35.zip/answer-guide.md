# Chapter 35 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 35.1.2 Worked design

app.py reads an operation and displays its result. registration.py validates values and stores them through a Store object. The printed database implementation stores capacity and schema version in settings, with RegistrationID as the registrations primary key. The printed tests use temporary databases so they do not change a learner’s saved project.

The approved statuses are Confirmed, Waitlisted, Cancelled and Needs review. Only Confirmed uses capacity. A cancellation frees a place but does not automatically choose someone to promote. An explicit set-status operation records that separate fictional operator decision.

## 35.1.3 Answer guide

Duplicate handling must be defined before implementation. R01, r01 and a value with surrounding spaces represent the same normalised key. Reject a second record with that key and preserve the original. Silently replacing Guest 01 would lose information even if the total row count stayed unchanged.

## 35.2.2 Worked summary

```text
{
  "capacity": 12,
  "confirmed": 8,
  "available": 4,
  "total_records": 11,
  "statuses": {
    "Confirmed": 8,
    "Waitlisted": 1,
    "Cancelled": 1,
    "Needs review": 1
  }
}
```

## 35.2.3 Answer guide

Each command starts a new Python process, so the later summary reads saved records rather than the earlier process's local variables. SQLite supplies the file-backed storage interface. [PY4] Check the path as well as the counts: a different working folder with the same relative filename could refer to another database.

The app deliberately rejects init if the file already exists. Choose a new filename for a fresh exercise instead of expecting init to reset a database. It also refuses to silently create a database when list or summary is pointed at a missing file. In the supplied interface, --db belongs before the subcommand.

## 35.3.2 Worked change results

Adding R12 through R15 raises confirmed seats from eight to twelve, leaving zero available. There are now fifteen total records. R16 is rejected, and R07 remains Waitlisted when its promotion is attempted at full capacity.

Cancelling R01 reduces confirmed seats to eleven and makes one place available. It leaves R07 Waitlisted. Explicitly confirming R07 then returns the count to twelve. The final fifteen records comprise twelve Confirmed, two Cancelled, zero Waitlisted and one Needs review. R11 remains visible throughout.

## 35.3.3 Answer guide

The duplicate and capacity rules must apply to every relevant path, including an import and a status update. A form that rejects an over-capacity addition but allows an unchecked promotion would leave a hole in the rule. The reference also allows an existing Confirmed record to remain Confirmed at full capacity; that operation does not reserve a second seat.

Use the help for the add command to inspect its required fields. A short Python example of the same storage operation is:

```text
from registration import Store
```

```text
with Store("demo.sqlite3") as store:
    store.add("R12", "Guest 12", "2026-11-12",
              "Community", "Confirmed")
```

Run this only on a separate baseline copy, since adding R12 again must be rejected. The example demonstrates one record; it is not part of restoring the baseline after the full-capacity test.

## 35.4.2 Worked result and explanation

bad_import.csv is rejected when R01 is encountered. The earlier new R20 from that same import must also disappear through rollback. The original eleven records remain, with Guest 01 unchanged. invalid_status.csv uses Pending, which is not an approved status, and must also be rejected without adding a record.

The reference groups the capacity check and write in an explicit transaction. It uses parameter binding, such as passing a key separately from a query containing a question-mark placeholder. Python's SQLite documentation explains this separation of SQL text and data. [PY4] An alias containing an apostrophe should remain a data value rather than break the query.

## 35.4.3 Answer guide

The printed registration suite in Appendix A6 runs eight test methods covering saved capacity, reopening, duplicates, input validation, capacity, explicit promotion, CSV rollback and missing databases. Run it yourself with python -m unittest -v test_registration. Separately run the Chapter 35 command-line scenarios with the printed CSVs; the method count does not cover every possible application behaviour.

In the reference interface, ordinary input rejection returns exit code two. A storage failure returns three. Argument errors also fail rather than silently starting the application with guessed values. Record the relevant message and confirm the database state, rather than relying on an exit code alone.

## 35.5.2 Worked handover note

The prototype stores fictional one-seat registrations in a local SQLite file. Its baseline uses capacity twelve and eleven records, including eight confirmed places and R11 marked Needs review. The original CSV remains available for creating a fresh baseline. Reinitialising an existing file is refused. Duplicate IDs, invalid labels and capacity overflow are rejected, while a failed multirow import rolls back its new rows. Record the actual test run and reopen observations before completing the handover review.

## 35.5.3 Answer guide

This edition’s printed calculator and registration suites contain fourteen passing test methods in total; the separate debugging starter deliberately fails. Code checks were performed on Python 3.12.14. Record your own actual results, editor checks and signed-in Copilot observations separately. There is no root archive runner to download.

## 35.6.1 Answer guide

The initial four records have two confirmed places and one available. Adding I05 fills the third place. Promotion of I03 is rejected while full. Cancelling I02 frees a place but leaves I03 Waitlisted. After the explicit promotion, five records comprise three Confirmed, one Cancelled, one Needs review and zero Waitlisted. Available seats are zero. The unresolved I04 remains in the saved data.
