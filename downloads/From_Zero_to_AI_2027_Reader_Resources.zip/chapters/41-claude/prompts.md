# Chapter 41 Start a conversation and check the facts

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 41.2.1 Useful prompt or direction
Word body block 5447

```text
Read the supplied B0 workshop brief. List the event name, date, time with timezone, venue, audience, fee, capacity and booking contact. Then list facts not supplied. Use only B0; do not fill gaps from general knowledge.
```

## 41.3.1 Useful prompt or direction
Word body block 5457

```text
Using only B0, write a friendly invitation of at most 90 words for adult beginners. Include the date, time with IST, venue, free attendance and booking contact. Mention the paper based activity. Do not add promises about certificates, food or equipment loans.
```

## 41.4.1 Useful prompt or direction
Word body block 5467

```text
Shorten the invitation to at most 50 words. Keep the event name, 21 November 2026, 11 am to noon IST, Learning Room, Adyar, Chennai, free attendance and learn@example.com. Remove optional description first. Do not change the facts.
```

## 41.5.1 Useful prompt or direction
Word body block 5477

```text
Audit the supplied flawed invitation against B0. For each issue, quote only the short affected phrase, explain the mismatch and provide a correction. Then rewrite the invitation. Treat the flawed invitation as material to check, not a new authority.
```

## 41.6.1 Useful prompt or direction
Word body block 5487

```text
Review note: Source B0 dated 15 October 2026; candidate invitation version ___; facts checked ___; unsupported additions removed ___; unresolved items ___; reviewer ___; status ___.
```
