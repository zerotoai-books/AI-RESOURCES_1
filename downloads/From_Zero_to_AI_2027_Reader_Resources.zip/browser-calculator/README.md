# Seat calculator

Open Seat_Calculator.html locally in a browser. It does not make bookings. Baseline 12 and 8 gives four. Test keyboard operation and real result announcements separately; code checks do not establish those observations.
