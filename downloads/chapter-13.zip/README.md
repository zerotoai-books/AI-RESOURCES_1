# Chapter 13 Compare evidence and resolve disagreement

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 13.3.1 Your task

Step 1  Record the printed source ID and heading.

Step 2  Record publication and effective dates separately.

Step 3  Note the relevant plan or option.

Step 4  Summarise only claims contained in the source.

Step 5  Record the date you inspected the file.



## 13.4.1 Your task

Step 1  State the current claim and decision date.

Step 2  Compare the introductory end date with the current date.

Step 3  Identify the current guide and its effective date.

Step 4  Write a resolution in no more than 100 words.

Step 5  Add a next action for a real product decision.



## 13.5.1 Your task

Step 1  Locate the source for each claim.

Step 2  Use contradicted only when the source establishes the opposite.

Step 3  Use unresolved when the source does not answer the question.

Step 4  Add a precise question for each unresolved item.



## 13.6.1 Your task

Step 1  Save the answer and inspect the citation.

Step 2  Locate the eligibility section on the actual page.

Step 3  Record the feature's exact name and scope.

Step 4  Write a dated result and a manual alternative.



## 13.7.1 Your task

Step 1  Read R0 and the current F2 to F5 sources.

Step 2  List questions the sources do not settle separately from established features.

Step 3  Assign a proposed owner and a specific evidence-gathering action to each question.

Step 4  State what evidence will be saved and keep unperformed checks Pending.

