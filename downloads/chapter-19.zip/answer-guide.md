# Chapter 19 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 19.2.2 Answer guide

Each version must identify the event and tell the reader when, where and how to act. You can move additional learning details to a caption or handout section, but do not describe a post as standalone if the date or registration instruction exists only somewhere else.

## 19.3.2 Worked square copy

```text
Plan Your First Workshop
For adult beginners
```

```text
Saturday 21 November 2026
10.30 am to 11.30 am IST
Learning Room, Adyar, Chennai
```

```text
Free to attend | Capacity 12
No phone or laptop needed
Register: learn@example.com
```

```text
Fictional practice event
```

## 19.3.3 Answer guide

This copy retains the standalone event facts. English delivery and included printed materials can appear in the accompanying caption. Do not imply that omitting a detail from one graphic cancels the underlying brief; check the complete set of graphic and caption together.

## 19.4.2 Worked story structure

The top group identifies Plan Your First Workshop and its beginner audience. The middle group carries Saturday 21 November 2026, 10.30 am to 11.30 am IST and Learning Room, Adyar, Chennai. Below it, place free attendance, capacity 12, English and included printed practice materials. The last main group gives learn@example.com and the no-device requirement. Keep the small fictional-practice footer distinct from the action.

## 19.4.3 Check your work

The vertical version should not merely be the square version stretched taller. Preserve proportions and rearrange elements. If a picture becomes distorted, undo the stretch and resize it proportionally or crop it deliberately.

## 19.5.2 Worked handout content

```text
Plan Your First Workshop
Saturday 21 November 2026 | 10.30 am to 11.30 am IST
Learning Room, Adyar, Chennai
```

```text
This practical session is for adult beginners. We will practise writing a learning outcome, calculating a supplied budget and building a timed agenda. The session is in English, uses paper activities and includes printed practice materials. No phone or laptop is needed.
```

```text
Attendance is free and capacity is 12. To register, email learn@example.com. Step-free access is confirmed within this fictional exercise; contact the organiser about specific access needs.
```

```text
No certificate, refreshments, parking or equipment loan is promised.
```

```text
Fictional practice event. The contact address is a placeholder.
```

## 19.5.3 Answer guide

A physical proof can reveal small text or colour problems that a zoomed screen hides. If you cannot print, record that physical proofing is pending; a screen inspection does not become a print test. Do not mark the handout ready for a specific printer before its specifications have been confirmed.

## 19.6.2 Worked consistency record

| Field | Square | Story | Handout |
| --- | --- | --- | --- |
| Event and date | Compare with C0 | Compare with C0 | Compare with C0 |
| Time and IST | Compare with C0 | Compare with C0 | Compare with C0 |
| Venue | Compare with C0 | Compare with C0 | Compare with C0 |
| Contact | Compare letter by letter | Compare letter by letter | Compare letter by letter |
| Export readability | Inspect actual file | Inspect actual file | Inspect PDF and proof |

## 19.6.3 Answer guide

This is an unfilled checking template. Your final record should contain actual results or pending items. Matching filenames do not prove matching content. Open every exported file and check it against the authoritative brief.

## 19.7.1 Answer guide

All versions must preserve 28 November 2026, 3 pm to 4.30 pm IST, Studio Room, Kochi, capacity eight, INR 650 per person and photos@example.com. The camera or camera-phone requirement must remain easy to find. Do not reuse the workshop's free-attendance statement. A valid layout change could be reducing a decorative image so the equipment requirement fits at phone size.
