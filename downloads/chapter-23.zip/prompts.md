# Chapter 23 Turn a source document into a deck

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 23.1.1 Your task
Word body block 3854

```text
Using the complete G0 and G1 text pasted below, extract the facts required for a five-card organiser proposal. Separate event details, agenda, estimated costs, requested decision and missing evidence. Preserve quantities and units. Do not create bookings, invoices, quotes or approval.
```

## 23.2.1 Your task
Word body block 3868

```text
Use G0 and G1 as source material for a new five-card proposal to the organiser. Create a new layout; preserve the supplied facts, calculations and pending approval. Structure the deck as proposal, audience and activities, agenda, estimated budget, and decision requested. Do not add external research or convert estimates into actual expenditure. Show the outline for review first.
```

## 23.3.2 Worked budget
Word body block 3887

```text
Build the budget card from these checked figures. Show the three estimates, total INR 1080, limit INR 1500 and remaining budget INR 420. If you use a chart, chart only the three cost components and label the axis in INR. Keep the remaining budget outside a chart labelled workshop costs.
```
