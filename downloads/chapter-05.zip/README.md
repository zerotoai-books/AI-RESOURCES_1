# Chapter 5 Build a small business communication pack

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 5.4 Exercise 1 Build the master brief and fact register

Step 1  Read the approved event inputs, budget and decision record.

Step 2  Draft Master Brief v4 dated 6 November 2026 using those current inputs.

Step 3  Separate event facts, the ticket snapshot, planned costs and unknown policies.

Step 4  Create a fact register and verify every value against its source.



## 5.5 Exercise 2 Draft the invitation and reminder

Step 1  Define the invitation and registered-attendee reminder audiences separately.

Step 2  Draft the invitation within its word limit using Master Brief v4.

Step 3  Draft the reminder with the confirmed arrival time, device requirement and contact.

Step 4  Compare both messages with the same fact register and save checked versions.



## 5.6 Exercise 3 Write an FAQ that respects unknown policies

Step 1  List the requested FAQ topics before drafting.

Step 2  Find the source for each answer in Master Brief v4.

Step 3  Answer confirmed questions and refer unknown policies to the organiser.

Step 4  Check for unsupported refunds, certificates, refreshments or loan devices.



## 5.7 Exercise 4 Calculate a budget readers can reconcile

Step 1  Calculate each supplied budget line and include the reserve.

Step 2  Calculate the full Paid-capacity projection separately from recorded receipts.

Step 3  Find the minimum whole Paid-ticket count needed to cover the allowance.

Step 4  Check the generated arithmetic and keep Pending amounts labelled as uncollected.



## 5.8 Exercise 5 Outline a presentation that fits the session

Step 1  Copy the checked teaching, break and question allocations.

Step 2  Request six presentation parts using Master Brief v4 and those timings.

Step 3  Give every teaching part a purpose, key points and a practice action.

Step 4  Add the minutes independently and verify the outline against the two-hour session.



## 5.9.4 Perform the final human checks

Step 1  Compare every current event field with the fact register.

Step 2  Calculate each budget line and all summary measures independently.

Step 3  Add the presentation minutes and inspect the actual time ranges.

Step 4  Search your files for the old time, old fee variants, and unsupported policy terms.

Step 5  Read the invitation and reminder aloud for clarity and audience fit.

Step 6  Reopen every saved file and verify that it contains the reviewed version.

Step 7  Record open issues and the permitted use of each document.



## 5.10 Exercise 7 Make a controlled capacity change

Step 1  Save the v4 baseline and record the approved capacity and print-quantity change.

Step 2  Create v5 and update every output that uses those fields.

Step 3  Recalculate the allowance, full-capacity projection and minimum Paid count.

Step 4  Retain the raw ticket data and use enquiry wording because all places are allocated.

Step 5  Record changed outputs and checks of unaffected outputs in the change log.



## 5.11.4 Handover checklist

Step 1  Confirm the folder opens and every named current file exists.

Step 2  Open each current file and compare its title or version with the README.

Step 3  Compare event date, session, venue, fee, capacity, materials, device policy, and contact against v5.

Step 4  Confirm all 10 places are described as allocated, without an invented waiting-list option.

Step 5  Check that budget materials use 10 × 35 and the total is INR 4,450.

Step 6  Check full Paid-capacity fees INR 4,990, projected balance INR 540, and the nine-ticket minimum.

Step 7  Confirm recorded receipts remain INR 3,992 and Pending amounts are not counted as cash.

Step 8  Confirm the outline still totals 120 minutes and ends at 1 pm.

Step 9  Confirm the raw source is retained and the duplicate and R010 decisions are documented.

Step 10  Ask Vishva for the exact address and accessible route, then update the joining documents.

Step 11  Have Shardha review that update and record the decision and pack version.

Step 12  Reopen the final saved files after the last change and archive the superseded copies.



## 5.13.1 Questions to answer in your own words

Step 1  Why should an old invitation not overrule the current master brief?

Step 2  Why are INR 5,988 projected fees different from INR 3,992 recorded receipts?

Step 3  After capacity changes to 10, why does the minimum Paid-ticket count become nine?

Step 4  Why can the reminder still be on Hold after its wording is checked?

Step 5  What would stop you accepting a further capacity reduction to nine?



## 5.13.2 Answer guide

Step 1  The approved brief and decision record establish current facts; an old draft is an output that may contain superseded values.

Step 2  The projection assumes 12 Paid tickets; the recorded receipts come from eight Paid tickets in the working sales data.

Step 3  Materials fall by INR 70, bringing the allowance to INR 4,450; nine tickets yield INR 4,491 and cover it.

Step 4  Exact joining details still need confirmation and a release review even though the supplied wording is accurate.

Step 5  There are 10 active allocated tickets, so a capacity of nine creates an unresolved allocation conflict.

