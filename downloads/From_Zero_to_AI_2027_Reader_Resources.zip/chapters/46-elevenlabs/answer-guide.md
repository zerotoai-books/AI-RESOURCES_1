# Chapter 46 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 46.2.2 Worked answer guide

The supplied script says “Join Plan Your First Workshop on the twenty first of November, twenty twenty six, from eleven a.m. to noon, Indian Standard Time.” Writing the date in words helps define the intended reading. It does not establish that any particular model will pronounce it correctly. Notes such as “pause here” should remain outside the spoken text unless tested as supported controls.

Check your work. Check every number before generating. Repairing a script error first is usually simpler than regenerating an otherwise good recording after review.

## 46.3.2 Worked answer guide

A suitable voice makes the date easy to understand and avoids exaggerated drama for a practical invitation. The current model catalogue includes different families and access routes; do not assume an API model name is necessarily a button in the web interface. [E2] Select from the controls actually offered and record that choice.

Check your work. Voice availability and use rights can vary. Save the applicable source and permission note, and do not describe a synthetic voice as an organiser or attendee endorsement.

## 46.4.2 Worked answer guide

The target is a complete, intelligible sentence with no added words. A hypothetical test that says “twelfth” instead of “twenty first” fails the date check even if the voice sounds polished. A test that feels too formal may be revised for tone after the facts are correct. These are possible evaluation outcomes, not results from an actual supplied recording.

Check your work. Listen at normal speed using the playback route your audience is likely to use. A waveform or transcript alone cannot establish how clearly the date is heard.

## 46.5.2 Worked answer guide

A good review has separate factual and listening checks. Reading along may reveal an omitted phrase; listening without the script may reveal an address that is technically spoken but hard to follow. The actual recording length must be measured. A planning estimate such as words divided by an assumed speaking rate is not that measurement.

Check your work. If the audio exceeds the intended video slot, shorten the approved script or revise the edit deliberately. Do not speed it up until the date becomes difficult to understand.

## 46.6.2 Worked answer guide

A complete record identifies the exact file that was listened to. If generation was not run, the chapter folder contains a script and a blank or Not run record, not an invented MP3. A downloaded file that opens successfully still needs the factual listening check.

Check your work. Keep flawed takes outside the candidate handover folder. Later pronunciation work should start from a named baseline rather than an unidentified history item.

## 46.7.1 Answer guide after your attempt

The script must preserve 28 November 2026, 3 to 4.30 pm Indian Standard Time, Studio Room in Kochi, INR 650 and bring your own camera or camera phone. A clear spoken fee is “six hundred and fifty Indian rupees.” It must not describe this as the free Chennai event. Measured duration and pronunciation review remain pending until audio exists.
