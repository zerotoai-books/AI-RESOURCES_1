# Chapter 28 Clean data and build summaries

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 28.1.1 Your task
Word body block 4301

```text
Inspect RawRegistrationTable on RawRegistrations without editing it. Identify duplicate RegistrationIDs, missing Status values, category or status spelling and spacing differences, and dates stored as text. List the affected IDs and fields. Do not delete rows, fill unknown booking statuses or change the original sheet.
```

## 28.2.1 Your task
Word body block 4320

```text
Create a cleaning plan using E0's approved rules. Make a separate CleanedRegistrations sheet and leave RawRegistrations unchanged. Standardise recognised labels, convert R06's supplied date, keep one exact R03 copy and retain R11 as Needs review. Do not turn a missing status into Confirmed or invent a date. Show the proposed actions before editing.
```

## 28.4.1 Your task
Word body block 4345

```text
Using CleanRegistrationTable only, create a status summary with record counts and a category summary of Confirmed seats. Include Needs review as its own status. Use formulas linked to the cleaned table, not hardcoded totals. Explain how the category figures reconcile to the overall confirmed-seat total.
```
