# Chapter 18 Use images and edit individual elements

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 18.2.1 Your task

Step 1  Write the image's purpose in one sentence.

Step 2  Make the drawing in Appendix A7 or use an available generation route.

Step 3  Keep the image illustrative and free of event lettering.

Step 4  Avoid a brand, identifiable person or venue claim.

Step 5  Record the selected asset's filename or source.



## 18.3.1 Your task

Step 1  Keep the title, date and contact in their own text elements.

Step 2  Place the image below or beside the information group.

Step 3  Resize proportionally so the drawing is not stretched.

Step 4  If cropping is needed, check which objects or edges disappear.

Step 5  Recheck the complete reading order.



## 18.4.1 Your task

Step 1  Select the intended object and inspect the selection outline.

Step 2  Make one change at a time.

Step 3  If several elements move together, inspect whether they are grouped.

Step 4  Use undo when the result changes the wrong object.

Step 5  Compare the revised design with C1 after the edits.



## 18.5.1 Your task

Step 1  Identify every image file or in-app asset used.

Step 2  Record its origin, identifier, date, intended use and permission evidence.

Step 3  Distinguish your own drawing, third-party library content and generated material.

Step 4  Record unresolved terms or approval questions without inventing exclusive rights.



## 18.6.1 Your task

Step 1  Check for stretching, unexpected crop and pixelation.

Step 2  Read the event name, schedule, venue and contact without zooming.

Step 3  Confirm that no generated lettering replaced a required fact.

Step 4  Confirm the asset record matches the image used.

Step 5  Save any remaining issue in the correction record.

