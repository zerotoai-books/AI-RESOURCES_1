import argparse
import csv
import json
import sqlite3
from registration import Store


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", required=True)
    commands = parser.add_subparsers(dest="command", required=True)
    init = commands.add_parser("init")
    init.add_argument("--capacity", type=int, default=12)
    load = commands.add_parser("import-csv")
    load.add_argument("filename")
    change = commands.add_parser("set-status")
    change.add_argument("--id", required=True)
    change.add_argument("--status", required=True)
    commands.add_parser("summary")
    commands.add_parser("list")
    args = parser.parse_args()
    try:
        if args.command == "init":
            Store.create(args.db, args.capacity)
            print("Initialised")
            return 0
        with Store(args.db) as store:
            if args.command == "import-csv":
                store.import_csv(args.filename)
                print("Imported")
            elif args.command == "set-status":
                store.set_status(args.id, args.status)
                print("Updated")
            elif args.command == "summary":
                print(json.dumps(store.summary(), indent=2))
            else:
                print(json.dumps(store.rows(), indent=2))
    except (ValueError, csv.Error) as error:
        print("Input error:", error)
        return 2
    except (OSError, sqlite3.Error) as error:
        print("Storage error:", error)
        return 3
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
