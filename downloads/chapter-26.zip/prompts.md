# Chapter 26 Prepare a workbook and ask a data question

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 26.3.1 Your task
Word body block 4147

```text
Inspect RegistrationTable on the Registrations sheet. Explain its columns, record count and meaning. Do not edit the workbook. Tell me whether any missing ID, inconsistent status or nonnumeric Seats value prevents answering a confirmed-seats question.
```

## 26.4.1 Your task
Word body block 4158

```text
Using RegistrationTable only, sum Seats where Status is Confirmed. Exclude Waitlisted and Cancelled. Give the result and list the matching RegistrationIDs so I can verify it. Answer in chat only and do not change any cells. Do not use web information or another workbook.
```

## 26.6.1 Your task
Word body block 4183

```text
Write a brief explanation using my checked result from RegistrationTable: eight confirmed seats, capacity twelve, one waitlisted record and one cancelled record. Say four seats remain available against confirmed bookings. Do not claim that the waitlisted person has been promoted or that these are real event records.
```
