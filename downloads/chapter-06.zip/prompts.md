# Chapter 6 Start a conversation and learn something new

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 6.4.1 Prompt to try
Word body block 1571

```text
Using only source note C1 and the practice case above, explain capacity, confirmed bookings, and places available to an adult beginner. Keep the explanation under 120 words. Use the supplied numbers. Make the status of the waiting list clear. Do not invent other bookings or restrictions.
```

## 6.5.1 Prompt to try
Word body block 1590

```text
Rewrite that explanation in no more than 60 words. Use everyday language. Keep capacity 12, confirmed places eight, and available places four. Explain that the waiting list is not confirmed. Do not add a new example.
```

## 6.5.4 A useful correction
Word body block 1596

```text
The sentence about 12 people suggests actual attendance. The source says 12 is the capacity. Correct that sentence and retain the distinction between confirmed bookings and waiting-list requests.
```

## 6.6.1 Prompt to try
Word body block 1607

```text
Review this learner explanation against C1: “Capacity is 12. Eight people booked and three are waiting, so 11 places are confirmed and only one place is available.” Identify the exact mistake, explain the correction, and ask me one question to test the distinction. Keep the feedback under 100 words. Do not answer your question yet.
```

## 6.7.1 Prompt to try
Word body block 1624

```text
Use C1 to tutor me. Ask three short questions, one at a time, and wait for my answer after each. Test the difference between capacity and bookings, calculate available places when all required facts are known, and recognise when a booking count is missing. Give feedback only after I answer. Do not invent booking rules.
```

## 6.8.1 Prompt to try
Word body block 1645

```text
Check the response above against C1 and the original practice case. List each factual claim with its status and the source basis. Do not explain invented deposits or extra chairs as if they were facts. Then give a corrected answer under 60 words.
```

## 6.9.1 One suitable prompt
Word body block 1668

```text
Using C2 and the definitions in C1, explain the situation before and after four waiting requests are accepted. Keep it under 100 words. Separate capacity, confirmed places, available places, and remaining waiting requests. Show the arithmetic and do not invent other changes.
```

## 6.10.1 Learn from a supplied note
Word body block 1676

```text
Explain [idea] to [learner] using only [source]. Keep it under [word limit]. Give an example using [supplied facts]. Identify anything the source does not establish.
```

## 6.10.2 Check my understanding
Word body block 1678

```text
Compare my explanation with [source]. Identify a specific misunderstanding, explain the source rule, and ask one new question. Wait for my answer before giving feedback.
```

## 6.10.3 Revise without losing meaning
Word body block 1680

```text
Make the explanation simpler and shorter. Preserve [key distinction and facts]. After the revision, identify any necessary point that the shorter version omits.
```
