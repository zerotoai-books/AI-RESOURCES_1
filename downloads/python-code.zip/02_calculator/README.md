# 02_calculator

Printed reference recovered without code changes. Python 3.12 or later and the standard library. The review reran it on 3.12.14.

Run `python calculator.py 25 12 --discount 10`. Then run `python -m unittest -v test_calculator` for six methods. `python -m unittest -v test_fixed` runs two full-calculator comparison checks. See CORRECTIONS.md for the target distinction.

Keep the baseline unchanged and use a working copy. This is a local teaching example.
