# Chapter 16 Create your first workshop poster

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 16.3.1 Your task

Step 1  Copy the current facts from C0 and C1.

Step 2  Put the event name first in the reading order.

Step 3  Make the date and time the next important information.

Step 4  Include the venue and registration contact.

Step 5  Ask for editable text where the available design tool supports it.



## 16.4.1 Your task

Step 1  Generate or open the starting design.

Step 2  Give it a clear name, such as Workshop A4 draft v1.

Step 3  Inspect the text and separate elements in the editor.

Step 4  Identify missing facts and added claims before changing colours.

Step 5  Save a note describing the route used.



## 16.5.2 Worked poster copy

Step 1  Place the event title in its own text element.

Step 2  Keep date, time and venue together as one readable group or aligned elements.

Step 3  Give the registration instruction its own clear line.

Step 4  Check the contact letter by letter.

Step 5  Click each text element and make a small test edit, then undo it.



## 16.6.1 Your task

Step 1  Place the flawed wording beside C0 version 2.

Step 2  Mark wrong facts, missing essentials and unsupported promises separately.

Step 3  Record the source for every corrected value.

Step 4  Recheck the wording before changing the visual design.



## 16.7.1 Your task

Step 1  Choose the intended page, not an earlier draft page.

Step 2  Download the review image.

Step 3  Open the downloaded file outside the Canva editor.

Step 4  Compare every fact with C1.

Step 5  Keep the editable source design and the reviewed image together in your record.

