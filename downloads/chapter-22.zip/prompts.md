# Chapter 22 Improve the sequence and slide wording

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 22.1.1 Your task
Word body block 3766

```text
Review the audience deck against G0. Propose the clearest order for someone deciding whether to attend. Explain each card's purpose in one sentence. Reorder only after showing the proposal. Preserve the event facts and five-card limit.
```

## 22.2.1 Your task
Word body block 3778

```text
Replace this paragraph with clear audience copy based on G0. Explain who the session suits and what participants practise. Remove guarantees, certification and unsupported benefits. Keep the wording suitable for one presentation card.
```

## 22.3.1 Your task
Word body block 3791

```text
Revise the practice card to three short task statements from G0. Draft separate speaker notes explaining what each task involves. Do not add a new activity or a promised result. Keep the date, venue and contact on their appropriate cards.
```

## 22.4.1 Your task
Word body block 3807

```text
Improve this card's hierarchy while preserving its checked text. Make the title prominent, group the three tasks and provide enough spacing to read them. Use the G0 palette. If everything does not fit, simplify the layout or move speaker detail to notes before reducing the text size.
```
