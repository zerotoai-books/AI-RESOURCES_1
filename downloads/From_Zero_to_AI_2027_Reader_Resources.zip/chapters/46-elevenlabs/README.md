# Chapter 46 Generate a clear voiceover from an approved script

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 46.2 Exercise 1 Separate spoken text from production notes

Step 1  Read B0 and compare the supplied English script line by line.

Step 2  Copy only the spoken text into a working script file.

Step 3  Keep timing targets, pronunciation notes and approval fields in a separate cue sheet.



## 46.3 Exercise 2 Choose a voice and model for the task

Step 1  Audition eligible voices with one short sentence from the script.

Step 2  Select a model offered in your account for the intended language.

Step 3  Record voice name or ID, model, settings and displayed generation charge.



## 46.4 Exercise 3 Generate a short first test

Step 1  Paste the audition sentence with the intended punctuation.

Step 2  Confirm the voice, model and charge before generating.

Step 3  Listen to the complete test and save the actual output if suitable.



## 46.5 Exercise 4 Generate and review the full script

Step 1  Generate the full script after the test is acceptable.

Step 2  Listen with the script visible, then listen once without reading it.

Step 3  Check omissions, extra words, names, numbers, ending and measured duration.



## 46.6 Exercise 5 Name and document the take

Step 1  Download using an available format and record the actual extension.

Step 2  Name the take ch46_main_EN_A and store its script and settings record.

Step 3  Open the downloaded file in a separate player and check the whole recording.

