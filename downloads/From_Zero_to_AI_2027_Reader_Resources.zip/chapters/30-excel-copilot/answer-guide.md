# Chapter 30 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 30.1.2 Worked input layout

| Cell | Input | Baseline |
| --- | --- | --- |
| B5 | Capacity | 12 |
| B6 | Budget limit INR | 1500 |
| B7 | Materials INR per seat | 25 |
| B8 | Printing INR per seat | 15 |
| B9 | Room estimate INR | 600 |

## 30.1.3 Answer guide

Changing capacity must change materials and printing quantities, available seats and capacity used. Changing a booking status changes confirmed seats, but it does not change a budget planned for full capacity. Keeping this planning basis explicit prevents the workbook from quietly switching between capacity and bookings.

## 30.2.2 Worked budget layout

Build A14:D17 using Appendix A2: Item, Quantity, UnitCost and LineTotal. Row 15 is Room, row 16 Materials and row 17 Printing. The room quantity is one; materials and printing quantities refer to B5. Their unit prices refer to B7 and B8; the room price refers to B9. D19 is planned cost, D20 remaining budget and D21 budget status.

```text
Complete planned total in D19
=IF(COUNT(D15:D17)=ROWS(D15:D17),SUM(D15:D17),"Check costs")
```

```text
Remaining budget in D20
=IF(NOT(ISNUMBER(B6)),"Missing budget",IF(B6<0,"Invalid budget",
  IF(ISNUMBER(D19),B6-D19,"Check costs")))
```

## 30.2.3 Answer guide

The baseline cost lines are INR 600, INR 300 and INR 180, giving total INR 1080 and remaining budget INR 420. The line formulas must already expose missing quantities or prices for the complete-total check to work. Otherwise a blank converted to zero would appear numeric and conceal the omission.

Enter the booking formulas printed in Appendix A2: E5 confirmed seats, E6 available seats, E7 seats over capacity and E8 capacity used. They separate spare capacity from overbooking and check the capacity input before displaying dependent results.

At baseline the outputs are eight, four, zero and 66.7%. An overbooked event should show zero available seats and a positive over-capacity count. Do not hide that condition by displaying a negative number labelled seats available.

## 30.3.2 Answer guide

For the manual route, use Data, Data Validation and choose the appropriate whole-number, decimal or list rule. Inspect its error alert and test normal entry in your Excel version. [EREF9] Check newly added table rows for the required validation and calculated columns instead of assuming every rule carried over.

Add IDCopies to your cleaned registration table using the COUNTIFS formula in Appendix A2. A value above one flags a repeated key. The main sheet counts rows carrying repeated IDs. A duplicated pair flags two rows; that measure is not the number of extra records to delete.

The tracker also shows Needs review records, unclassified statuses and blank IDs. None of these checks authorises a booking change or automatic deletion. A colour must draw attention to a recorded condition, rather than replace its label or evidence.

## 30.4.2 Worked test expectations

| Independent test | Cost result | Booking or review result |
| --- | --- | --- |
| Materials price 30 | Total 1140, remaining 360 | Confirmed seats stay 8 |
| Capacity 10 | Total 1000, remaining 500 | Available 2, used 80% |
| R07 Confirmed | Total stays 1080 | Confirmed 9, available 3 |
| Budget limit 1000 | Remaining negative 80 | Show Over budget |
| Materials price missing | No complete numeric total | Show missing input |
| Materials price zero | Total 780, remaining 720 | Zero remains valid |
| Capacity zero | No valid cost or utilisation result | Reject or flag invalid input |
| Repeated confirmed ID | Seat sum may rise incorrectly | Flag repeated IDs and investigate |

## 30.4.3 Answer guide

For R07 Confirmed, Community becomes five and Workplace stays four. The chart should follow those formula values. Restore Waitlisted to return to four, four and eight. If your workbook also contains a PivotTable, refresh and inspect it after the source change.

For an extension test, add a new unique Confirmed Community record with one seat. Verify that the native table expanded, the new IDCopies formula and validation are present, confirmed seats become nine and Community becomes five. If a formula or chart does not include the new record, correct its source coverage before recording the test as passed.

The expected values are answer checks, not evidence that your Excel application performed them. Record the actual result and any correction. Keep an invalid test value out of the final workbook.

## 30.5.2 Worked handover note

```text
The teaching tracker plans for capacity twelve using a budget limit of INR 1500, materials at INR 25 per seat, printing at INR 15 per seat and a room estimate of INR 600. Planned cost is INR 1080 and remaining budget INR 420. Eight seats are Confirmed, leaving four available. R11 remains Needs review. The raw records are preserved. Record the actual change tests and reviewer details before marking the handover review complete.
```

## 30.5.3 Answer guide

Create Reviewer status in E30 and Reviewer initials in E31. Enter the E32 formula printed in Appendix A2: it remains Awaiting reviewer until status is Reviewed, then requests initials if missing. Completing these fields records a review; it does not erase R11 or establish approval of a real event.

Save the editable workbook, original data, cleaning log and test checklist together. For a real dataset, repeat the source and calculation checks on that actual population; the teaching results do not transfer automatically.

## 30.6.1 Answer guide

Planned cost is INR 600 plus INR 150 plus INR 90, or INR 840. Remaining budget is INR 60. Available seats are zero and the over-capacity count is two. Capacity used is approximately 133.3%. The positive budget remainder does not resolve the overbooking; identify that open action in the handover.
