# Chapter 33 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 33.1.2 Worked observations

The starter program prints Total INR 290.00. Its test expects Decimal("270.00") and fails. The failing test is intentional and should return exit code one. An import error or zero discovered tests would be a different problem and would not establish this reproduction.

The independent calculation is twenty-five times twelve, giving subtotal three hundred. Ten percent of three hundred is thirty. Subtracting thirty leaves two hundred and seventy. A test expecting two hundred and ninety would preserve the bug rather than detect it.

## 33.1.3 Answer guide

A reproducible report identifies the file version, working folder, command, inputs, actual result and independently justified expectation. A report saying only that the calculator is broken leaves the assistant to guess. Keep relevant error text intact, including the first failing assertion.

## 33.2.2 Worked diagnosis

The function subtracts the number ten directly from the subtotal, treating the percentage as a rupee amount. The multiplication producing three hundred is correct. The repair needs to calculate the discount from that subtotal, apply K1's rounding policy and then subtract the discount.

## 33.2.3 Check your work

The word percent in a variable name does not make Python apply a percentage. Names help readers, but operators determine the calculation. The trace should identify the wrong operation rather than blame Decimal, the terminal or the price input without evidence.

## 33.3.2 Worked inspection guide

Before the broken return executes, subtotal should be Decimal("300") and discount_percent should still be the supplied text "10". The return expression converts that ten to Decimal and subtracts it as a fixed amount. It never divides a percentage by one hundred.

If you cannot use the debugger, temporarily print the subtotal and the proposed discount immediately before returning. Label these as diagnostic output. Restore the normal output after the investigation. A print trace is a valid manual inspection route, but it is not evidence that you used a breakpoint.

## 33.3.3 Answer guide

Inspect the saved file and active run. If the debugger is paused in another copy or running an older saved version, its values may be correct for that file while irrelevant to your current edit. Record the file path and interpreter when the result does not match the trace you expected.

## 33.4.2 Worked repair for controlled valid inputs

The worked file calculator_fixed.py expresses the repaired calculation as:

```text
def fixed_total(unit_price, quantity, discount_percent):
    subtotal = Decimal(unit_price) * int(quantity)
    discount = (
        subtotal * Decimal(discount_percent) / Decimal("100")
    ).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return subtotal - discount
```

The file includes the required Decimal and ROUND_HALF_UP imports. When patching your original function, keep its existing name; the excerpt's fixed_total name identifies the separate worked answer. This minimal repair assumes the controlled valid inputs. Use the full calculator.py from Chapter 32 for K1's complete validation and command-line handling.

## 33.4.3 Answer guide

The repaired baseline prints 270.00. A diff should show the percentage calculation and its rounding, together with the needed import. A replacement that changes expected 270 to 290, hardcodes a return of 270 or removes the test has not fixed the defect.

## 33.5.2 Worked regression outcomes

The original total is INR 270.00. The independent subtotal is INR 200.00 and its fifteen-percent discount is INR 30.00, leaving INR 170.00. The old broken expression would return INR 185.00 for that second case. Both amounts therefore help distinguish the actual percentage repair from a hardcoded baseline.

From a separate learning folder containing calculator.py and the test_fixed.py listing in Appendix A4, run python -m unittest -v test_fixed. It checks the original baseline and an independent case. Your untouched 03_debug baseline should still fail its one test; keep the negative example out of a suite expected to pass.

## 33.6.1 Answer guide

K1 calculates subtotal INR 0.15, then rounds the overall discount INR 0.015 to INR 0.02. The total is INR 0.13. Rounding each unit discount INR 0.005 to INR 0.01 first gives total discount INR 0.03 and total INR 0.12. The difference identifies a rounding-order defect even though larger round-number examples may agree.
