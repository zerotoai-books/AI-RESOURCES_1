# Chapter 4 Plan and review a multi-step assignment

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 4.4 Exercise 1 Define what completion means

Step 1  Read all 12 tasks and write one result that would show completion for each.

Step 2  Keep review and approval tasks distinct from drafting tasks.

Step 3  Ask ChatGPT to suggest completion conditions using the supplied scope.

Step 4  Inspect any conditions that require a new task, purchase, or policy.

Step 5  Save the checked conditions beside the task list.



## 4.5 Exercise 2 Add owners and inspect dependencies

Step 1  Read the owner and prerequisite fields for all twelve tasks.

Step 2  List the dependencies and check that each referenced task exists.

Step 3  Find independent tasks and check whether they compete for the same owner.

Step 4  Record missing owners, cycles or impossible parallel work before scheduling.



## 4.6 Exercise 3 Build a schedule inside the working windows

Step 1  Add the task minutes by owner before requesting the schedule.

Step 2  Write down each owner’s daily window and weekly capacity.

Step 3  Ask for dated start and finish times with task IDs.

Step 4  Check each dependency against the actual finish time of its predecessors.

Step 5  Check owner overlaps, daily limits, and the Friday deadline.

Step 6  Save the schedule as a proposed plan, together with its open decisions.



## 4.7 Exercise 4 Review a deliberately defective plan

Step 1  Keep the defective schedule separate from the accepted task list.

Step 2  Check every slot against its owner, duration, working window and prerequisites.

Step 3  List missing tasks, overlaps and unsupported additions.

Step 4  Compare the repaired proposal with the entire P01 to P12 sequence.



## 4.8 Exercise 5 Plan the event day without assuming attendance

Step 1  Copy the Saturday room and teaching windows into a planning sheet.

Step 2  Place setup, registration and tidying within room access but outside teaching where required.

Step 3  Allocate the teaching blocks, break and questions within the two-hour session.

Step 4  Check the totals and mark every proposed owner as awaiting Saturday confirmation.



## 4.9 Exercise 6 Record risks and the release decision

Step 1  Read the preparation and event-day proposals together.

Step 2  Separate current unresolved issues from possible future disruptions.

Step 3  Name the task, next action and decision evidence for each issue.

Step 4  Write a proposed release status with reasons and leave approval to the reviewer.



## 4.11.1 Questions to answer in your own words

Step 1  Why can the team have spare minutes while a task is still blocked?

Step 2  Why does P08 need three separate inputs?

Step 3  What is the difference between completing P12 and receiving approval?

Step 4  Why does Saturday attendance need a separate decision?

Step 5  Which tasks move when Vishva loses Tuesday availability?



## 4.11.2 Answer guide

Step 1  Unused minutes may belong to the wrong owner or fall outside a required access slot or dependency sequence.

Step 2  The review must inspect the invitation, FAQ, and presentation outline, not only one draft.

Step 3  P12 records a decision; the decision may be Approve, Hold, or Reject.

Step 4  The supplied weekday preparation windows do not establish event-day availability.

Step 5  P03 and P04 move to Wednesday; P05 and P06 follow on Thursday. Under the second constraint, P07 also moves to Thursday.

