# Chapter 1 Open ChatGPT and complete your first useful tasks

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 1.3.1 Prompt to try
Word body block 180

```text
Explain what a prompt is in plain English. Use one everyday example and keep your answer under 80 words.
```

## 1.4.1 Prompt to try
Word body block 194

```text
Explain cloud storage to an adult who is comfortable using a phone but has never studied computing. Keep it under 100 words. Give one everyday example. Avoid technical jargon.
```

## 1.4.4 Prompt to try
Word body block 201

```text
Now explain the same idea in two sentences. Use the example of a holiday photograph. Keep the point about access clear.
```

## 1.6.1 Prompt to try
Word body block 219

```text
I have one hour this evening to practise writing better emails with AI. I am a beginner. Give me a simple practice plan with durations for each activity. Include time to check and save my work.
```

## 1.6.3 Prompt to try
Word body block 223

```text
Simplify that into exactly three activities. Use 15 minutes for learning, 30 minutes for practice, and 15 minutes for checking and saving. Give one action for each activity. Do not add homework.
```

## 1.7.2 Prompt to try
Word body block 246

```text
Using only the workshop facts above, write an invitation email for adults who are new to AI. Include a subject line. Keep the body under 120 words. Use a warm, straightforward tone. Include the date, time zone, venue, fee, capacity, included materials, and booking email. Do not invent trainer names, certificates, refreshments, or a refund policy.
```

## 1.8.2 Prompt to try
Word body block 264

```text
Use only these meeting notes. Write a two-sentence summary, then an action table with Task, Owner, and Due date. Mark missing owners as Not assigned and missing dates as Not agreed. Finish with the open questions. Do not convert a pending item into a confirmed decision.
```

## 1.9.2 Prompt to try
Word body block 293

```text
Calculate the line total for each item and the overall stationery total. Show quantity multiplied by unit price. Use INR. No tax, discount, or delivery charge is supplied, so do not add any.
```

## 1.9.5 Prompt to try
Word body block 299

```text
A colleague says the total is INR 930. Check that claim against the supplied order. Explain any discrepancy using the actual calculations rather than agreeing with the colleague.
```

## 1.10.1 Prompt to try
Word body block 314

```text
Create a communication pack using only this workshop brief. Include an invitation email with a subject and body under 120 words, a reminder message under 60 words, and three FAQ answers covering audience, included materials, and booking. Do not invent a refund policy, trainer qualifications, equipment promises, or attendee registrations. Keep the details consistent across all outputs.
```

## 1.10.3 Prompt to try
Word body block 319

```text
The workshop start time has changed to 11 am IST and the end time to 1 pm IST on the same date. Update every part of the pack that mentions the time. Preserve all other supplied facts. Add a short change log after the revised pack.
```
