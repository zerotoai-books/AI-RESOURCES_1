# Chapter 50 Produce a complete audio handover

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 50.2.1 Useful prompt or direction
Word body block 6078

```text
Audio package scope: short English promotion for a thirty second video; longer three part English explanation; Spanish practice draft as a separate pending candidate. Use B0 facts. For each item show script version, take, target, measured duration and review status.
```

## 50.3.1 Useful prompt or direction
Word body block 6088

```text
Timing direction: Use Promotion_30s_EN.txt. Target a clear recording that fits the thirty second edit. Keep the date, time with timezone, venue, free adult beginner audience, English activity and booking route. Report actual duration after generation; do not promise an exact length from text alone.
```

## 50.4.1 Useful prompt or direction
Word body block 6098

```text
Alignment review: Confirm that the spoken date, time, venue and contact agree with editable titles. Keep important text readable while narration plays. Record the actual audio end and whether the final card remains visible long enough.
```

## 50.5.1 Useful prompt or direction
Word body block 6108

```text
Final quality record: candidate ___; script match ___; date and time ___; names and contact ___; beginning and ending ___; level and background sound ___; format and duration ___; reviewer ___; status ___.
```

## 50.6.1 Useful prompt or direction
Word body block 6118

```text
Final cover note: This package contains the listed candidate files and editable scripts for B0. Measured durations and listening results are in the manifest. Missing outputs and pending reviews are explicitly listed. Approval Pending; no public release performed.
```
