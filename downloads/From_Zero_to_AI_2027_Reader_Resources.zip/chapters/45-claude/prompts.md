# Chapter 45 Deliver a complete workshop operations pack

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 45.2.1 Useful prompt or direction
Word body block 5723

```text
Prepare an operations pack using B0, B3 and B4 only. First give a contents list and a source map. Do not use B2 capacity ten. Keep the registration fixture and feedback sample distinct from event arrangements.
```

## 45.3.1 Useful prompt or direction
Word body block 5733

```text
Create a clock timed agenda from B4: welcome 5 minutes, example 10, guided practice 15, independent practice 15, review 10 and close 5. Start at 11 am IST. Show start and end times and the total.
```

## 45.4.1 Useful prompt or direction
Word body block 5743

```text
Using B4 full capacity planning, calculate room INR 600, materials 12 times INR 25 and printing 12 times INR 15. Show the total and remaining amount within the INR 1500 budget. Do not call the remainder profit.
```

## 45.5.1 Useful prompt or direction
Word body block 5753

```text
Audit the operations pack against its source map. Report contradictions, unsupported promises, arithmetic errors and missing checks. Confirm capacity 12, eight confirmed records, four available places, sixty agenda minutes and INR 1080 planned cost. Do not invent approvals or assign real people.
```

## 45.6.1 Useful prompt or direction
Word body block 5763

```text
Handover cover note: Candidate version ___ uses B0, B3 and B4. Checked calculations ___; source files ___; calculator scope ___; unresolved organiser checks ___; approval Pending. No messages sent or public release performed.
```
