# Chapter 34 Add tests and review dependencies

Exact prompt-style blocks from the supplied Word manuscript. Context, source facts and the order of exercises still matter. These are editorial examples, not captured account outputs.

## 34.1.1 Your task
Word body block 4874

```text
Create a test plan from K1 before writing tests. Cover normal values, permitted boundaries, invalid formats, missing input, genuine zero and discount rounding. Give independently calculated expected outcomes. Do not use quote itself to generate the expected answers and do not alter the implementation yet.
```

## 34.2.1 Your task
Word body block 4896

```text
Write unittest tests for my calculator.py using K1 and the approved test matrix. Assert independently specified Decimal values. Use assertRaises for rejected inputs and check subtotal, discount and total separately for the baseline. Do not weaken K1 or change expected values merely because the current code differs.
```

## 34.3.1 Your task
Word body block 4915

```text
Interpret this actual unittest output. First state how many tests ran and whether the result is a failure, an error or no discovery. Explain the first relevant mismatch against K1. Before suggesting an edit, check whether the problem lies in the implementation, the expected value or importing the wrong file.
```

## 34.4.1 Your task
Word body block 4929

```text
Add command-line checks to the calculator tests using sys.executable and subprocess from the standard library. Run a valid quote and a fractional quantity in separate processes, check exit codes and output, and verify that importing calculator prints nothing. Do not hardcode a machine-specific Python path or add a test dependency.
```

## 34.5.1 Your task
Word body block 4943

```text
Review the calculator project's imports and the setup commands printed in Appendix A3 and A4. Identify local modules and standard-library modules, and flag any actual third-party dependency. Keep installation instructions accurate for this code. Do not add packages, API keys, cloud services or repository publishing steps. Explain what the passing tests do and do not establish.
```
