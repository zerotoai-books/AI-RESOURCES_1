# Chapter 6 Start a conversation and learn something new

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 6.2 Get ready

Step 1  Open https://gemini.google.com in your browser and check the address.

Step 2  Sign in with a Google Account that has access to Gemini. Work and school accounts may depend on organisation settings. Follow the official sign-in guidance if access is unavailable. [1]

Step 3  Start a new chat using the option shown in your account.

Step 4  Find the message box, type a question, and select the submit control. [1]

Step 5  Create a document called Gemini Practice Log. Add Chapter 6 and today’s date.

Step 6  Keep the source note below beside the conversation. Save prompts, revisions, and checked answers in the log.



## 6.4 Exercise 1 Ask for an explanation you can check

Step 1  Paste C1 and the practice case into a new chat.

Step 2  Enter the prompt below.

Step 3  Read the explanation once for meaning, then again for numbers.

Step 4  Circle every number and compare it with the practice case.

Step 5  Save the prompt and checked explanation.



## 6.5 Exercise 2 Make the explanation simpler

Step 1  Continue in the same chat so Gemini has the practice case.

Step 2  Ask for the simpler explanation below.

Step 3  Compare the shorter answer with C1, not just with the earlier answer.

Step 4  Check whether shortening removed the waiting-list rule.

Step 5  Keep the version that you could comfortably explain to another beginner.



## 6.6 Exercise 3 Explain the idea back in your own words

Step 1  Write your own explanation of the error in the practice log.

Step 2  Paste the learner’s response into the chat with the prompt below.

Step 3  Compare the feedback with your diagnosis.

Step 4  Close or cover the AI answer and write a fresh explanation yourself.

Step 5  Reopen C1 to check your explanation.



## 6.7 Exercise 4 Practise one question at a time

Step 1  Ask Gemini to give one question and wait for your answer.

Step 2  Answer without looking at the worked answer guide.

Step 3  Ask for feedback tied to C1.

Step 4  Correct a wrong answer before moving on.

Step 5  Record the reasoning behind the correction, not just the final number.



## 6.8 Exercise 5 Separate an answer from its evidence

Step 1  Mark each separate claim in the response.

Step 2  Classify it as supported, contradicted, or not supplied.

Step 3  Write the source rule or number beside the classification.

Step 4  Ask Gemini for its own check and compare it with yours.

Step 5  Write a corrected response using only the supported facts.



## 6.9 Exercise 6 Finish a learning conversation independently

Step 1  Write a prompt yourself before copying any pattern from this chapter.

Step 2  Ask for an explanation of what changes and what stays the same.

Step 3  Request a simpler revision if you need one.

Step 4  Recalculate the numbers independently.

Step 5  Write a summary in your own words with the AI answer covered.

Step 6  Save the source, prompt, checked explanation, summary, and one improvement.



## 6.12 Check your understanding

Step 1  Why does room capacity not establish the number of bookings?

Step 2  When can the available count be calculated in C1?

Step 3  Why is an unsupported deposit claim different from a proved false claim?

Step 4  What should you do if Gemini accepts your incorrect calculation?

Step 5  What makes your own summary useful evidence of learning?



## 6.12.1 Answer guide

Step 1  Capacity is the upper limit. Confirmed bookings are a separate count.

Step 2  When capacity, confirmed places, and any other holds or restrictions are known.

Step 3  The source is silent about deposits. It does not prove that none exist.

Step 4  Return to the source rule, show the arithmetic, request a correction, and check it yourself.

Step 5  You produce it without copying the answer and can apply the distinction to a new case.

