# Chapter 1 Open ChatGPT and complete your first useful tasks

1. Open source-inputs.md and identify the source version required for the exercise.
2. Open prompts.md and copy the relevant prompt with its source text or actual attachment.
3. Follow the procedure in the printed chapter and the steps below.
4. Save a working copy and actual observations.
5. Compare with answer-guide.md after your attempt.

Sources, prompts and worked guides serve different purposes. Cloud tool access is separate from downloading these files.

## 1.2 Get ready

Step 1  Type https://chatgpt.com into your browser address bar. Confirm you are on the official site. [3]

Step 2  Choose the sign-up or login option displayed. If you already have an account, use your existing sign-in method. Otherwise follow the on-screen account creation instructions.

Step 3  Complete any verification requested by the service. Enter passwords and verification codes only in the official sign-in process.

Step 4  After signing in, find the message box where you can type an instruction. Start a fresh conversation if another one is already open.

Step 5  Create a local document called AI Practice Log. Add today’s date and the heading ChatGPT Chapter 1. You will save your prompts, corrections, and checked answers here.



## 1.4 Exercise 1 Ask for a useful explanation

Step 1  Stay in your practice conversation or start a new one.

Step 2  Enter the prompt below and read the response.

Step 3  Underline unfamiliar words in your practice log.

Step 4  Send the follow-up instruction and compare the new answer with the first.

Step 5  Save the version you understand best and write one sentence explaining the idea yourself.



## 1.6 Exercise 2 Continue the conversation

Step 1  Start a new conversation for this exercise.

Step 2  Enter the first prompt and examine whether the plan fits one hour.

Step 3  Send the follow-up below in the same conversation.

Step 4  Check the times by adding them yourself.

Step 5  Write down which constraint changed the plan most.



## 1.7.1 The supplied facts

Step 1  Start a fresh chat. First ask only: “Write an invitation to an AI workshop.”

Step 2  Read the response and mark any facts it supplied that you did not provide. These may appear as placeholders or as unsupported claims.

Step 3  Paste the fact brief above, followed by the improved instruction below.

Step 4  Compare the second draft with the brief line by line.

Step 5  Ask for one revision if the tone is too formal, the details are incomplete, or the draft exceeds the limit.



## 1.8.1 Meeting notes to paste

Step 1  Paste the notes into a fresh conversation.

Step 2  Enter the instruction below.

Step 3  Compare every action with the original notes.

Step 4  If the tool fills a gap, ask it to replace the invented value with “Not assigned” or “Not agreed.”

Step 5  Save the corrected action list and unresolved questions.



## 1.9.1 Order details

Step 1  Before asking AI, calculate each line total with a calculator.

Step 2  Add the three totals and write down your answer.

Step 3  Paste the order table as text and enter the prompt below.

Step 4  Compare the answer with your own calculation.

Step 5  Send the challenge prompt and check whether the tool corrects it with evidence.



## 1.10 Exercise 6 Build a small communication pack

Step 1  Start a fresh conversation and paste the full workshop brief from Exercise 3.

Step 2  Ask for the materials using the first prompt below.

Step 3  Read all three outputs before making changes.

Step 4  Change one fact using the follow-up prompt.

Step 5  Check that the change appears wherever needed and that unrelated facts stay correct.

Step 6  Copy the reviewed pack into your practice log. Record the correction and the reason for it.



## 1.16.1 Questions to answer before looking below

Step 1  What information made the second workshop invitation more useful than the first?

Step 2  Why should the action table contain missing dates instead of guessed dates?

Step 3  What is the stationery total, and how can you verify it?

Step 4  After a workshop time change, what needs checking across the communication pack?

Step 5  Why can a polished response still require correction?



## 1.16.2 Answer guide

Step 1  The second invitation had the actual event facts, a defined reader, an output format, a word limit, and a rule against invented details. These gave the assistant a concrete task.

Step 2  The notes did not agree those dates. Guessed deadlines would turn uncertainty into a false commitment.

Step 3  INR 830. Multiply quantity by price for each line and add 480, 200, and 150 independently.

Step 4  Every place the time appears, including the invitation, reminder, and any FAQ answer. Other facts should remain correct.

Step 5  Fluent writing can hide incorrect claims, missing facts, or ignored constraints. Review must compare the answer with the source material.

