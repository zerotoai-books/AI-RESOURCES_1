# Chapter 37 answer guide

Attempt the exercise first. These are editorial reference answers, not evidence that your own account or output passed.

## 37.2.2 Worked answer guide

For the hypothetical duplicated pencil, the note could be: “A second pencil appears near three seconds; it distracts from the calm planning scene.” The selected issue is object stability. If the camera drifts but the drift is harmless, it may rank below an object that changes shape. Prioritising the problem makes the next attempt purposeful.

Check your work. Do not write an exact timestamp from memory. Replay the clip and enter the observed time. If using the hypothetical case, say “Example defect” rather than logging it as your own result.

## 37.3.2 Worked answer guide

Both versions keep the page action. Version B adds a slow movement toward the subject. It should not also ask for an orbit or a wide reveal. A push toward a subject and a zoom can look different; use plain wording describing the desired view if you are unsure of the technical term.

Check your work. For a static shot, a positive description such as “The camera stays motionless throughout” is clearer than a long list of unwanted camera moves. Inspect the result; wording is guidance, not a lock.

## 37.4.2 Worked answer guide

This revision focuses on stable objects and a smaller page action. The setting, style and framing remain comparable. The expected benefit is easier inspection of a small movement, not guaranteed elimination of every defect. If take B introduces a new problem, record that rather than treating the newer version as automatically better.

Check your work. The log must contain the full text of both prompts. “Made it more stable” does not let another learner reproduce your intended change.

## 37.5.2 Worked answer guide

A hypothetical A score of 1, 2, 2 totals five. A hypothetical B score of 2, 1, 2 also totals five. B improves stability but weakens motion; the equal total hides that tradeoff. Choose according to the purpose or attempt a smaller motion revision if your budget allows. Do not present these example scores as actual generated results.

Check your work. A high score cannot make an unreadable date correct. Event titles are checked separately against B0 in Chapter 40.

## 37.6.2 Worked answer guide

If neither take preserves the objects, a permitted still image with a slow editor movement may be a sensible fallback. Label that as an edited still, not a successful Runway generation. If one take is stable enough for a brief background, accept it and move on to titles and playback review.

Check your work. A stopping rule protects time as well as credits. Keep rejected takes in an archive folder so they cannot be imported accidentally into the final edit.

## 37.7.1 Answer guide after your attempt

Gentle motion may be a more manageable first target, but the prediction is not an observed outcome. The comparison should preserve duration, framing and model. Record whether the strap stays attached and whether the camera body remains stable. A suitable decision explains the evidence and the attempt limit; it does not claim that smaller motion always wins.
