## ChatGPT

## Official references for the ChatGPT chapters

The references support the general product use and prompting guidance. The workshop scenarios, datasets, prompts, sample answers, plans, and assessments are teaching material. Product guidance was checked on 11 October 2026. Follow the current official instructions if your account or screen differs.

1 OpenAI  Use ChatGPT
https://learn.chatgpt.com/docs/use-chatgpt

2 OpenAI  Prompting
https://learn.chatgpt.com/docs/prompting

3 OpenAI  ChatGPT on the web
https://learn.chatgpt.com/docs/web
