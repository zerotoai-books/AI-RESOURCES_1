# Chapter 2 source inputs

These are fictional teaching sources from the current printed manuscript. Use the exact source ID and scope named in the exercise. Deliberate defects and old versions remain unchanged.

## 2.4.1 The supplied facts

Sender: Vishva. Recipient: Shardha, a colleague. Document: the invitation draft for the Everyday AI Workshop. Vishva will paste the draft below the email; there is no attachment. Shardha must check the date, time, venue, and booking email. Review deadline: 4 pm IST on 3 November 2026. Shardha should reply with corrections or confirm that these details are accurate. Approval to send the invitation has not been given.

## 2.8.1 The supplied lesson facts

A spreadsheet filter shows rows that match a selected condition and temporarily hides other rows from the view. It does not delete those other records. Removing the filter shows them again. Filtering changes which rows are visible; sorting changes their order. This exercise asks only about filtering, with one condition: payment status is Paid.

| Name | City | Payment status |
| --- | --- | --- |
| Vishva | Chennai | Paid |
| the equipment coordinator | Chennai | Pending |
| Shardha | Kochi | Paid |
| Participant 05 | Chennai | Pending |
| Participant 03 | Kochi | Paid |
| Participant 06 | Bengaluru | Pending |

## 2.10.1 The supplied planning brief

Vishva can work for 45 minutes each weekday, from Monday 2 November through Friday 6 November 2026. These sessions prepare material for the fictional workshop on 7 November. No evenings or weekend preparation sessions are available. Durations below are planning estimates supplied for the exercise. Work outside the list is not required.

| Task | Min | Must happen after |
| --- | --- | --- |
| Draft invitation | 25 | None |
| Review invitation | 10 | Draft invitation |
| Draft reminder | 10 | Review invitation |
| Draft FAQ | 20 | None |
| Check FAQ | 15 | Draft FAQ |
| Draft handout | 35 | None |
| Review handout | 15 | Draft handout |
| Outline presentation | 30 | Review handout |
| Check the complete pack | 15 | All work above |
| Revise flagged issues | 20 | Complete pack check |
| Save and reopen final files | 10 | Revisions |

A dependency is a task that must be completed before another task can begin. Here, the reminder follows the invitation review so it uses checked details. The final pack check must wait for all preceding work, including the presentation outline.

## 2.13.1 The incomplete brief

Vishva says: “Move the Everyday AI Workshop and tell people.” The original session is on 7 November 2026, from 11 am to 1 pm IST, at Learning Room, Adyar, Chennai. The brief does not supply a replacement date or time. It does not confirm whether the venue stays the same or say who should receive the message. The booking contact is learn@example.com.

## 2.14.1 The exercise answers

New date: 14 November 2026. Time: 11 am to 1 pm IST. The venue remains Learning Room, Adyar, Chennai. The recipients are people already booked. They should reply to learn@example.com if they cannot attend the new date. No reason for the change and no refund policy have been supplied.

## 2.15.1 Style example only

```text
Hi Shardha,
Please check the room booking by 2 pm on 30 October. Reply with confirmation or list anything still pending.
Thanks,
Vishva
```

## 2.15.2 Facts for the new task

Vishva writes to the equipment coordinator. The workshop projector needs checking by noon IST on 5 November 2026. The equipment coordinator should test power and image display, then reply with either confirmation that both work or a description of the problem. No attachment or repair appointment has been arranged.

## 2.18.1 The event brief

Event: Smartphone Basics. Date: 21 November 2026. Time: 2 pm to 4 pm IST. Venue: Learning Room, Kochi. Audience: adults who are new to smartphone features. Fee: INR 350. Capacity: 15 attendees. A digital handout is included. Participants must bring their own smartphone. Booking contact: basics@example.com. Sender: Vishva. No refreshments, certificates, device loans, or refund policy are supplied.

## 2.18.2 The lesson brief

A calendar reminder is an alert for a saved event. The event time and reminder time are separate settings. A reminder set for one day before this workshop is due at 2 pm IST on 20 November 2026; the workshop remains at 2 pm IST on 21 November. The exercise assumes that the event and alert settings have been saved correctly. Do not promise that an alert will appear when a device is switched off or its notification settings prevent it.

## 2.18.3 The preparation brief

Use four sessions of 40 minutes, Monday 16 November through Thursday 19 November 2026. There is no preparation session on Friday or at the weekend. The tasks and dependencies appear in the next section. Only the revision task may be split across sessions.

## 2.19 Plan the independent challenge

| Task | Min | Must happen after |
| --- | --- | --- |
| Draft invitation | 20 | None |
| Review invitation | 10 | Draft invitation |
| Draft reminder message | 10 | Invitation review |
| Draft lesson explanation | 25 | None |
| Check lesson explanation | 15 | Lesson draft |
| Review reminder | 10 | Reminder draft |
| Check consistency across pack | 20 | All drafts and reviews above |
| Revise flagged issues | 20 | Consistency check |
| Read final pack | 20 | Revisions |
| Save and reopen final files | 10 | Final read |

## 2.19.2 One valid preparation schedule

Read this only after you have checked your own plan. Monday: invitation draft 20, invitation review 10, reminder draft 10. Tuesday: lesson draft 25, lesson check 15. Wednesday: reminder review 10, consistency check 20, revisions 10. Thursday: remaining revisions 10, final read 20, save and reopen 10.

Every day totals 40 minutes. Required work is 160 minutes, matching the available 4 × 40 = 160. There is no buffer. Revisions are the only split task, shown as two 10-minute parts. The final read follows the completed revisions, and saving follows the final read.

A different plan can pass if it keeps these durations and dependencies. If you need contingency time in real work, agree a change to available time or task scope rather than claiming buffer that the arithmetic does not provide.


## Official tool references

## ChatGPT

## Official references for the ChatGPT chapters

The references support the general product use and prompting guidance. The workshop scenarios, datasets, prompts, sample answers, plans, and assessments are teaching material. Product guidance was checked on 11 October 2026. Follow the current official instructions if your account or screen differs.

1 OpenAI  Use ChatGPT
https://learn.chatgpt.com/docs/use-chatgpt

2 OpenAI  Prompting
https://learn.chatgpt.com/docs/prompting

3 OpenAI  ChatGPT on the web
https://learn.chatgpt.com/docs/web
